package co.id.franknco.controller;

/**
 * Created by GSS-NB-2016-0012 on 8/26/2017.
 */

public class Place {
}
