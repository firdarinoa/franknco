package co.id.franknco.controller;

/**
 * Created by GSS-NB-2016-0012 on 8/25/2017.
 */

public class GetUrlName {
    //public final static String URL = "http://192.168.1.11:80/mpos_bni/index.php/api/mpos/hitapi/format/json"; // INTEGRA
    public final static String URL_Login = "http://autobot.dlinkddns.com:61026/BMSDemoJSONHost/test/technician_login_000";
    public final static String URL_Logout = "http://autobot.dlinkddns.com:61026/BMSDemoJSONHost/test/technician_logout_000";
    public final static String URL_verif_token = "http://autobot.dlinkddns.com:61026/BMSDemoJSONHost/test/technician_token_verification_000";
    public final static String URL_Terminal_Id = "http://autobot.dlinkddns.com:61026/BMSDemoJSONHost/test/technician_get_terminal_list_000";
    public final static String URL_Terminal_Id_details = "http://autobot.dlinkddns.com:61026/BMSDemoJSONHost/test/technician_get_terminal_details_000";
    public final static String URL_Child_Terminal_Id_details = "http://autobot.dlinkddns.com:61026/BMSDemoJSONHost/test/technician_get_terminal_child_details_000";
    public final static String URL_Update_Child_Terminal_Id_details = "http://autobot.dlinkddns.com:61026/BMSDemoJSONHost/test/technician_update_terminal_child_active_stat_000";
    public final static String authorization = "Marcos  ";


    public static final int MY_SOCKET_TIMEOUT_MS = 30000;
    public static final String versioning = "2.0.1";
    public static final String NULL_DATA = "null data";
}
