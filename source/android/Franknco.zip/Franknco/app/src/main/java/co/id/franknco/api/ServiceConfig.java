package co.id.franknco.api;

/**
 * Created by ERD on 12/4/2016.
 */

public class ServiceConfig {
    public static final String BASE_URL = "http://192.168.1.101/api/franknco/franknco_api_RESTFULL/index.php/api/hitapi/";


}
