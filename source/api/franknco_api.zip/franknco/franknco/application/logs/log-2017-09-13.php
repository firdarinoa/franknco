<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-09-13 09:28:08 --> Config Class Initialized
INFO - 2017-09-13 09:28:08 --> Hooks Class Initialized
DEBUG - 2017-09-13 09:28:09 --> UTF-8 Support Enabled
INFO - 2017-09-13 09:28:09 --> Utf8 Class Initialized
INFO - 2017-09-13 09:28:09 --> URI Class Initialized
DEBUG - 2017-09-13 09:28:09 --> No URI present. Default controller set.
INFO - 2017-09-13 09:28:09 --> Router Class Initialized
INFO - 2017-09-13 09:28:09 --> Output Class Initialized
INFO - 2017-09-13 09:28:09 --> Security Class Initialized
DEBUG - 2017-09-13 09:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-13 09:28:09 --> Input Class Initialized
INFO - 2017-09-13 09:28:09 --> Language Class Initialized
INFO - 2017-09-13 09:28:09 --> Loader Class Initialized
INFO - 2017-09-13 09:28:10 --> Helper loaded: url_helper
INFO - 2017-09-13 09:28:10 --> Database Driver Class Initialized
INFO - 2017-09-13 09:28:10 --> Email Class Initialized
INFO - 2017-09-13 09:28:10 --> Controller Class Initialized
INFO - 2017-09-13 09:28:10 --> File loaded: C:\xampp\htdocs\api\franknco\franknco1\application\views\welcome_message.php
INFO - 2017-09-13 09:28:10 --> Final output sent to browser
DEBUG - 2017-09-13 09:28:10 --> Total execution time: 2.2561
INFO - 2017-09-13 09:28:34 --> Config Class Initialized
INFO - 2017-09-13 09:28:34 --> Hooks Class Initialized
DEBUG - 2017-09-13 09:28:34 --> UTF-8 Support Enabled
INFO - 2017-09-13 09:28:34 --> Utf8 Class Initialized
INFO - 2017-09-13 09:28:34 --> URI Class Initialized
DEBUG - 2017-09-13 09:28:34 --> No URI present. Default controller set.
INFO - 2017-09-13 09:28:34 --> Router Class Initialized
INFO - 2017-09-13 09:28:34 --> Output Class Initialized
INFO - 2017-09-13 09:28:34 --> Security Class Initialized
DEBUG - 2017-09-13 09:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-13 09:28:34 --> Input Class Initialized
INFO - 2017-09-13 09:28:34 --> Language Class Initialized
INFO - 2017-09-13 09:28:34 --> Loader Class Initialized
INFO - 2017-09-13 09:28:34 --> Helper loaded: url_helper
INFO - 2017-09-13 09:28:34 --> Database Driver Class Initialized
INFO - 2017-09-13 09:28:34 --> Email Class Initialized
INFO - 2017-09-13 09:28:34 --> Controller Class Initialized
INFO - 2017-09-13 09:28:34 --> File loaded: C:\xampp\htdocs\api\franknco\franknco\application\views\welcome_message.php
INFO - 2017-09-13 09:28:34 --> Final output sent to browser
DEBUG - 2017-09-13 09:28:34 --> Total execution time: 0.4170
INFO - 2017-09-13 09:29:20 --> Config Class Initialized
INFO - 2017-09-13 09:29:20 --> Hooks Class Initialized
DEBUG - 2017-09-13 09:29:21 --> UTF-8 Support Enabled
INFO - 2017-09-13 09:29:21 --> Utf8 Class Initialized
INFO - 2017-09-13 09:29:21 --> URI Class Initialized
INFO - 2017-09-13 09:29:21 --> Router Class Initialized
INFO - 2017-09-13 09:29:21 --> Output Class Initialized
INFO - 2017-09-13 09:29:21 --> Security Class Initialized
DEBUG - 2017-09-13 09:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-13 09:29:21 --> Input Class Initialized
INFO - 2017-09-13 09:29:21 --> Language Class Initialized
INFO - 2017-09-13 09:29:21 --> Loader Class Initialized
INFO - 2017-09-13 09:29:21 --> Helper loaded: url_helper
INFO - 2017-09-13 09:29:21 --> Database Driver Class Initialized
INFO - 2017-09-13 09:29:21 --> Email Class Initialized
INFO - 2017-09-13 09:29:21 --> Controller Class Initialized
DEBUG - 2017-09-13 09:29:21 --> Config file loaded: C:\xampp\htdocs\api\franknco\franknco\application\config/rest.php
INFO - 2017-09-13 09:29:21 --> Helper loaded: inflector_helper
INFO - 2017-09-13 09:29:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-13 09:29:21 --> Helper loaded: log_helper
INFO - 2017-09-13 09:29:21 --> Model Class Initialized
INFO - 2017-09-13 14:29:21 --> Final output sent to browser
DEBUG - 2017-09-13 14:29:21 --> Total execution time: 0.8971
INFO - 2017-09-13 09:30:31 --> Config Class Initialized
INFO - 2017-09-13 09:30:31 --> Hooks Class Initialized
DEBUG - 2017-09-13 09:30:31 --> UTF-8 Support Enabled
INFO - 2017-09-13 09:30:31 --> Utf8 Class Initialized
INFO - 2017-09-13 09:30:31 --> URI Class Initialized
INFO - 2017-09-13 09:30:31 --> Router Class Initialized
INFO - 2017-09-13 09:30:31 --> Output Class Initialized
INFO - 2017-09-13 09:30:31 --> Security Class Initialized
DEBUG - 2017-09-13 09:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-13 09:30:31 --> Input Class Initialized
INFO - 2017-09-13 09:30:31 --> Language Class Initialized
INFO - 2017-09-13 09:30:31 --> Loader Class Initialized
INFO - 2017-09-13 09:30:31 --> Helper loaded: url_helper
INFO - 2017-09-13 09:30:31 --> Database Driver Class Initialized
INFO - 2017-09-13 09:30:31 --> Email Class Initialized
INFO - 2017-09-13 09:30:31 --> Controller Class Initialized
DEBUG - 2017-09-13 09:30:31 --> Config file loaded: C:\xampp\htdocs\api\franknco\franknco\application\config/rest.php
INFO - 2017-09-13 09:30:31 --> Helper loaded: inflector_helper
INFO - 2017-09-13 09:30:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-13 09:30:31 --> Helper loaded: log_helper
INFO - 2017-09-13 09:30:31 --> Model Class Initialized
INFO - 2017-09-13 14:30:31 --> Final output sent to browser
DEBUG - 2017-09-13 14:30:31 --> Total execution time: 0.3450
INFO - 2017-09-13 09:31:24 --> Config Class Initialized
INFO - 2017-09-13 09:31:24 --> Hooks Class Initialized
DEBUG - 2017-09-13 09:31:24 --> UTF-8 Support Enabled
INFO - 2017-09-13 09:31:24 --> Utf8 Class Initialized
INFO - 2017-09-13 09:31:24 --> URI Class Initialized
INFO - 2017-09-13 09:31:24 --> Router Class Initialized
INFO - 2017-09-13 09:31:24 --> Output Class Initialized
INFO - 2017-09-13 09:31:24 --> Security Class Initialized
DEBUG - 2017-09-13 09:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-13 09:31:25 --> Input Class Initialized
INFO - 2017-09-13 09:31:25 --> Language Class Initialized
INFO - 2017-09-13 09:31:25 --> Loader Class Initialized
INFO - 2017-09-13 09:31:25 --> Helper loaded: url_helper
INFO - 2017-09-13 09:31:25 --> Database Driver Class Initialized
INFO - 2017-09-13 09:31:25 --> Email Class Initialized
INFO - 2017-09-13 09:31:25 --> Controller Class Initialized
DEBUG - 2017-09-13 09:31:25 --> Config file loaded: C:\xampp\htdocs\api\franknco\franknco\application\config/rest.php
INFO - 2017-09-13 09:31:25 --> Helper loaded: inflector_helper
INFO - 2017-09-13 09:31:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-13 09:31:25 --> Helper loaded: log_helper
INFO - 2017-09-13 09:31:25 --> Model Class Initialized
INFO - 2017-09-13 14:31:25 --> Final output sent to browser
DEBUG - 2017-09-13 14:31:25 --> Total execution time: 0.7320
INFO - 2017-09-13 09:31:59 --> Config Class Initialized
INFO - 2017-09-13 09:31:59 --> Hooks Class Initialized
DEBUG - 2017-09-13 09:32:00 --> UTF-8 Support Enabled
INFO - 2017-09-13 09:32:00 --> Utf8 Class Initialized
INFO - 2017-09-13 09:32:00 --> URI Class Initialized
INFO - 2017-09-13 09:32:00 --> Router Class Initialized
INFO - 2017-09-13 09:32:00 --> Output Class Initialized
INFO - 2017-09-13 09:32:00 --> Security Class Initialized
DEBUG - 2017-09-13 09:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-13 09:32:00 --> Input Class Initialized
INFO - 2017-09-13 09:32:00 --> Language Class Initialized
INFO - 2017-09-13 09:32:00 --> Loader Class Initialized
INFO - 2017-09-13 09:32:00 --> Helper loaded: url_helper
INFO - 2017-09-13 09:32:00 --> Database Driver Class Initialized
INFO - 2017-09-13 09:32:00 --> Email Class Initialized
INFO - 2017-09-13 09:32:00 --> Controller Class Initialized
DEBUG - 2017-09-13 09:32:00 --> Config file loaded: C:\xampp\htdocs\api\franknco\franknco\application\config/rest.php
INFO - 2017-09-13 09:32:00 --> Helper loaded: inflector_helper
INFO - 2017-09-13 09:32:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-13 09:32:00 --> Helper loaded: log_helper
INFO - 2017-09-13 09:32:00 --> Model Class Initialized
INFO - 2017-09-13 14:32:00 --> Final output sent to browser
DEBUG - 2017-09-13 14:32:00 --> Total execution time: 0.6420
INFO - 2017-09-13 09:32:41 --> Config Class Initialized
INFO - 2017-09-13 09:32:41 --> Hooks Class Initialized
DEBUG - 2017-09-13 09:32:41 --> UTF-8 Support Enabled
INFO - 2017-09-13 09:32:41 --> Utf8 Class Initialized
INFO - 2017-09-13 09:32:41 --> URI Class Initialized
INFO - 2017-09-13 09:32:41 --> Router Class Initialized
INFO - 2017-09-13 09:32:41 --> Output Class Initialized
INFO - 2017-09-13 09:32:41 --> Security Class Initialized
DEBUG - 2017-09-13 09:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-13 09:32:41 --> Input Class Initialized
INFO - 2017-09-13 09:32:41 --> Language Class Initialized
INFO - 2017-09-13 09:32:41 --> Loader Class Initialized
INFO - 2017-09-13 09:32:41 --> Helper loaded: url_helper
INFO - 2017-09-13 09:32:41 --> Database Driver Class Initialized
INFO - 2017-09-13 09:32:41 --> Email Class Initialized
INFO - 2017-09-13 09:32:41 --> Controller Class Initialized
DEBUG - 2017-09-13 09:32:41 --> Config file loaded: C:\xampp\htdocs\api\franknco\franknco\application\config/rest.php
INFO - 2017-09-13 09:32:41 --> Helper loaded: inflector_helper
INFO - 2017-09-13 09:32:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-13 09:32:41 --> Helper loaded: log_helper
INFO - 2017-09-13 09:32:41 --> Model Class Initialized
ERROR - 2017-09-13 14:32:41 --> Severity: Notice --> Undefined index: code C:\xampp\htdocs\api\franknco\franknco\application\controllers\api\franknco_api.php 39
INFO - 2017-09-13 14:32:41 --> Final output sent to browser
DEBUG - 2017-09-13 14:32:41 --> Total execution time: 0.4510
INFO - 2017-09-13 09:33:49 --> Config Class Initialized
INFO - 2017-09-13 09:33:49 --> Hooks Class Initialized
DEBUG - 2017-09-13 09:33:49 --> UTF-8 Support Enabled
INFO - 2017-09-13 09:33:49 --> Utf8 Class Initialized
INFO - 2017-09-13 09:33:49 --> URI Class Initialized
INFO - 2017-09-13 09:33:49 --> Router Class Initialized
INFO - 2017-09-13 09:33:49 --> Output Class Initialized
INFO - 2017-09-13 09:33:49 --> Security Class Initialized
DEBUG - 2017-09-13 09:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-13 09:33:49 --> Input Class Initialized
INFO - 2017-09-13 09:33:49 --> Language Class Initialized
INFO - 2017-09-13 09:33:49 --> Loader Class Initialized
INFO - 2017-09-13 09:33:49 --> Helper loaded: url_helper
INFO - 2017-09-13 09:33:49 --> Database Driver Class Initialized
INFO - 2017-09-13 09:33:49 --> Email Class Initialized
INFO - 2017-09-13 09:33:49 --> Controller Class Initialized
DEBUG - 2017-09-13 09:33:49 --> Config file loaded: C:\xampp\htdocs\api\franknco\franknco\application\config/rest.php
INFO - 2017-09-13 09:33:49 --> Helper loaded: inflector_helper
INFO - 2017-09-13 09:33:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-13 09:33:49 --> Helper loaded: log_helper
INFO - 2017-09-13 09:33:49 --> Model Class Initialized
ERROR - 2017-09-13 14:33:49 --> Severity: Notice --> Undefined index: code C:\xampp\htdocs\api\franknco\franknco\application\controllers\api\franknco_api.php 39
INFO - 2017-09-13 14:33:49 --> Final output sent to browser
DEBUG - 2017-09-13 14:33:49 --> Total execution time: 0.4000
INFO - 2017-09-13 09:35:11 --> Config Class Initialized
INFO - 2017-09-13 09:35:11 --> Hooks Class Initialized
DEBUG - 2017-09-13 09:35:11 --> UTF-8 Support Enabled
INFO - 2017-09-13 09:35:11 --> Utf8 Class Initialized
INFO - 2017-09-13 09:35:11 --> URI Class Initialized
INFO - 2017-09-13 09:35:11 --> Router Class Initialized
INFO - 2017-09-13 09:35:11 --> Output Class Initialized
INFO - 2017-09-13 09:35:11 --> Security Class Initialized
DEBUG - 2017-09-13 09:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-13 09:35:11 --> Input Class Initialized
INFO - 2017-09-13 09:35:11 --> Language Class Initialized
INFO - 2017-09-13 09:35:11 --> Loader Class Initialized
INFO - 2017-09-13 09:35:11 --> Helper loaded: url_helper
INFO - 2017-09-13 09:35:11 --> Database Driver Class Initialized
INFO - 2017-09-13 09:35:11 --> Email Class Initialized
INFO - 2017-09-13 09:35:11 --> Controller Class Initialized
DEBUG - 2017-09-13 09:35:11 --> Config file loaded: C:\xampp\htdocs\api\franknco\franknco\application\config/rest.php
INFO - 2017-09-13 09:35:11 --> Helper loaded: inflector_helper
INFO - 2017-09-13 09:35:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-13 09:35:11 --> Helper loaded: log_helper
INFO - 2017-09-13 09:35:11 --> Model Class Initialized
ERROR - 2017-09-13 14:35:11 --> Severity: Notice --> Undefined index: code C:\xampp\htdocs\api\franknco\franknco\application\controllers\api\franknco_api.php 39
INFO - 2017-09-13 14:35:11 --> Final output sent to browser
DEBUG - 2017-09-13 14:35:11 --> Total execution time: 0.3500
INFO - 2017-09-13 09:35:26 --> Config Class Initialized
INFO - 2017-09-13 09:35:26 --> Hooks Class Initialized
DEBUG - 2017-09-13 09:35:26 --> UTF-8 Support Enabled
INFO - 2017-09-13 09:35:26 --> Utf8 Class Initialized
INFO - 2017-09-13 09:35:26 --> URI Class Initialized
INFO - 2017-09-13 09:35:26 --> Router Class Initialized
INFO - 2017-09-13 09:35:26 --> Output Class Initialized
INFO - 2017-09-13 09:35:26 --> Security Class Initialized
DEBUG - 2017-09-13 09:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-13 09:35:26 --> Input Class Initialized
INFO - 2017-09-13 09:35:26 --> Language Class Initialized
INFO - 2017-09-13 09:35:26 --> Loader Class Initialized
INFO - 2017-09-13 09:35:26 --> Helper loaded: url_helper
INFO - 2017-09-13 09:35:26 --> Database Driver Class Initialized
INFO - 2017-09-13 09:35:26 --> Email Class Initialized
INFO - 2017-09-13 09:35:26 --> Controller Class Initialized
DEBUG - 2017-09-13 09:35:26 --> Config file loaded: C:\xampp\htdocs\api\franknco\franknco\application\config/rest.php
INFO - 2017-09-13 09:35:26 --> Helper loaded: inflector_helper
INFO - 2017-09-13 09:35:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-13 09:35:26 --> Helper loaded: log_helper
INFO - 2017-09-13 09:35:26 --> Model Class Initialized
ERROR - 2017-09-13 14:35:26 --> Severity: Notice --> Undefined index: code C:\xampp\htdocs\api\franknco\franknco\application\controllers\api\franknco_api.php 39
INFO - 2017-09-13 14:35:26 --> Final output sent to browser
DEBUG - 2017-09-13 14:35:26 --> Total execution time: 0.3920
INFO - 2017-09-13 09:36:24 --> Config Class Initialized
INFO - 2017-09-13 09:36:24 --> Hooks Class Initialized
DEBUG - 2017-09-13 09:36:24 --> UTF-8 Support Enabled
INFO - 2017-09-13 09:36:24 --> Utf8 Class Initialized
INFO - 2017-09-13 09:36:24 --> URI Class Initialized
INFO - 2017-09-13 09:36:24 --> Router Class Initialized
INFO - 2017-09-13 09:36:24 --> Output Class Initialized
INFO - 2017-09-13 09:36:24 --> Security Class Initialized
DEBUG - 2017-09-13 09:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-13 09:36:24 --> Input Class Initialized
INFO - 2017-09-13 09:36:24 --> Language Class Initialized
INFO - 2017-09-13 09:36:24 --> Loader Class Initialized
INFO - 2017-09-13 09:36:24 --> Helper loaded: url_helper
INFO - 2017-09-13 09:36:24 --> Database Driver Class Initialized
INFO - 2017-09-13 09:36:24 --> Email Class Initialized
INFO - 2017-09-13 09:36:24 --> Controller Class Initialized
DEBUG - 2017-09-13 09:36:24 --> Config file loaded: C:\xampp\htdocs\api\franknco\franknco\application\config/rest.php
INFO - 2017-09-13 09:36:24 --> Helper loaded: inflector_helper
INFO - 2017-09-13 09:36:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-13 09:36:24 --> Helper loaded: log_helper
INFO - 2017-09-13 09:36:24 --> Model Class Initialized
ERROR - 2017-09-13 14:36:24 --> Severity: Notice --> Undefined index: code C:\xampp\htdocs\api\franknco\franknco\application\controllers\api\franknco_api.php 39
INFO - 2017-09-13 14:36:24 --> Final output sent to browser
DEBUG - 2017-09-13 14:36:24 --> Total execution time: 0.3860
INFO - 2017-09-13 09:44:10 --> Config Class Initialized
INFO - 2017-09-13 09:44:10 --> Hooks Class Initialized
DEBUG - 2017-09-13 09:44:10 --> UTF-8 Support Enabled
INFO - 2017-09-13 09:44:10 --> Utf8 Class Initialized
INFO - 2017-09-13 09:44:10 --> URI Class Initialized
INFO - 2017-09-13 09:44:10 --> Router Class Initialized
INFO - 2017-09-13 09:44:10 --> Output Class Initialized
INFO - 2017-09-13 09:44:10 --> Security Class Initialized
DEBUG - 2017-09-13 09:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-13 09:44:10 --> Input Class Initialized
INFO - 2017-09-13 09:44:10 --> Language Class Initialized
INFO - 2017-09-13 09:44:10 --> Loader Class Initialized
INFO - 2017-09-13 09:44:10 --> Helper loaded: url_helper
INFO - 2017-09-13 09:44:10 --> Database Driver Class Initialized
INFO - 2017-09-13 09:44:10 --> Email Class Initialized
INFO - 2017-09-13 09:44:10 --> Controller Class Initialized
DEBUG - 2017-09-13 09:44:10 --> Config file loaded: C:\xampp\htdocs\api\franknco\franknco\application\config/rest.php
INFO - 2017-09-13 09:44:10 --> Helper loaded: inflector_helper
INFO - 2017-09-13 09:44:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-13 09:44:10 --> Helper loaded: log_helper
INFO - 2017-09-13 09:44:11 --> Model Class Initialized
INFO - 2017-09-13 14:44:11 --> Final output sent to browser
DEBUG - 2017-09-13 14:44:11 --> Total execution time: 0.6240
INFO - 2017-09-13 09:44:13 --> Config Class Initialized
INFO - 2017-09-13 09:44:13 --> Hooks Class Initialized
DEBUG - 2017-09-13 09:44:13 --> UTF-8 Support Enabled
INFO - 2017-09-13 09:44:13 --> Utf8 Class Initialized
INFO - 2017-09-13 09:44:13 --> URI Class Initialized
INFO - 2017-09-13 09:44:13 --> Router Class Initialized
INFO - 2017-09-13 09:44:13 --> Output Class Initialized
INFO - 2017-09-13 09:44:13 --> Security Class Initialized
DEBUG - 2017-09-13 09:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-13 09:44:13 --> Input Class Initialized
INFO - 2017-09-13 09:44:13 --> Language Class Initialized
INFO - 2017-09-13 09:44:13 --> Loader Class Initialized
INFO - 2017-09-13 09:44:13 --> Helper loaded: url_helper
INFO - 2017-09-13 09:44:13 --> Database Driver Class Initialized
INFO - 2017-09-13 09:44:13 --> Email Class Initialized
INFO - 2017-09-13 09:44:13 --> Controller Class Initialized
DEBUG - 2017-09-13 09:44:13 --> Config file loaded: C:\xampp\htdocs\api\franknco\franknco\application\config/rest.php
INFO - 2017-09-13 09:44:13 --> Helper loaded: inflector_helper
INFO - 2017-09-13 09:44:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-13 09:44:13 --> Helper loaded: log_helper
INFO - 2017-09-13 09:44:13 --> Model Class Initialized
INFO - 2017-09-13 14:44:13 --> Final output sent to browser
DEBUG - 2017-09-13 14:44:13 --> Total execution time: 0.4830
INFO - 2017-09-13 09:44:15 --> Config Class Initialized
INFO - 2017-09-13 09:44:15 --> Hooks Class Initialized
DEBUG - 2017-09-13 09:44:15 --> UTF-8 Support Enabled
INFO - 2017-09-13 09:44:15 --> Utf8 Class Initialized
INFO - 2017-09-13 09:44:15 --> URI Class Initialized
INFO - 2017-09-13 09:44:15 --> Router Class Initialized
INFO - 2017-09-13 09:44:15 --> Output Class Initialized
INFO - 2017-09-13 09:44:15 --> Security Class Initialized
DEBUG - 2017-09-13 09:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-13 09:44:16 --> Input Class Initialized
INFO - 2017-09-13 09:44:16 --> Language Class Initialized
INFO - 2017-09-13 09:44:16 --> Loader Class Initialized
INFO - 2017-09-13 09:44:16 --> Helper loaded: url_helper
INFO - 2017-09-13 09:44:16 --> Database Driver Class Initialized
INFO - 2017-09-13 09:44:16 --> Email Class Initialized
INFO - 2017-09-13 09:44:16 --> Controller Class Initialized
DEBUG - 2017-09-13 09:44:16 --> Config file loaded: C:\xampp\htdocs\api\franknco\franknco\application\config/rest.php
INFO - 2017-09-13 09:44:16 --> Helper loaded: inflector_helper
INFO - 2017-09-13 09:44:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-13 09:44:16 --> Helper loaded: log_helper
INFO - 2017-09-13 09:44:16 --> Model Class Initialized
ERROR - 2017-09-13 14:44:16 --> Severity: Notice --> Undefined index: code C:\xampp\htdocs\api\franknco\franknco\application\controllers\api\franknco_api.php 39
INFO - 2017-09-13 14:44:16 --> Final output sent to browser
DEBUG - 2017-09-13 14:44:16 --> Total execution time: 0.4360
INFO - 2017-09-13 09:44:27 --> Config Class Initialized
INFO - 2017-09-13 09:44:27 --> Hooks Class Initialized
DEBUG - 2017-09-13 09:44:27 --> UTF-8 Support Enabled
INFO - 2017-09-13 09:44:27 --> Utf8 Class Initialized
INFO - 2017-09-13 09:44:27 --> URI Class Initialized
INFO - 2017-09-13 09:44:27 --> Router Class Initialized
INFO - 2017-09-13 09:44:27 --> Output Class Initialized
INFO - 2017-09-13 09:44:27 --> Security Class Initialized
DEBUG - 2017-09-13 09:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-13 09:44:27 --> Input Class Initialized
INFO - 2017-09-13 09:44:27 --> Language Class Initialized
INFO - 2017-09-13 09:44:27 --> Loader Class Initialized
INFO - 2017-09-13 09:44:28 --> Helper loaded: url_helper
INFO - 2017-09-13 09:44:28 --> Database Driver Class Initialized
INFO - 2017-09-13 09:44:28 --> Email Class Initialized
INFO - 2017-09-13 09:44:28 --> Controller Class Initialized
DEBUG - 2017-09-13 09:44:28 --> Config file loaded: C:\xampp\htdocs\api\franknco\franknco\application\config/rest.php
INFO - 2017-09-13 09:44:28 --> Helper loaded: inflector_helper
INFO - 2017-09-13 09:44:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-13 09:44:28 --> Helper loaded: log_helper
INFO - 2017-09-13 09:44:28 --> Model Class Initialized
INFO - 2017-09-13 14:44:28 --> Final output sent to browser
DEBUG - 2017-09-13 14:44:28 --> Total execution time: 0.5330
INFO - 2017-09-13 09:44:57 --> Config Class Initialized
INFO - 2017-09-13 09:44:57 --> Hooks Class Initialized
DEBUG - 2017-09-13 09:44:57 --> UTF-8 Support Enabled
INFO - 2017-09-13 09:44:57 --> Utf8 Class Initialized
INFO - 2017-09-13 09:44:57 --> URI Class Initialized
INFO - 2017-09-13 09:44:57 --> Router Class Initialized
INFO - 2017-09-13 09:44:57 --> Output Class Initialized
INFO - 2017-09-13 09:44:57 --> Security Class Initialized
DEBUG - 2017-09-13 09:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-13 09:44:57 --> Input Class Initialized
INFO - 2017-09-13 09:44:57 --> Language Class Initialized
INFO - 2017-09-13 09:44:57 --> Loader Class Initialized
INFO - 2017-09-13 09:44:57 --> Helper loaded: url_helper
INFO - 2017-09-13 09:44:57 --> Database Driver Class Initialized
INFO - 2017-09-13 09:44:57 --> Email Class Initialized
INFO - 2017-09-13 09:44:57 --> Controller Class Initialized
DEBUG - 2017-09-13 09:44:58 --> Config file loaded: C:\xampp\htdocs\api\franknco\franknco\application\config/rest.php
INFO - 2017-09-13 09:44:58 --> Helper loaded: inflector_helper
INFO - 2017-09-13 09:44:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-13 09:44:58 --> Helper loaded: log_helper
INFO - 2017-09-13 09:44:58 --> Model Class Initialized
INFO - 2017-09-13 14:44:58 --> Final output sent to browser
DEBUG - 2017-09-13 14:44:58 --> Total execution time: 0.4860
INFO - 2017-09-13 10:15:34 --> Config Class Initialized
INFO - 2017-09-13 10:15:34 --> Hooks Class Initialized
DEBUG - 2017-09-13 10:15:34 --> UTF-8 Support Enabled
INFO - 2017-09-13 10:15:34 --> Utf8 Class Initialized
INFO - 2017-09-13 10:15:35 --> URI Class Initialized
INFO - 2017-09-13 10:15:35 --> Router Class Initialized
INFO - 2017-09-13 10:15:35 --> Output Class Initialized
INFO - 2017-09-13 10:15:35 --> Security Class Initialized
DEBUG - 2017-09-13 10:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-13 10:15:35 --> Input Class Initialized
INFO - 2017-09-13 10:15:35 --> Language Class Initialized
INFO - 2017-09-13 10:15:35 --> Loader Class Initialized
INFO - 2017-09-13 10:15:35 --> Helper loaded: url_helper
INFO - 2017-09-13 10:15:35 --> Database Driver Class Initialized
INFO - 2017-09-13 10:15:35 --> Email Class Initialized
INFO - 2017-09-13 10:15:35 --> Controller Class Initialized
DEBUG - 2017-09-13 10:15:35 --> Config file loaded: C:\xampp\htdocs\api\franknco\franknco\application\config/rest.php
INFO - 2017-09-13 10:15:35 --> Helper loaded: inflector_helper
INFO - 2017-09-13 10:15:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-13 10:15:35 --> Helper loaded: log_helper
INFO - 2017-09-13 10:15:35 --> Model Class Initialized
INFO - 2017-09-13 15:15:35 --> Final output sent to browser
DEBUG - 2017-09-13 15:15:35 --> Total execution time: 0.5370
INFO - 2017-09-13 10:50:14 --> Config Class Initialized
INFO - 2017-09-13 10:50:14 --> Hooks Class Initialized
DEBUG - 2017-09-13 10:50:14 --> UTF-8 Support Enabled
INFO - 2017-09-13 10:50:14 --> Utf8 Class Initialized
INFO - 2017-09-13 10:50:14 --> URI Class Initialized
INFO - 2017-09-13 10:50:14 --> Router Class Initialized
INFO - 2017-09-13 10:50:14 --> Output Class Initialized
INFO - 2017-09-13 10:50:14 --> Security Class Initialized
DEBUG - 2017-09-13 10:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-13 10:50:14 --> Input Class Initialized
INFO - 2017-09-13 10:50:14 --> Language Class Initialized
INFO - 2017-09-13 10:50:14 --> Loader Class Initialized
INFO - 2017-09-13 10:50:14 --> Helper loaded: url_helper
INFO - 2017-09-13 10:50:14 --> Database Driver Class Initialized
INFO - 2017-09-13 10:50:14 --> Email Class Initialized
INFO - 2017-09-13 10:50:14 --> Controller Class Initialized
DEBUG - 2017-09-13 10:50:14 --> Config file loaded: C:\xampp\htdocs\api\franknco\franknco\application\config/rest.php
INFO - 2017-09-13 10:50:14 --> Helper loaded: inflector_helper
INFO - 2017-09-13 10:50:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-13 10:50:14 --> Helper loaded: log_helper
INFO - 2017-09-13 10:50:14 --> Model Class Initialized
INFO - 2017-09-13 15:50:15 --> Final output sent to browser
DEBUG - 2017-09-13 15:50:15 --> Total execution time: 1.2322
INFO - 2017-09-13 14:21:19 --> Config Class Initialized
INFO - 2017-09-13 14:21:19 --> Hooks Class Initialized
DEBUG - 2017-09-13 14:21:20 --> UTF-8 Support Enabled
INFO - 2017-09-13 14:21:20 --> Utf8 Class Initialized
INFO - 2017-09-13 14:21:20 --> URI Class Initialized
INFO - 2017-09-13 14:21:20 --> Router Class Initialized
INFO - 2017-09-13 14:21:20 --> Output Class Initialized
INFO - 2017-09-13 14:21:20 --> Security Class Initialized
DEBUG - 2017-09-13 14:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-13 14:21:20 --> Input Class Initialized
INFO - 2017-09-13 14:21:20 --> Language Class Initialized
INFO - 2017-09-13 14:21:21 --> Loader Class Initialized
INFO - 2017-09-13 14:21:21 --> Helper loaded: url_helper
INFO - 2017-09-13 14:21:21 --> Database Driver Class Initialized
INFO - 2017-09-13 14:21:21 --> Email Class Initialized
INFO - 2017-09-13 14:21:21 --> Controller Class Initialized
DEBUG - 2017-09-13 14:21:21 --> Config file loaded: C:\xampp\htdocs\api\franknco\franknco\application\config/rest.php
INFO - 2017-09-13 14:21:21 --> Helper loaded: inflector_helper
INFO - 2017-09-13 14:21:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-13 14:21:21 --> Helper loaded: log_helper
INFO - 2017-09-13 14:21:22 --> Model Class Initialized
INFO - 2017-09-13 19:21:22 --> Final output sent to browser
DEBUG - 2017-09-13 19:21:22 --> Total execution time: 2.6938
INFO - 2017-09-13 14:22:17 --> Config Class Initialized
INFO - 2017-09-13 14:22:17 --> Hooks Class Initialized
DEBUG - 2017-09-13 14:22:17 --> UTF-8 Support Enabled
INFO - 2017-09-13 14:22:17 --> Utf8 Class Initialized
INFO - 2017-09-13 14:22:17 --> URI Class Initialized
INFO - 2017-09-13 14:22:17 --> Router Class Initialized
INFO - 2017-09-13 14:22:17 --> Output Class Initialized
INFO - 2017-09-13 14:22:17 --> Security Class Initialized
DEBUG - 2017-09-13 14:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-13 14:22:17 --> Input Class Initialized
INFO - 2017-09-13 14:22:17 --> Language Class Initialized
INFO - 2017-09-13 14:22:17 --> Loader Class Initialized
INFO - 2017-09-13 14:22:17 --> Helper loaded: url_helper
INFO - 2017-09-13 14:22:17 --> Database Driver Class Initialized
INFO - 2017-09-13 14:22:17 --> Email Class Initialized
INFO - 2017-09-13 14:22:17 --> Controller Class Initialized
DEBUG - 2017-09-13 14:22:17 --> Config file loaded: C:\xampp\htdocs\api\franknco\franknco\application\config/rest.php
INFO - 2017-09-13 14:22:17 --> Helper loaded: inflector_helper
INFO - 2017-09-13 14:22:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-13 14:22:17 --> Helper loaded: log_helper
INFO - 2017-09-13 14:22:17 --> Model Class Initialized
INFO - 2017-09-13 19:22:17 --> Final output sent to browser
DEBUG - 2017-09-13 19:22:17 --> Total execution time: 0.3926
INFO - 2017-09-13 14:24:38 --> Config Class Initialized
INFO - 2017-09-13 14:24:38 --> Hooks Class Initialized
DEBUG - 2017-09-13 14:24:38 --> UTF-8 Support Enabled
INFO - 2017-09-13 14:24:38 --> Utf8 Class Initialized
INFO - 2017-09-13 14:24:38 --> URI Class Initialized
INFO - 2017-09-13 14:24:38 --> Router Class Initialized
INFO - 2017-09-13 14:24:38 --> Output Class Initialized
INFO - 2017-09-13 14:24:38 --> Security Class Initialized
DEBUG - 2017-09-13 14:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-13 14:24:38 --> Input Class Initialized
INFO - 2017-09-13 14:24:38 --> Language Class Initialized
INFO - 2017-09-13 14:24:38 --> Loader Class Initialized
INFO - 2017-09-13 14:24:38 --> Helper loaded: url_helper
INFO - 2017-09-13 14:24:38 --> Database Driver Class Initialized
INFO - 2017-09-13 14:24:38 --> Email Class Initialized
INFO - 2017-09-13 14:24:38 --> Controller Class Initialized
DEBUG - 2017-09-13 14:24:38 --> Config file loaded: C:\xampp\htdocs\api\franknco\franknco\application\config/rest.php
INFO - 2017-09-13 14:24:38 --> Helper loaded: inflector_helper
INFO - 2017-09-13 14:24:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-13 14:24:38 --> Helper loaded: log_helper
INFO - 2017-09-13 14:24:38 --> Model Class Initialized
INFO - 2017-09-13 19:24:38 --> Final output sent to browser
DEBUG - 2017-09-13 19:24:38 --> Total execution time: 0.3550
INFO - 2017-09-13 16:10:12 --> Config Class Initialized
INFO - 2017-09-13 16:10:12 --> Hooks Class Initialized
DEBUG - 2017-09-13 16:10:12 --> UTF-8 Support Enabled
INFO - 2017-09-13 16:10:12 --> Utf8 Class Initialized
INFO - 2017-09-13 16:10:12 --> URI Class Initialized
INFO - 2017-09-13 16:10:12 --> Router Class Initialized
INFO - 2017-09-13 16:10:12 --> Output Class Initialized
INFO - 2017-09-13 16:10:13 --> Security Class Initialized
DEBUG - 2017-09-13 16:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-13 16:10:13 --> Input Class Initialized
INFO - 2017-09-13 16:10:13 --> Language Class Initialized
INFO - 2017-09-13 16:10:13 --> Loader Class Initialized
INFO - 2017-09-13 16:10:13 --> Helper loaded: url_helper
INFO - 2017-09-13 16:10:14 --> Database Driver Class Initialized
INFO - 2017-09-13 16:10:14 --> Email Class Initialized
INFO - 2017-09-13 16:10:14 --> Controller Class Initialized
DEBUG - 2017-09-13 16:10:14 --> Config file loaded: C:\xampp\htdocs\api\franknco\franknco\application\config/rest.php
INFO - 2017-09-13 16:10:14 --> Helper loaded: inflector_helper
INFO - 2017-09-13 16:10:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-13 16:10:14 --> Helper loaded: log_helper
INFO - 2017-09-13 16:10:14 --> Model Class Initialized
ERROR - 2017-09-13 21:10:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '?vmOR6?)??.+1??߲????WF?N?j_?7'y??@a??????ϝ??.?w?L=??ޤ}?x";Card Number:s:16:' at line 1 - Invalid query: insert into logging_api(user,action,data,last_log_timestamp) values ('Z�n��*[%��T��<','SIGN UP','Init Hit Data User:s:16:"Z�n��*[%��T��<";Password:s:72:"�Щ/Zc�'�vmOR6�)��.+1��߲����WF�N�j_�7'y��@a������ϝ��.�w�L=��ޤ}�x";Card Number:s:16:"P;��4VZH�j19�";Fullname:s:8:"i�����";DOB:s:10:"1994-02-26";Address:s:8:"����-)�";Email:s:16:"T���HDd���ۢ";',now())
INFO - 2017-09-13 21:10:14 --> Language file loaded: language/english/db_lang.php
INFO - 2017-09-13 16:10:53 --> Config Class Initialized
INFO - 2017-09-13 16:10:53 --> Hooks Class Initialized
DEBUG - 2017-09-13 16:10:53 --> UTF-8 Support Enabled
INFO - 2017-09-13 16:10:53 --> Utf8 Class Initialized
INFO - 2017-09-13 16:10:53 --> URI Class Initialized
INFO - 2017-09-13 16:10:53 --> Router Class Initialized
INFO - 2017-09-13 16:10:53 --> Output Class Initialized
INFO - 2017-09-13 16:10:53 --> Security Class Initialized
DEBUG - 2017-09-13 16:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-13 16:10:53 --> Input Class Initialized
INFO - 2017-09-13 16:10:53 --> Language Class Initialized
INFO - 2017-09-13 16:10:53 --> Loader Class Initialized
INFO - 2017-09-13 16:10:53 --> Helper loaded: url_helper
INFO - 2017-09-13 16:10:53 --> Database Driver Class Initialized
INFO - 2017-09-13 16:10:53 --> Email Class Initialized
INFO - 2017-09-13 16:10:53 --> Controller Class Initialized
DEBUG - 2017-09-13 16:10:53 --> Config file loaded: C:\xampp\htdocs\api\franknco\franknco\application\config/rest.php
INFO - 2017-09-13 16:10:53 --> Helper loaded: inflector_helper
INFO - 2017-09-13 16:10:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-13 16:10:53 --> Helper loaded: log_helper
INFO - 2017-09-13 16:10:53 --> Model Class Initialized
ERROR - 2017-09-13 21:10:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '?vmOR6?)??.+1??߲????WF?N?j_?7'y??@a??????ϝ??.?w?L=??ޤ}?x";Card Number:s:16:' at line 1 - Invalid query: insert into logging_api(user,action,data,last_log_timestamp) values ('Z�n��*[%��T��<','SIGN UP','Init Hit Data User:s:16:"Z�n��*[%��T��<";Password:s:72:"�Щ/Zc�'�vmOR6�)��.+1��߲����WF�N�j_�7'y��@a������ϝ��.�w�L=��ޤ}�x";Card Number:s:16:"P;��4VZH�j19�";Fullname:s:8:"i�����";DOB:s:10:"1994-02-26";Address:s:8:"����-)�";Email:s:16:"T���HDd���ۢ";',now())
INFO - 2017-09-13 21:10:53 --> Language file loaded: language/english/db_lang.php
INFO - 2017-09-13 16:11:45 --> Config Class Initialized
INFO - 2017-09-13 16:11:45 --> Hooks Class Initialized
DEBUG - 2017-09-13 16:11:45 --> UTF-8 Support Enabled
INFO - 2017-09-13 16:11:45 --> Utf8 Class Initialized
INFO - 2017-09-13 16:11:45 --> URI Class Initialized
INFO - 2017-09-13 16:11:45 --> Router Class Initialized
INFO - 2017-09-13 16:11:45 --> Output Class Initialized
INFO - 2017-09-13 16:11:45 --> Security Class Initialized
DEBUG - 2017-09-13 16:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-13 16:11:45 --> Input Class Initialized
INFO - 2017-09-13 16:11:45 --> Language Class Initialized
INFO - 2017-09-13 16:11:45 --> Loader Class Initialized
INFO - 2017-09-13 16:11:45 --> Helper loaded: url_helper
INFO - 2017-09-13 16:11:45 --> Database Driver Class Initialized
INFO - 2017-09-13 16:11:45 --> Email Class Initialized
INFO - 2017-09-13 16:11:45 --> Controller Class Initialized
DEBUG - 2017-09-13 16:11:45 --> Config file loaded: C:\xampp\htdocs\api\franknco\franknco\application\config/rest.php
INFO - 2017-09-13 16:11:45 --> Helper loaded: inflector_helper
INFO - 2017-09-13 16:11:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-13 16:11:45 --> Helper loaded: log_helper
INFO - 2017-09-13 16:11:45 --> Model Class Initialized
ERROR - 2017-09-13 21:11:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '?vmOR6?)??.+1??߲????WF?N?j_?7'y??@a??????ϝ??.?w?L=??ޤ}?x";Card Number:s:16:' at line 1 - Invalid query: insert into logging_api(user,action,data,last_log_timestamp) values ('Z�n��*[%��T��<','SIGN UP','Init Hit Data User:s:16:"Z�n��*[%��T��<";Password:s:72:"�Щ/Zc�'�vmOR6�)��.+1��߲����WF�N�j_�7'y��@a������ϝ��.�w�L=��ޤ}�x";Card Number:s:16:"P;��4VZH�j19�";Fullname:s:8:"i�����";DOB:s:10:"1994-02-26";Address:s:8:"����-)�";Email:s:16:"T���HDd���ۢ";',now())
INFO - 2017-09-13 21:11:45 --> Language file loaded: language/english/db_lang.php
INFO - 2017-09-13 16:12:49 --> Config Class Initialized
INFO - 2017-09-13 16:12:49 --> Hooks Class Initialized
DEBUG - 2017-09-13 16:12:49 --> UTF-8 Support Enabled
INFO - 2017-09-13 16:12:49 --> Utf8 Class Initialized
INFO - 2017-09-13 16:12:49 --> URI Class Initialized
INFO - 2017-09-13 16:12:49 --> Router Class Initialized
INFO - 2017-09-13 16:12:49 --> Output Class Initialized
INFO - 2017-09-13 16:12:49 --> Security Class Initialized
DEBUG - 2017-09-13 16:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-13 16:12:49 --> Input Class Initialized
INFO - 2017-09-13 16:12:49 --> Language Class Initialized
INFO - 2017-09-13 16:12:49 --> Loader Class Initialized
INFO - 2017-09-13 16:12:49 --> Helper loaded: url_helper
INFO - 2017-09-13 16:12:49 --> Database Driver Class Initialized
INFO - 2017-09-13 16:12:49 --> Email Class Initialized
INFO - 2017-09-13 16:12:49 --> Controller Class Initialized
DEBUG - 2017-09-13 16:12:49 --> Config file loaded: C:\xampp\htdocs\api\franknco\franknco\application\config/rest.php
INFO - 2017-09-13 16:12:49 --> Helper loaded: inflector_helper
INFO - 2017-09-13 16:12:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-13 16:12:49 --> Helper loaded: log_helper
INFO - 2017-09-13 16:12:49 --> Model Class Initialized
ERROR - 2017-09-13 21:12:49 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '?vmOR6?)??.+1??߲????WF?N?j_?7'y??@a??????ϝ??.?w?L=??ޤ}?x";Card Number:s:16:' at line 1 - Invalid query: insert into logging_api(user,action,data,last_log_timestamp) values ('Z�n��*[%��T��<','SIGN UP','Init Hit Data User:s:16:"Z�n��*[%��T��<";Password:s:72:"�Щ/Zc�'�vmOR6�)��.+1��߲����WF�N�j_�7'y��@a������ϝ��.�w�L=��ޤ}�x";Card Number:s:16:"P;��4VZH�j19�";Fullname:s:8:"i�����";DOB:s:10:"1994-02-26";Address:s:8:"����-)�";Email:s:16:"T���HDd���ۢ";',now())
INFO - 2017-09-13 21:12:49 --> Language file loaded: language/english/db_lang.php
INFO - 2017-09-13 16:15:10 --> Config Class Initialized
INFO - 2017-09-13 16:15:10 --> Hooks Class Initialized
DEBUG - 2017-09-13 16:15:10 --> UTF-8 Support Enabled
INFO - 2017-09-13 16:15:10 --> Utf8 Class Initialized
INFO - 2017-09-13 16:15:10 --> URI Class Initialized
INFO - 2017-09-13 16:15:10 --> Router Class Initialized
INFO - 2017-09-13 16:15:10 --> Output Class Initialized
INFO - 2017-09-13 16:15:10 --> Security Class Initialized
DEBUG - 2017-09-13 16:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-13 16:15:10 --> Input Class Initialized
INFO - 2017-09-13 16:15:10 --> Language Class Initialized
INFO - 2017-09-13 16:15:10 --> Loader Class Initialized
INFO - 2017-09-13 16:15:10 --> Helper loaded: url_helper
INFO - 2017-09-13 16:15:10 --> Database Driver Class Initialized
INFO - 2017-09-13 16:15:10 --> Email Class Initialized
INFO - 2017-09-13 16:15:11 --> Controller Class Initialized
DEBUG - 2017-09-13 16:15:11 --> Config file loaded: C:\xampp\htdocs\api\franknco\franknco\application\config/rest.php
INFO - 2017-09-13 16:15:11 --> Helper loaded: inflector_helper
INFO - 2017-09-13 16:15:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-13 16:15:11 --> Helper loaded: log_helper
INFO - 2017-09-13 16:15:11 --> Model Class Initialized
ERROR - 2017-09-13 21:15:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '?s?Y";Email:s:24:"?
m*?ÐCN?,???dR?I???";',now())' at line 1 - Invalid query: insert into logging_api(user,action,data,last_log_timestamp) values ('Z�n��*[%��T��<','SIGN UP','Init Hit Data User:s:16:"Z�n��*[%��T��<";Password:s:72:"���Vʓ�����m�G4���P�-�"���7�ݯ�9�\�9���9rX�(bſE�,��a�@�B����";Card Number:s:16:"�ǻLp�!꼚��";Fullname:s:8:"i�����";DOB:s:10:"1994-02-26";Address:s:8:"�V'�s�Y";Email:s:24:"�
m*�ÐCN�,���dR�I���";',now())
INFO - 2017-09-13 21:15:11 --> Language file loaded: language/english/db_lang.php
INFO - 2017-09-13 16:16:15 --> Config Class Initialized
INFO - 2017-09-13 16:16:15 --> Hooks Class Initialized
DEBUG - 2017-09-13 16:16:15 --> UTF-8 Support Enabled
INFO - 2017-09-13 16:16:15 --> Utf8 Class Initialized
INFO - 2017-09-13 16:16:15 --> URI Class Initialized
INFO - 2017-09-13 16:16:15 --> Router Class Initialized
INFO - 2017-09-13 16:16:15 --> Output Class Initialized
INFO - 2017-09-13 16:16:15 --> Security Class Initialized
DEBUG - 2017-09-13 16:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-13 16:16:15 --> Input Class Initialized
INFO - 2017-09-13 16:16:15 --> Language Class Initialized
INFO - 2017-09-13 16:16:15 --> Loader Class Initialized
INFO - 2017-09-13 16:16:15 --> Helper loaded: url_helper
INFO - 2017-09-13 16:16:16 --> Database Driver Class Initialized
INFO - 2017-09-13 16:16:16 --> Email Class Initialized
INFO - 2017-09-13 16:16:16 --> Controller Class Initialized
DEBUG - 2017-09-13 16:16:16 --> Config file loaded: C:\xampp\htdocs\api\franknco\franknco\application\config/rest.php
INFO - 2017-09-13 16:16:16 --> Helper loaded: inflector_helper
INFO - 2017-09-13 16:16:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-13 16:16:16 --> Helper loaded: log_helper
INFO - 2017-09-13 16:16:16 --> Model Class Initialized
ERROR - 2017-09-13 21:16:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '?s?Y";Email:s:24:"?
m*?ÐCN?,???dR?I???";',now())' at line 1 - Invalid query: insert into logging_api(user,action,data,last_log_timestamp) values ('Z�n��*[%��T��<','SIGN UP','Init Hit Data User:s:16:"Z�n��*[%��T��<";Password:s:72:"���Vʓ�����m�G4���P�-�"���7�ݯ�9�\�9���9rX�(bſE�,��a�@�B����";Card Number:s:16:"�ǻLp�!꼚��";Fullname:s:8:"i�����";DOB:s:10:"1994-02-26";Address:s:8:"�V'�s�Y";Email:s:24:"�
m*�ÐCN�,���dR�I���";',now())
INFO - 2017-09-13 21:16:16 --> Language file loaded: language/english/db_lang.php
INFO - 2017-09-13 16:16:30 --> Config Class Initialized
INFO - 2017-09-13 16:16:30 --> Hooks Class Initialized
DEBUG - 2017-09-13 16:16:30 --> UTF-8 Support Enabled
INFO - 2017-09-13 16:16:30 --> Utf8 Class Initialized
INFO - 2017-09-13 16:16:30 --> URI Class Initialized
INFO - 2017-09-13 16:16:30 --> Router Class Initialized
INFO - 2017-09-13 16:16:30 --> Output Class Initialized
INFO - 2017-09-13 16:16:30 --> Security Class Initialized
DEBUG - 2017-09-13 16:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-13 16:16:30 --> Input Class Initialized
INFO - 2017-09-13 16:16:30 --> Language Class Initialized
INFO - 2017-09-13 16:16:30 --> Loader Class Initialized
INFO - 2017-09-13 16:16:30 --> Helper loaded: url_helper
INFO - 2017-09-13 16:16:30 --> Database Driver Class Initialized
INFO - 2017-09-13 16:16:30 --> Email Class Initialized
INFO - 2017-09-13 16:16:30 --> Controller Class Initialized
DEBUG - 2017-09-13 16:16:30 --> Config file loaded: C:\xampp\htdocs\api\franknco\franknco\application\config/rest.php
INFO - 2017-09-13 16:16:30 --> Helper loaded: inflector_helper
INFO - 2017-09-13 16:16:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-13 16:16:30 --> Helper loaded: log_helper
INFO - 2017-09-13 16:16:30 --> Model Class Initialized
ERROR - 2017-09-13 21:16:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '?s?Y";Email:s:24:"?
m*?ÐCN?,???dR?I???";',now())' at line 1 - Invalid query: insert into logging_api(user,action,data,last_log_timestamp) values ('Z�n��*[%��T��<','SIGN UP','Init Hit Data User:s:16:"Z�n��*[%��T��<";Password:s:72:"���Vʓ�����m�G4���P�-�"���7�ݯ�9�\�9���9rX�(bſE�,��a�@�B����";Card Number:s:16:"�ǻLp�!꼚��";Fullname:s:8:"i�����";DOB:s:10:"1994-02-26";Address:s:8:"�V'�s�Y";Email:s:24:"�
m*�ÐCN�,���dR�I���";',now())
INFO - 2017-09-13 21:16:30 --> Language file loaded: language/english/db_lang.php
INFO - 2017-09-13 16:17:14 --> Config Class Initialized
INFO - 2017-09-13 16:17:14 --> Hooks Class Initialized
DEBUG - 2017-09-13 16:17:14 --> UTF-8 Support Enabled
INFO - 2017-09-13 16:17:14 --> Utf8 Class Initialized
INFO - 2017-09-13 16:17:14 --> URI Class Initialized
INFO - 2017-09-13 16:17:14 --> Router Class Initialized
INFO - 2017-09-13 16:17:14 --> Output Class Initialized
INFO - 2017-09-13 16:17:14 --> Security Class Initialized
DEBUG - 2017-09-13 16:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-13 16:17:14 --> Input Class Initialized
INFO - 2017-09-13 16:17:14 --> Language Class Initialized
INFO - 2017-09-13 16:17:14 --> Loader Class Initialized
INFO - 2017-09-13 16:17:14 --> Helper loaded: url_helper
INFO - 2017-09-13 16:17:14 --> Database Driver Class Initialized
INFO - 2017-09-13 16:17:14 --> Email Class Initialized
INFO - 2017-09-13 16:17:14 --> Controller Class Initialized
DEBUG - 2017-09-13 16:17:14 --> Config file loaded: C:\xampp\htdocs\api\franknco\franknco\application\config/rest.php
INFO - 2017-09-13 16:17:14 --> Helper loaded: inflector_helper
INFO - 2017-09-13 16:17:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-13 16:17:14 --> Helper loaded: log_helper
INFO - 2017-09-13 16:17:14 --> Model Class Initialized
INFO - 2017-09-13 21:17:14 --> Final output sent to browser
DEBUG - 2017-09-13 21:17:14 --> Total execution time: 0.3710
INFO - 2017-09-13 16:17:21 --> Config Class Initialized
INFO - 2017-09-13 16:17:21 --> Hooks Class Initialized
DEBUG - 2017-09-13 16:17:21 --> UTF-8 Support Enabled
INFO - 2017-09-13 16:17:21 --> Utf8 Class Initialized
INFO - 2017-09-13 16:17:21 --> URI Class Initialized
INFO - 2017-09-13 16:17:21 --> Router Class Initialized
INFO - 2017-09-13 16:17:21 --> Output Class Initialized
INFO - 2017-09-13 16:17:21 --> Security Class Initialized
DEBUG - 2017-09-13 16:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-13 16:17:21 --> Input Class Initialized
INFO - 2017-09-13 16:17:21 --> Language Class Initialized
INFO - 2017-09-13 16:17:21 --> Loader Class Initialized
INFO - 2017-09-13 16:17:21 --> Helper loaded: url_helper
INFO - 2017-09-13 16:17:21 --> Database Driver Class Initialized
INFO - 2017-09-13 16:17:21 --> Email Class Initialized
INFO - 2017-09-13 16:17:21 --> Controller Class Initialized
DEBUG - 2017-09-13 16:17:21 --> Config file loaded: C:\xampp\htdocs\api\franknco\franknco\application\config/rest.php
INFO - 2017-09-13 16:17:21 --> Helper loaded: inflector_helper
INFO - 2017-09-13 16:17:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-13 16:17:21 --> Helper loaded: log_helper
INFO - 2017-09-13 16:17:21 --> Model Class Initialized
INFO - 2017-09-13 21:17:21 --> Final output sent to browser
DEBUG - 2017-09-13 21:17:21 --> Total execution time: 0.3720
INFO - 2017-09-13 16:18:06 --> Config Class Initialized
INFO - 2017-09-13 16:18:06 --> Hooks Class Initialized
DEBUG - 2017-09-13 16:18:06 --> UTF-8 Support Enabled
INFO - 2017-09-13 16:18:06 --> Utf8 Class Initialized
INFO - 2017-09-13 16:18:06 --> URI Class Initialized
INFO - 2017-09-13 16:18:06 --> Router Class Initialized
INFO - 2017-09-13 16:18:06 --> Output Class Initialized
INFO - 2017-09-13 16:18:06 --> Security Class Initialized
DEBUG - 2017-09-13 16:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-13 16:18:06 --> Input Class Initialized
INFO - 2017-09-13 16:18:06 --> Language Class Initialized
INFO - 2017-09-13 16:18:06 --> Loader Class Initialized
INFO - 2017-09-13 16:18:06 --> Helper loaded: url_helper
INFO - 2017-09-13 16:18:06 --> Database Driver Class Initialized
INFO - 2017-09-13 16:18:06 --> Email Class Initialized
INFO - 2017-09-13 16:18:06 --> Controller Class Initialized
DEBUG - 2017-09-13 16:18:06 --> Config file loaded: C:\xampp\htdocs\api\franknco\franknco\application\config/rest.php
INFO - 2017-09-13 16:18:06 --> Helper loaded: inflector_helper
INFO - 2017-09-13 16:18:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-13 16:18:06 --> Helper loaded: log_helper
INFO - 2017-09-13 16:18:06 --> Model Class Initialized
INFO - 2017-09-13 21:18:06 --> Final output sent to browser
DEBUG - 2017-09-13 21:18:06 --> Total execution time: 0.3650
INFO - 2017-09-13 16:18:39 --> Config Class Initialized
INFO - 2017-09-13 16:18:39 --> Hooks Class Initialized
DEBUG - 2017-09-13 16:18:39 --> UTF-8 Support Enabled
INFO - 2017-09-13 16:18:39 --> Utf8 Class Initialized
INFO - 2017-09-13 16:18:39 --> URI Class Initialized
INFO - 2017-09-13 16:18:39 --> Router Class Initialized
INFO - 2017-09-13 16:18:39 --> Output Class Initialized
INFO - 2017-09-13 16:18:39 --> Security Class Initialized
DEBUG - 2017-09-13 16:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-13 16:18:39 --> Input Class Initialized
INFO - 2017-09-13 16:18:39 --> Language Class Initialized
INFO - 2017-09-13 16:18:39 --> Loader Class Initialized
INFO - 2017-09-13 16:18:39 --> Helper loaded: url_helper
INFO - 2017-09-13 16:18:39 --> Database Driver Class Initialized
INFO - 2017-09-13 16:18:39 --> Email Class Initialized
INFO - 2017-09-13 16:18:39 --> Controller Class Initialized
DEBUG - 2017-09-13 16:18:39 --> Config file loaded: C:\xampp\htdocs\api\franknco\franknco\application\config/rest.php
INFO - 2017-09-13 16:18:39 --> Helper loaded: inflector_helper
INFO - 2017-09-13 16:18:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-13 16:18:39 --> Helper loaded: log_helper
INFO - 2017-09-13 16:18:39 --> Model Class Initialized
INFO - 2017-09-13 21:18:39 --> Final output sent to browser
DEBUG - 2017-09-13 21:18:39 --> Total execution time: 0.3570
INFO - 2017-09-13 16:52:14 --> Config Class Initialized
INFO - 2017-09-13 16:52:14 --> Hooks Class Initialized
DEBUG - 2017-09-13 16:52:14 --> UTF-8 Support Enabled
INFO - 2017-09-13 16:52:14 --> Utf8 Class Initialized
INFO - 2017-09-13 16:52:14 --> URI Class Initialized
INFO - 2017-09-13 16:52:15 --> Router Class Initialized
INFO - 2017-09-13 16:52:15 --> Output Class Initialized
INFO - 2017-09-13 16:52:15 --> Security Class Initialized
DEBUG - 2017-09-13 16:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-13 16:52:15 --> Input Class Initialized
INFO - 2017-09-13 16:52:15 --> Language Class Initialized
INFO - 2017-09-13 16:52:15 --> Loader Class Initialized
INFO - 2017-09-13 16:52:16 --> Helper loaded: url_helper
INFO - 2017-09-13 16:52:16 --> Database Driver Class Initialized
INFO - 2017-09-13 16:52:16 --> Email Class Initialized
INFO - 2017-09-13 16:52:16 --> Controller Class Initialized
DEBUG - 2017-09-13 16:52:16 --> Config file loaded: C:\xampp\htdocs\api\franknco\franknco\application\config/rest.php
INFO - 2017-09-13 16:52:16 --> Helper loaded: inflector_helper
INFO - 2017-09-13 16:52:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-13 16:52:16 --> Helper loaded: log_helper
INFO - 2017-09-13 16:52:16 --> Model Class Initialized
ERROR - 2017-09-13 21:52:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '?vmOR6?)??.+1??߲????WF?N?j_?7'y??@a??????ϝ??.?w?L=??ޤ}?x";Card Number:s:16:' at line 1 - Invalid query: insert into logging_api(user,action,data,last_log_timestamp) values ('Z�n��*[%��T��<','SIGN UP','Init Hit Data User:s:16:"Z�n��*[%��T��<";Password:s:72:"�Щ/Zc�'�vmOR6�)��.+1��߲����WF�N�j_�7'y��@a������ϝ��.�w�L=��ޤ}�x";Card Number:s:16:"P;��4VZHJ��(��";Fullname:s:8:"i�����";DOB:s:10:"1994-02-26";Address:s:7:"�>�mt�";Email:s:16:"�
m*�â/g&�n`";',now())
INFO - 2017-09-13 21:52:16 --> Language file loaded: language/english/db_lang.php
INFO - 2017-09-13 16:53:31 --> Config Class Initialized
INFO - 2017-09-13 16:53:31 --> Hooks Class Initialized
DEBUG - 2017-09-13 16:53:31 --> UTF-8 Support Enabled
INFO - 2017-09-13 16:53:31 --> Utf8 Class Initialized
INFO - 2017-09-13 16:53:31 --> URI Class Initialized
INFO - 2017-09-13 16:53:31 --> Router Class Initialized
INFO - 2017-09-13 16:53:31 --> Output Class Initialized
INFO - 2017-09-13 16:53:31 --> Security Class Initialized
DEBUG - 2017-09-13 16:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-13 16:53:31 --> Input Class Initialized
INFO - 2017-09-13 16:53:31 --> Language Class Initialized
INFO - 2017-09-13 16:53:31 --> Loader Class Initialized
INFO - 2017-09-13 16:53:31 --> Helper loaded: url_helper
INFO - 2017-09-13 16:53:31 --> Database Driver Class Initialized
INFO - 2017-09-13 16:53:31 --> Email Class Initialized
INFO - 2017-09-13 16:53:31 --> Controller Class Initialized
DEBUG - 2017-09-13 16:53:31 --> Config file loaded: C:\xampp\htdocs\api\franknco\franknco\application\config/rest.php
INFO - 2017-09-13 16:53:31 --> Helper loaded: inflector_helper
INFO - 2017-09-13 16:53:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-13 16:53:31 --> Helper loaded: log_helper
INFO - 2017-09-13 16:53:31 --> Model Class Initialized
ERROR - 2017-09-13 21:53:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '?vmOR6?)??.+1??߲????WF?N?j_?7'y??@a??????ϝ??.?w?L=??ޤ}?x";Card Number:s:16:' at line 1 - Invalid query: insert into logging_api(user,action,data,last_log_timestamp) values ('Z�n��*[%��T��<','SIGN UP','Init Hit Data User:s:16:"Z�n��*[%��T��<";Password:s:72:"�Щ/Zc�'�vmOR6�)��.+1��߲����WF�N�j_�7'y��@a������ϝ��.�w�L=��ޤ}�x";Card Number:s:16:"P;��4VZHJ��(��";Fullname:s:8:"i�����";DOB:s:10:"1994-02-26";Address:s:7:"�>�mt�";Email:s:16:"�
m*�â/g&�n`";',now())
INFO - 2017-09-13 21:53:31 --> Language file loaded: language/english/db_lang.php
INFO - 2017-09-13 17:01:20 --> Config Class Initialized
INFO - 2017-09-13 17:01:20 --> Hooks Class Initialized
DEBUG - 2017-09-13 17:01:20 --> UTF-8 Support Enabled
INFO - 2017-09-13 17:01:20 --> Utf8 Class Initialized
INFO - 2017-09-13 17:01:20 --> URI Class Initialized
INFO - 2017-09-13 17:01:20 --> Router Class Initialized
INFO - 2017-09-13 17:01:20 --> Output Class Initialized
INFO - 2017-09-13 17:01:20 --> Security Class Initialized
DEBUG - 2017-09-13 17:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-13 17:01:20 --> Input Class Initialized
INFO - 2017-09-13 17:01:20 --> Language Class Initialized
INFO - 2017-09-13 17:01:20 --> Loader Class Initialized
INFO - 2017-09-13 17:01:20 --> Helper loaded: url_helper
INFO - 2017-09-13 17:01:20 --> Database Driver Class Initialized
INFO - 2017-09-13 17:01:20 --> Email Class Initialized
INFO - 2017-09-13 17:01:20 --> Controller Class Initialized
DEBUG - 2017-09-13 17:01:20 --> Config file loaded: C:\xampp\htdocs\api\franknco\franknco\application\config/rest.php
INFO - 2017-09-13 17:01:20 --> Helper loaded: inflector_helper
INFO - 2017-09-13 17:01:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-13 17:01:20 --> Helper loaded: log_helper
INFO - 2017-09-13 17:01:20 --> Model Class Initialized
ERROR - 2017-09-13 22:01:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '?vmOR6?)??.+1??߲????WF?N?j_?7'y??@a??????ϝ??.?w?L=??ޤ}?x";Card Number:s:16:' at line 1 - Invalid query: insert into logging_api(user,action,data,last_log_timestamp) values ('Z�n��*[%��T��<','SIGN UP','Init Hit Data User:s:16:"Z�n��*[%��T��<";Password:s:72:"�Щ/Zc�'�vmOR6�)��.+1��߲����WF�N�j_�7'y��@a������ϝ��.�w�L=��ޤ}�x";Card Number:s:16:"P;��4VZHJ��(��";Fullname:s:8:"i�����";DOB:s:10:"1994-02-26";Address:s:7:"�>�mt�";Email:s:16:"�
m*�â/g&�n`";',now())
INFO - 2017-09-13 22:01:20 --> Language file loaded: language/english/db_lang.php
INFO - 2017-09-13 17:03:45 --> Config Class Initialized
INFO - 2017-09-13 17:03:45 --> Hooks Class Initialized
DEBUG - 2017-09-13 17:03:45 --> UTF-8 Support Enabled
INFO - 2017-09-13 17:03:45 --> Utf8 Class Initialized
INFO - 2017-09-13 17:03:45 --> URI Class Initialized
INFO - 2017-09-13 17:03:45 --> Router Class Initialized
INFO - 2017-09-13 17:03:45 --> Output Class Initialized
INFO - 2017-09-13 17:03:45 --> Security Class Initialized
DEBUG - 2017-09-13 17:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-13 17:03:45 --> Input Class Initialized
INFO - 2017-09-13 17:03:45 --> Language Class Initialized
INFO - 2017-09-13 17:03:45 --> Loader Class Initialized
INFO - 2017-09-13 17:03:45 --> Helper loaded: url_helper
INFO - 2017-09-13 17:03:45 --> Database Driver Class Initialized
INFO - 2017-09-13 17:03:45 --> Email Class Initialized
INFO - 2017-09-13 17:03:45 --> Controller Class Initialized
DEBUG - 2017-09-13 17:03:45 --> Config file loaded: C:\xampp\htdocs\api\franknco\franknco\application\config/rest.php
INFO - 2017-09-13 17:03:45 --> Helper loaded: inflector_helper
INFO - 2017-09-13 17:03:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-13 17:03:46 --> Helper loaded: log_helper
INFO - 2017-09-13 17:03:46 --> Model Class Initialized
ERROR - 2017-09-13 22:03:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '?vmOR6?)??.+1??߲????WF?N?j_?7'y??@a??????ϝ??.?w?L=??ޤ}?x";Card Number:s:16:' at line 1 - Invalid query: insert into logging_api(user,action,data,last_log_timestamp) values ('Z�n��*[%��T��<','SIGN UP','Init Hit Data User:s:16:"Z�n��*[%��T��<";Password:s:72:"�Щ/Zc�'�vmOR6�)��.+1��߲����WF�N�j_�7'y��@a������ϝ��.�w�L=��ޤ}�x";Card Number:s:16:"P;��4VZHJ��(��";Fullname:s:8:"i�����";DOB:s:10:"1994-02-26";Address:s:7:"�>�mt�";Email:s:16:"T���HDd���ۢ";',now())
INFO - 2017-09-13 22:03:46 --> Language file loaded: language/english/db_lang.php
INFO - 2017-09-13 17:08:16 --> Config Class Initialized
INFO - 2017-09-13 17:08:16 --> Hooks Class Initialized
DEBUG - 2017-09-13 17:08:16 --> UTF-8 Support Enabled
INFO - 2017-09-13 17:08:16 --> Utf8 Class Initialized
INFO - 2017-09-13 17:08:16 --> URI Class Initialized
INFO - 2017-09-13 17:08:16 --> Router Class Initialized
INFO - 2017-09-13 17:08:16 --> Output Class Initialized
INFO - 2017-09-13 17:08:16 --> Security Class Initialized
DEBUG - 2017-09-13 17:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-13 17:08:16 --> Input Class Initialized
INFO - 2017-09-13 17:08:16 --> Language Class Initialized
INFO - 2017-09-13 17:08:16 --> Loader Class Initialized
INFO - 2017-09-13 17:08:16 --> Helper loaded: url_helper
INFO - 2017-09-13 17:08:16 --> Database Driver Class Initialized
INFO - 2017-09-13 17:08:16 --> Email Class Initialized
INFO - 2017-09-13 17:08:16 --> Controller Class Initialized
DEBUG - 2017-09-13 17:08:16 --> Config file loaded: C:\xampp\htdocs\api\franknco\franknco\application\config/rest.php
INFO - 2017-09-13 17:08:16 --> Helper loaded: inflector_helper
INFO - 2017-09-13 17:08:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-13 17:08:16 --> Helper loaded: log_helper
INFO - 2017-09-13 17:08:16 --> Model Class Initialized
ERROR - 2017-09-13 22:08:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '?vmOR6?)??.+1??߲????WF?N?j_?7'y??@a??????ϝ??.?w?L=??ޤ}?x";Card Number:s:16:' at line 1 - Invalid query: insert into logging_api(user,action,data,last_log_timestamp) values ('Z�n��*[%��T��<','SIGN UP','Init Hit Data User:s:16:"Z�n��*[%��T��<";Password:s:72:"�Щ/Zc�'�vmOR6�)��.+1��߲����WF�N�j_�7'y��@a������ϝ��.�w�L=��ޤ}�x";Card Number:s:16:"P;��4VZHJ��(��";Fullname:s:8:"i�����";DOB:s:10:"1994-02-26";Address:s:7:"�>�mt�";Email:s:16:"T���HDd���ۢ";',now())
INFO - 2017-09-13 22:08:16 --> Language file loaded: language/english/db_lang.php
INFO - 2017-09-13 17:11:14 --> Config Class Initialized
INFO - 2017-09-13 17:11:14 --> Hooks Class Initialized
DEBUG - 2017-09-13 17:11:14 --> UTF-8 Support Enabled
INFO - 2017-09-13 17:11:15 --> Utf8 Class Initialized
INFO - 2017-09-13 17:11:15 --> URI Class Initialized
INFO - 2017-09-13 17:11:15 --> Router Class Initialized
INFO - 2017-09-13 17:11:15 --> Output Class Initialized
INFO - 2017-09-13 17:11:15 --> Security Class Initialized
DEBUG - 2017-09-13 17:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-13 17:11:15 --> Input Class Initialized
INFO - 2017-09-13 17:11:15 --> Language Class Initialized
INFO - 2017-09-13 17:11:15 --> Loader Class Initialized
INFO - 2017-09-13 17:11:15 --> Helper loaded: url_helper
INFO - 2017-09-13 17:11:15 --> Database Driver Class Initialized
INFO - 2017-09-13 17:11:15 --> Email Class Initialized
INFO - 2017-09-13 17:11:15 --> Controller Class Initialized
DEBUG - 2017-09-13 17:11:15 --> Config file loaded: C:\xampp\htdocs\api\franknco\franknco\application\config/rest.php
INFO - 2017-09-13 17:11:15 --> Helper loaded: inflector_helper
INFO - 2017-09-13 17:11:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-13 17:11:15 --> Helper loaded: log_helper
INFO - 2017-09-13 17:11:15 --> Model Class Initialized
INFO - 2017-09-13 22:11:15 --> Final output sent to browser
DEBUG - 2017-09-13 22:11:15 --> Total execution time: 0.3550
INFO - 2017-09-13 17:23:16 --> Config Class Initialized
INFO - 2017-09-13 17:23:16 --> Hooks Class Initialized
DEBUG - 2017-09-13 17:23:16 --> UTF-8 Support Enabled
INFO - 2017-09-13 17:23:16 --> Utf8 Class Initialized
INFO - 2017-09-13 17:23:16 --> URI Class Initialized
INFO - 2017-09-13 17:23:16 --> Router Class Initialized
INFO - 2017-09-13 17:23:16 --> Output Class Initialized
INFO - 2017-09-13 17:23:16 --> Security Class Initialized
DEBUG - 2017-09-13 17:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-13 17:23:16 --> Input Class Initialized
INFO - 2017-09-13 17:23:16 --> Language Class Initialized
INFO - 2017-09-13 17:23:16 --> Loader Class Initialized
INFO - 2017-09-13 17:23:16 --> Helper loaded: url_helper
INFO - 2017-09-13 17:23:16 --> Database Driver Class Initialized
INFO - 2017-09-13 17:23:16 --> Email Class Initialized
INFO - 2017-09-13 17:23:16 --> Controller Class Initialized
DEBUG - 2017-09-13 17:23:16 --> Config file loaded: C:\xampp\htdocs\api\franknco\franknco\application\config/rest.php
INFO - 2017-09-13 17:23:16 --> Helper loaded: inflector_helper
INFO - 2017-09-13 17:23:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-13 17:23:16 --> Helper loaded: log_helper
INFO - 2017-09-13 17:23:16 --> Model Class Initialized
ERROR - 2017-09-13 22:23:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '?vmOR6?)??.+1??߲????WF?N?j_?7'y??@a??????ϝ??.?w?L=??ޤ}?x";Card Number:s:16:' at line 1 - Invalid query: insert into logging_api(user,action,data,last_log_timestamp) values ('Z�n��*[%��T��<','SIGN UP','Init Hit Data User:s:16:"Z�n��*[%��T��<";Password:s:72:"�Щ/Zc�'�vmOR6�)��.+1��߲����WF�N�j_�7'y��@a������ϝ��.�w�L=��ޤ}�x";Card Number:s:16:"P;��4VZHJ��(��";Fullname:s:8:"i�����";DOB:s:10:"1994-02-26";Address:s:8:"z��z�rQY";Email:s:16:"T���HDd���ۢ";',now())
INFO - 2017-09-13 22:23:17 --> Language file loaded: language/english/db_lang.php
INFO - 2017-09-13 17:31:00 --> Config Class Initialized
INFO - 2017-09-13 17:31:00 --> Hooks Class Initialized
DEBUG - 2017-09-13 17:31:00 --> UTF-8 Support Enabled
INFO - 2017-09-13 17:31:00 --> Utf8 Class Initialized
INFO - 2017-09-13 17:31:00 --> URI Class Initialized
INFO - 2017-09-13 17:31:00 --> Router Class Initialized
INFO - 2017-09-13 17:31:00 --> Output Class Initialized
INFO - 2017-09-13 17:31:00 --> Security Class Initialized
DEBUG - 2017-09-13 17:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-13 17:31:00 --> Input Class Initialized
INFO - 2017-09-13 17:31:00 --> Language Class Initialized
INFO - 2017-09-13 17:31:00 --> Loader Class Initialized
INFO - 2017-09-13 17:31:00 --> Helper loaded: url_helper
INFO - 2017-09-13 17:31:00 --> Database Driver Class Initialized
INFO - 2017-09-13 17:31:00 --> Email Class Initialized
INFO - 2017-09-13 17:31:00 --> Controller Class Initialized
DEBUG - 2017-09-13 17:31:00 --> Config file loaded: C:\xampp\htdocs\api\franknco\franknco\application\config/rest.php
INFO - 2017-09-13 17:31:00 --> Helper loaded: inflector_helper
INFO - 2017-09-13 17:31:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-13 17:31:00 --> Helper loaded: log_helper
INFO - 2017-09-13 17:31:00 --> Model Class Initialized
ERROR - 2017-09-13 22:31:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '?vmOR6?)??.+1??߲????WF?N?j_?7'y??@a??????ϝ??.?w?L=??ޤ}?x";Card Number:s:16:' at line 1 - Invalid query: insert into logging_api(user,action,data,last_log_timestamp) values ('Z�n��*[%��T��<','SIGN UP','Init Hit Data User:s:16:"Z�n��*[%��T��<";Password:s:72:"�Щ/Zc�'�vmOR6�)��.+1��߲����WF�N�j_�7'y��@a������ϝ��.�w�L=��ޤ}�x";Card Number:s:16:"P;��4VZHJ��(��";Fullname:s:8:"i�����";DOB:s:10:"1994-02-26";Address:s:8:"z��z�rQY";Email:s:16:"T���HDd���ۢ";',now())
INFO - 2017-09-13 22:31:00 --> Language file loaded: language/english/db_lang.php
INFO - 2017-09-13 17:38:19 --> Config Class Initialized
INFO - 2017-09-13 17:38:19 --> Hooks Class Initialized
DEBUG - 2017-09-13 17:38:19 --> UTF-8 Support Enabled
INFO - 2017-09-13 17:38:19 --> Utf8 Class Initialized
INFO - 2017-09-13 17:38:19 --> URI Class Initialized
INFO - 2017-09-13 17:38:19 --> Router Class Initialized
INFO - 2017-09-13 17:38:19 --> Output Class Initialized
INFO - 2017-09-13 17:38:19 --> Security Class Initialized
DEBUG - 2017-09-13 17:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-13 17:38:20 --> Input Class Initialized
INFO - 2017-09-13 17:38:20 --> Language Class Initialized
INFO - 2017-09-13 17:38:20 --> Loader Class Initialized
INFO - 2017-09-13 17:38:20 --> Helper loaded: url_helper
INFO - 2017-09-13 17:38:20 --> Database Driver Class Initialized
INFO - 2017-09-13 17:38:20 --> Email Class Initialized
INFO - 2017-09-13 17:38:20 --> Controller Class Initialized
DEBUG - 2017-09-13 17:38:20 --> Config file loaded: C:\xampp\htdocs\api\franknco\franknco\application\config/rest.php
INFO - 2017-09-13 17:38:20 --> Helper loaded: inflector_helper
INFO - 2017-09-13 17:38:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-13 17:38:20 --> Helper loaded: log_helper
INFO - 2017-09-13 17:38:20 --> Model Class Initialized
ERROR - 2017-09-13 22:38:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '?vmOR6?)??.+1??߲????WF?N?j_?7'y??@a??????ϝ??.?w?L=??ޤ}?x";Card Number:s:16:' at line 1 - Invalid query: insert into logging_api(user,action,data,last_log_timestamp) values ('Z�n��*[%��T��<','SIGN UP','Init Hit Data User:s:16:"Z�n��*[%��T��<";Password:s:72:"�Щ/Zc�'�vmOR6�)��.+1��߲����WF�N�j_�7'y��@a������ϝ��.�w�L=��ޤ}�x";Card Number:s:16:"P;��4VZH�j19�";Fullname:s:8:"i�����";DOB:s:10:"1994-02-26";Address:s:7:"�>�mt�";Email:s:16:"T���HDd���ۢ";',now())
INFO - 2017-09-13 22:38:20 --> Language file loaded: language/english/db_lang.php
INFO - 2017-09-13 17:39:01 --> Config Class Initialized
INFO - 2017-09-13 17:39:01 --> Hooks Class Initialized
DEBUG - 2017-09-13 17:39:01 --> UTF-8 Support Enabled
INFO - 2017-09-13 17:39:01 --> Utf8 Class Initialized
INFO - 2017-09-13 17:39:01 --> URI Class Initialized
INFO - 2017-09-13 17:39:01 --> Router Class Initialized
INFO - 2017-09-13 17:39:01 --> Output Class Initialized
INFO - 2017-09-13 17:39:01 --> Security Class Initialized
DEBUG - 2017-09-13 17:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-13 17:39:01 --> Input Class Initialized
INFO - 2017-09-13 17:39:01 --> Language Class Initialized
INFO - 2017-09-13 17:39:01 --> Loader Class Initialized
INFO - 2017-09-13 17:39:01 --> Helper loaded: url_helper
INFO - 2017-09-13 17:39:01 --> Database Driver Class Initialized
INFO - 2017-09-13 17:39:01 --> Email Class Initialized
INFO - 2017-09-13 17:39:01 --> Controller Class Initialized
DEBUG - 2017-09-13 17:39:01 --> Config file loaded: C:\xampp\htdocs\api\franknco\franknco\application\config/rest.php
INFO - 2017-09-13 17:39:01 --> Helper loaded: inflector_helper
INFO - 2017-09-13 17:39:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-13 17:39:01 --> Helper loaded: log_helper
INFO - 2017-09-13 17:39:01 --> Model Class Initialized
ERROR - 2017-09-13 22:39:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '?vmOR6?)??.+1??߲????WF?N?j_?7'y??@a??????ϝ??.?w?L=??ޤ}?x";Card Number:s:16:' at line 1 - Invalid query: insert into logging_api(user,action,data,last_log_timestamp) values ('Z�n��*[%��T��<','SIGN UP','Init Hit Data User:s:16:"Z�n��*[%��T��<";Password:s:72:"�Щ/Zc�'�vmOR6�)��.+1��߲����WF�N�j_�7'y��@a������ϝ��.�w�L=��ޤ}�x";Card Number:s:16:"P;��4VZH�j19�";Fullname:s:8:"i�����";DOB:s:10:"1994-02-26";Address:s:7:"�>�mt�";Email:s:16:"T���HDd���ۢ";',now())
INFO - 2017-09-13 22:39:01 --> Language file loaded: language/english/db_lang.php
INFO - 2017-09-13 17:39:30 --> Config Class Initialized
INFO - 2017-09-13 17:39:30 --> Hooks Class Initialized
DEBUG - 2017-09-13 17:39:30 --> UTF-8 Support Enabled
INFO - 2017-09-13 17:39:30 --> Utf8 Class Initialized
INFO - 2017-09-13 17:39:30 --> URI Class Initialized
INFO - 2017-09-13 17:39:30 --> Router Class Initialized
INFO - 2017-09-13 17:39:30 --> Output Class Initialized
INFO - 2017-09-13 17:39:30 --> Security Class Initialized
DEBUG - 2017-09-13 17:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-13 17:39:30 --> Input Class Initialized
INFO - 2017-09-13 17:39:30 --> Language Class Initialized
INFO - 2017-09-13 17:39:30 --> Loader Class Initialized
INFO - 2017-09-13 17:39:30 --> Helper loaded: url_helper
INFO - 2017-09-13 17:39:30 --> Database Driver Class Initialized
INFO - 2017-09-13 17:39:30 --> Email Class Initialized
INFO - 2017-09-13 17:39:30 --> Controller Class Initialized
DEBUG - 2017-09-13 17:39:30 --> Config file loaded: C:\xampp\htdocs\api\franknco\franknco\application\config/rest.php
INFO - 2017-09-13 17:39:30 --> Helper loaded: inflector_helper
INFO - 2017-09-13 17:39:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-13 17:39:30 --> Helper loaded: log_helper
INFO - 2017-09-13 17:39:30 --> Model Class Initialized
ERROR - 2017-09-13 22:39:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '?vmOR6?)??.+1??߲????WF?N?j_?7'y??@a??????ϝ??.?w?L=??ޤ}?x";Card Number:s:16:' at line 1 - Invalid query: insert into logging_api(user,action,data,last_log_timestamp) values ('Z�n��*[%��T��<','SIGN UP','Init Hit Data User:s:16:"Z�n��*[%��T��<";Password:s:72:"�Щ/Zc�'�vmOR6�)��.+1��߲����WF�N�j_�7'y��@a������ϝ��.�w�L=��ޤ}�x";Card Number:s:16:"P;��4VZH�j19�";Fullname:s:8:"i�����";DOB:s:10:"1994-02-26";Address:s:7:"�>�mt�";Email:s:16:"T���HDd���ۢ";',now())
INFO - 2017-09-13 22:39:30 --> Language file loaded: language/english/db_lang.php
INFO - 2017-09-13 17:41:15 --> Config Class Initialized
INFO - 2017-09-13 17:41:15 --> Hooks Class Initialized
DEBUG - 2017-09-13 17:41:15 --> UTF-8 Support Enabled
INFO - 2017-09-13 17:41:15 --> Utf8 Class Initialized
INFO - 2017-09-13 17:41:15 --> URI Class Initialized
INFO - 2017-09-13 17:41:15 --> Router Class Initialized
INFO - 2017-09-13 17:41:15 --> Output Class Initialized
INFO - 2017-09-13 17:41:15 --> Security Class Initialized
DEBUG - 2017-09-13 17:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-13 17:41:15 --> Input Class Initialized
INFO - 2017-09-13 17:41:15 --> Language Class Initialized
INFO - 2017-09-13 17:41:15 --> Loader Class Initialized
INFO - 2017-09-13 17:41:15 --> Helper loaded: url_helper
INFO - 2017-09-13 17:41:15 --> Database Driver Class Initialized
INFO - 2017-09-13 17:41:15 --> Email Class Initialized
INFO - 2017-09-13 17:41:15 --> Controller Class Initialized
DEBUG - 2017-09-13 17:41:15 --> Config file loaded: C:\xampp\htdocs\api\franknco\franknco\application\config/rest.php
INFO - 2017-09-13 17:41:15 --> Helper loaded: inflector_helper
INFO - 2017-09-13 17:41:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-13 17:41:15 --> Helper loaded: log_helper
INFO - 2017-09-13 17:41:15 --> Model Class Initialized
ERROR - 2017-09-13 22:41:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '?vmOR6?)??.+1??߲????WF?N?j_?7'y??@a??????ϝ??.?w?L=??ޤ}?x";Card Number:s:16:' at line 1 - Invalid query: insert into logging_api(user,action,data,last_log_timestamp) values ('Z�n��*[%��T��<','SIGN UP','Init Hit Data User:s:16:"Z�n��*[%��T��<";Password:s:72:"�Щ/Zc�'�vmOR6�)��.+1��߲����WF�N�j_�7'y��@a������ϝ��.�w�L=��ޤ}�x";Card Number:s:16:"P;��4VZH�j19�";Fullname:s:8:"i�����";DOB:s:10:"1994-02-26";Address:s:7:"�>�mt�";Email:s:16:"T���HDd���ۢ";',now())
INFO - 2017-09-13 22:41:15 --> Language file loaded: language/english/db_lang.php
INFO - 2017-09-13 17:43:10 --> Config Class Initialized
INFO - 2017-09-13 17:43:10 --> Hooks Class Initialized
DEBUG - 2017-09-13 17:43:10 --> UTF-8 Support Enabled
INFO - 2017-09-13 17:43:10 --> Utf8 Class Initialized
INFO - 2017-09-13 17:43:10 --> URI Class Initialized
INFO - 2017-09-13 17:43:10 --> Router Class Initialized
INFO - 2017-09-13 17:43:10 --> Output Class Initialized
INFO - 2017-09-13 17:43:10 --> Security Class Initialized
DEBUG - 2017-09-13 17:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-13 17:43:10 --> Input Class Initialized
INFO - 2017-09-13 17:43:10 --> Language Class Initialized
INFO - 2017-09-13 17:43:10 --> Loader Class Initialized
INFO - 2017-09-13 17:43:10 --> Helper loaded: url_helper
INFO - 2017-09-13 17:43:10 --> Database Driver Class Initialized
INFO - 2017-09-13 17:43:10 --> Email Class Initialized
INFO - 2017-09-13 17:43:10 --> Controller Class Initialized
DEBUG - 2017-09-13 17:43:10 --> Config file loaded: C:\xampp\htdocs\api\franknco\franknco\application\config/rest.php
INFO - 2017-09-13 17:43:10 --> Helper loaded: inflector_helper
INFO - 2017-09-13 17:43:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-13 17:43:11 --> Helper loaded: log_helper
INFO - 2017-09-13 17:43:11 --> Model Class Initialized
ERROR - 2017-09-13 22:43:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '?vmOR6?)??.+1??߲????WF?N?j_?7'y??@a??????ϝ??.?w?L=??ޤ}?x";Card Number:s:16:' at line 1 - Invalid query: insert into logging_api(user,action,data,last_log_timestamp) values ('Z�n��*[%��T��<','SIGN UP','Init Hit Data User:s:16:"Z�n��*[%��T��<";Password:s:72:"�Щ/Zc�'�vmOR6�)��.+1��߲����WF�N�j_�7'y��@a������ϝ��.�w�L=��ޤ}�x";Card Number:s:16:"P;��4VZH�j19�";Fullname:s:8:"i�����";DOB:s:10:"1994-02-26";Address:s:7:"�>�mt�";Email:s:16:"T���HDd���ۢ";',now())
INFO - 2017-09-13 22:43:11 --> Language file loaded: language/english/db_lang.php
INFO - 2017-09-13 18:01:20 --> Config Class Initialized
INFO - 2017-09-13 18:01:20 --> Hooks Class Initialized
DEBUG - 2017-09-13 18:01:20 --> UTF-8 Support Enabled
INFO - 2017-09-13 18:01:20 --> Utf8 Class Initialized
INFO - 2017-09-13 18:01:21 --> URI Class Initialized
INFO - 2017-09-13 18:01:21 --> Router Class Initialized
INFO - 2017-09-13 18:01:21 --> Output Class Initialized
INFO - 2017-09-13 18:01:21 --> Security Class Initialized
DEBUG - 2017-09-13 18:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-13 18:01:21 --> Input Class Initialized
INFO - 2017-09-13 18:01:21 --> Language Class Initialized
INFO - 2017-09-13 18:01:21 --> Loader Class Initialized
INFO - 2017-09-13 18:01:21 --> Helper loaded: url_helper
INFO - 2017-09-13 18:01:21 --> Database Driver Class Initialized
INFO - 2017-09-13 18:01:21 --> Email Class Initialized
INFO - 2017-09-13 18:01:21 --> Controller Class Initialized
DEBUG - 2017-09-13 18:01:21 --> Config file loaded: C:\xampp\htdocs\api\franknco\franknco\application\config/rest.php
INFO - 2017-09-13 18:01:21 --> Helper loaded: inflector_helper
INFO - 2017-09-13 18:01:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-13 18:01:21 --> Helper loaded: log_helper
INFO - 2017-09-13 18:01:21 --> Model Class Initialized
ERROR - 2017-09-13 23:01:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '?vmOR6?)??.+1??߲????WF?N?j_?7'y??@a??????ϝ??.?w?L=??ޤ}?x";Card Number:s:16:' at line 1 - Invalid query: insert into logging_api(user,action,data,last_log_timestamp) values ('Z�n��*[%��T��<','SIGN UP','Init Hit Data User:s:16:"Z�n��*[%��T��<";Password:s:72:"�Щ/Zc�'�vmOR6�)��.+1��߲����WF�N�j_�7'y��@a������ϝ��.�w�L=��ޤ}�x";Card Number:s:16:"P;��4VZH�j19�";Fullname:s:8:"i�����";DOB:s:10:"1994-02-26";Address:s:7:"�>�mt�";Email:s:16:"T���HDd���ۢ";',now())
INFO - 2017-09-13 23:01:21 --> Language file loaded: language/english/db_lang.php
INFO - 2017-09-13 18:45:56 --> Config Class Initialized
INFO - 2017-09-13 18:45:56 --> Hooks Class Initialized
DEBUG - 2017-09-13 18:45:57 --> UTF-8 Support Enabled
INFO - 2017-09-13 18:45:57 --> Utf8 Class Initialized
INFO - 2017-09-13 18:45:57 --> URI Class Initialized
INFO - 2017-09-13 18:45:57 --> Router Class Initialized
INFO - 2017-09-13 18:45:57 --> Output Class Initialized
INFO - 2017-09-13 18:45:57 --> Security Class Initialized
DEBUG - 2017-09-13 18:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-13 18:45:57 --> Input Class Initialized
INFO - 2017-09-13 18:45:57 --> Language Class Initialized
INFO - 2017-09-13 18:45:58 --> Loader Class Initialized
INFO - 2017-09-13 18:45:58 --> Helper loaded: url_helper
INFO - 2017-09-13 18:45:58 --> Database Driver Class Initialized
INFO - 2017-09-13 18:45:58 --> Email Class Initialized
INFO - 2017-09-13 18:45:58 --> Controller Class Initialized
DEBUG - 2017-09-13 18:45:58 --> Config file loaded: C:\xampp\htdocs\api\franknco\franknco\application\config/rest.php
INFO - 2017-09-13 18:45:58 --> Helper loaded: inflector_helper
INFO - 2017-09-13 18:45:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-13 18:45:58 --> Helper loaded: log_helper
INFO - 2017-09-13 18:45:59 --> Model Class Initialized
ERROR - 2017-09-13 23:45:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '?vmOR6?)??.+1??߲????WF?N?j_?7'y??@a??????ϝ??.?w?L=??ޤ}?x";Card Number:s:16:' at line 1 - Invalid query: insert into logging_api(user,action,data,last_log_timestamp) values ('Z�n��*[%��T��<','SIGN UP','Init Hit Data User:s:16:"Z�n��*[%��T��<";Password:s:72:"�Щ/Zc�'�vmOR6�)��.+1��߲����WF�N�j_�7'y��@a������ϝ��.�w�L=��ޤ}�x";Card Number:s:16:"P;��4VZHJ��(��";Fullname:s:8:"i�����";DOB:s:10:"1994-02-26";Address:s:7:"�>�mt�";Email:s:16:"T���HDd���ۢ";',now())
INFO - 2017-09-13 23:45:59 --> Language file loaded: language/english/db_lang.php
INFO - 2017-09-13 18:55:10 --> Config Class Initialized
INFO - 2017-09-13 18:55:10 --> Hooks Class Initialized
DEBUG - 2017-09-13 18:55:10 --> UTF-8 Support Enabled
INFO - 2017-09-13 18:55:10 --> Utf8 Class Initialized
INFO - 2017-09-13 18:55:11 --> URI Class Initialized
INFO - 2017-09-13 18:55:11 --> Router Class Initialized
INFO - 2017-09-13 18:55:11 --> Output Class Initialized
INFO - 2017-09-13 18:55:11 --> Security Class Initialized
DEBUG - 2017-09-13 18:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-13 18:55:11 --> Input Class Initialized
INFO - 2017-09-13 18:55:11 --> Language Class Initialized
INFO - 2017-09-13 18:55:11 --> Loader Class Initialized
INFO - 2017-09-13 18:55:11 --> Helper loaded: url_helper
INFO - 2017-09-13 18:55:11 --> Database Driver Class Initialized
INFO - 2017-09-13 18:55:11 --> Email Class Initialized
INFO - 2017-09-13 18:55:11 --> Controller Class Initialized
DEBUG - 2017-09-13 18:55:11 --> Config file loaded: C:\xampp\htdocs\api\franknco\franknco\application\config/rest.php
INFO - 2017-09-13 18:55:11 --> Helper loaded: inflector_helper
INFO - 2017-09-13 18:55:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-13 18:55:11 --> Helper loaded: log_helper
INFO - 2017-09-13 18:55:11 --> Model Class Initialized
ERROR - 2017-09-13 23:55:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '?vmOR6?)??.+1??߲????WF?N?j_?7'y??@a??????ϝ??.?w?L=??ޤ}?x";Card Number:s:16:' at line 1 - Invalid query: insert into logging_api(user,action,data,last_log_timestamp) values ('Z�n��*[%��T��<','SIGN UP','Init Hit Data User:s:16:"Z�n��*[%��T��<";Password:s:72:"�Щ/Zc�'�vmOR6�)��.+1��߲����WF�N�j_�7'y��@a������ϝ��.�w�L=��ޤ}�x";Card Number:s:16:"P;��4VZHJ��(��";Fullname:s:8:"i�����";DOB:s:10:"1994-02-26";Address:s:7:"�>�mt�";Email:s:16:"T���HDd���ۢ";',now())
INFO - 2017-09-13 23:55:11 --> Language file loaded: language/english/db_lang.php
INFO - 2017-09-13 19:02:19 --> Config Class Initialized
INFO - 2017-09-13 19:02:19 --> Hooks Class Initialized
DEBUG - 2017-09-13 19:02:19 --> UTF-8 Support Enabled
INFO - 2017-09-13 19:02:19 --> Utf8 Class Initialized
INFO - 2017-09-13 19:02:19 --> URI Class Initialized
INFO - 2017-09-13 19:02:19 --> Router Class Initialized
INFO - 2017-09-13 19:02:19 --> Output Class Initialized
INFO - 2017-09-13 19:02:19 --> Security Class Initialized
DEBUG - 2017-09-13 19:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-13 19:02:19 --> Input Class Initialized
INFO - 2017-09-13 19:02:19 --> Language Class Initialized
INFO - 2017-09-13 19:02:19 --> Loader Class Initialized
INFO - 2017-09-13 19:02:19 --> Helper loaded: url_helper
INFO - 2017-09-13 19:02:19 --> Database Driver Class Initialized
INFO - 2017-09-13 19:02:19 --> Email Class Initialized
INFO - 2017-09-13 19:02:19 --> Controller Class Initialized
DEBUG - 2017-09-13 19:02:19 --> Config file loaded: C:\xampp\htdocs\api\franknco\franknco\application\config/rest.php
INFO - 2017-09-13 19:02:19 --> Helper loaded: inflector_helper
INFO - 2017-09-13 19:02:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-13 19:02:19 --> Helper loaded: log_helper
INFO - 2017-09-13 19:02:19 --> Model Class Initialized
INFO - 2017-09-13 19:03:53 --> Config Class Initialized
INFO - 2017-09-13 19:03:53 --> Hooks Class Initialized
DEBUG - 2017-09-13 19:03:53 --> UTF-8 Support Enabled
INFO - 2017-09-13 19:03:53 --> Utf8 Class Initialized
INFO - 2017-09-13 19:03:53 --> URI Class Initialized
INFO - 2017-09-13 19:03:53 --> Router Class Initialized
INFO - 2017-09-13 19:03:53 --> Output Class Initialized
INFO - 2017-09-13 19:03:53 --> Security Class Initialized
DEBUG - 2017-09-13 19:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-13 19:03:53 --> Input Class Initialized
INFO - 2017-09-13 19:03:53 --> Language Class Initialized
INFO - 2017-09-13 19:03:53 --> Loader Class Initialized
INFO - 2017-09-13 19:03:53 --> Helper loaded: url_helper
INFO - 2017-09-13 19:03:53 --> Database Driver Class Initialized
INFO - 2017-09-13 19:03:53 --> Email Class Initialized
INFO - 2017-09-13 19:03:53 --> Controller Class Initialized
DEBUG - 2017-09-13 19:03:53 --> Config file loaded: C:\xampp\htdocs\api\franknco\franknco\application\config/rest.php
INFO - 2017-09-13 19:03:53 --> Helper loaded: inflector_helper
INFO - 2017-09-13 19:03:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-13 19:03:53 --> Helper loaded: log_helper
INFO - 2017-09-13 19:03:53 --> Model Class Initialized
