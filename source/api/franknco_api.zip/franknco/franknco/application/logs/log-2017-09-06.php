<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-09-06 07:14:31 --> Config Class Initialized
INFO - 2017-09-06 07:14:31 --> Hooks Class Initialized
DEBUG - 2017-09-06 07:14:31 --> UTF-8 Support Enabled
INFO - 2017-09-06 07:14:31 --> Utf8 Class Initialized
INFO - 2017-09-06 07:14:31 --> URI Class Initialized
INFO - 2017-09-06 07:14:31 --> Router Class Initialized
INFO - 2017-09-06 07:14:31 --> Output Class Initialized
INFO - 2017-09-06 07:14:31 --> Security Class Initialized
DEBUG - 2017-09-06 07:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 07:14:31 --> Input Class Initialized
INFO - 2017-09-06 07:14:31 --> Language Class Initialized
INFO - 2017-09-06 07:14:31 --> Loader Class Initialized
INFO - 2017-09-06 07:14:31 --> Helper loaded: url_helper
INFO - 2017-09-06 07:14:31 --> Database Driver Class Initialized
INFO - 2017-09-06 07:14:31 --> Email Class Initialized
INFO - 2017-09-06 07:14:31 --> Controller Class Initialized
DEBUG - 2017-09-06 07:14:31 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-06 07:14:31 --> Helper loaded: inflector_helper
INFO - 2017-09-06 07:14:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-06 07:14:31 --> Helper loaded: log_helper
INFO - 2017-09-06 07:14:31 --> Model Class Initialized
INFO - 2017-09-06 14:14:31 --> Final output sent to browser
DEBUG - 2017-09-06 14:14:31 --> Total execution time: 0.0780
INFO - 2017-09-06 07:14:34 --> Config Class Initialized
INFO - 2017-09-06 07:14:34 --> Hooks Class Initialized
DEBUG - 2017-09-06 07:14:34 --> UTF-8 Support Enabled
INFO - 2017-09-06 07:14:34 --> Utf8 Class Initialized
INFO - 2017-09-06 07:14:34 --> URI Class Initialized
INFO - 2017-09-06 07:14:34 --> Router Class Initialized
INFO - 2017-09-06 07:14:34 --> Output Class Initialized
INFO - 2017-09-06 07:14:34 --> Security Class Initialized
DEBUG - 2017-09-06 07:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 07:14:34 --> Input Class Initialized
INFO - 2017-09-06 07:14:34 --> Language Class Initialized
INFO - 2017-09-06 07:14:34 --> Loader Class Initialized
INFO - 2017-09-06 07:14:34 --> Helper loaded: url_helper
INFO - 2017-09-06 07:14:34 --> Database Driver Class Initialized
INFO - 2017-09-06 07:14:34 --> Email Class Initialized
INFO - 2017-09-06 07:14:34 --> Controller Class Initialized
DEBUG - 2017-09-06 07:14:34 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-06 07:14:34 --> Helper loaded: inflector_helper
INFO - 2017-09-06 07:14:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-06 07:14:34 --> Helper loaded: log_helper
INFO - 2017-09-06 07:14:34 --> Model Class Initialized
INFO - 2017-09-06 14:14:34 --> Final output sent to browser
DEBUG - 2017-09-06 14:14:34 --> Total execution time: 0.0715
INFO - 2017-09-06 07:14:37 --> Config Class Initialized
INFO - 2017-09-06 07:14:37 --> Hooks Class Initialized
DEBUG - 2017-09-06 07:14:37 --> UTF-8 Support Enabled
INFO - 2017-09-06 07:14:37 --> Utf8 Class Initialized
INFO - 2017-09-06 07:14:37 --> URI Class Initialized
INFO - 2017-09-06 07:14:37 --> Router Class Initialized
INFO - 2017-09-06 07:14:37 --> Output Class Initialized
INFO - 2017-09-06 07:14:37 --> Security Class Initialized
DEBUG - 2017-09-06 07:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 07:14:37 --> Input Class Initialized
INFO - 2017-09-06 07:14:37 --> Language Class Initialized
INFO - 2017-09-06 07:14:37 --> Loader Class Initialized
INFO - 2017-09-06 07:14:37 --> Helper loaded: url_helper
INFO - 2017-09-06 07:14:37 --> Database Driver Class Initialized
INFO - 2017-09-06 07:14:37 --> Email Class Initialized
INFO - 2017-09-06 07:14:37 --> Controller Class Initialized
DEBUG - 2017-09-06 07:14:37 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-06 07:14:37 --> Helper loaded: inflector_helper
INFO - 2017-09-06 07:14:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-06 07:14:37 --> Helper loaded: log_helper
INFO - 2017-09-06 07:14:37 --> Model Class Initialized
INFO - 2017-09-06 14:14:37 --> Final output sent to browser
DEBUG - 2017-09-06 14:14:37 --> Total execution time: 0.0753
INFO - 2017-09-06 09:43:15 --> Config Class Initialized
INFO - 2017-09-06 09:43:15 --> Hooks Class Initialized
DEBUG - 2017-09-06 09:43:15 --> UTF-8 Support Enabled
INFO - 2017-09-06 09:43:15 --> Utf8 Class Initialized
INFO - 2017-09-06 09:43:15 --> URI Class Initialized
INFO - 2017-09-06 09:43:15 --> Router Class Initialized
INFO - 2017-09-06 09:43:15 --> Output Class Initialized
INFO - 2017-09-06 09:43:15 --> Security Class Initialized
DEBUG - 2017-09-06 09:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 09:43:15 --> Input Class Initialized
INFO - 2017-09-06 09:43:15 --> Language Class Initialized
INFO - 2017-09-06 09:43:15 --> Loader Class Initialized
INFO - 2017-09-06 09:43:15 --> Helper loaded: url_helper
INFO - 2017-09-06 09:43:15 --> Database Driver Class Initialized
INFO - 2017-09-06 09:43:15 --> Email Class Initialized
INFO - 2017-09-06 09:43:15 --> Controller Class Initialized
DEBUG - 2017-09-06 09:43:15 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-06 09:43:15 --> Helper loaded: inflector_helper
INFO - 2017-09-06 09:43:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-06 09:43:15 --> Helper loaded: log_helper
INFO - 2017-09-06 09:43:15 --> Model Class Initialized
INFO - 2017-09-06 16:43:16 --> Final output sent to browser
DEBUG - 2017-09-06 16:43:16 --> Total execution time: 0.4364
INFO - 2017-09-06 09:43:20 --> Config Class Initialized
INFO - 2017-09-06 09:43:20 --> Hooks Class Initialized
DEBUG - 2017-09-06 09:43:20 --> UTF-8 Support Enabled
INFO - 2017-09-06 09:43:20 --> Utf8 Class Initialized
INFO - 2017-09-06 09:43:20 --> URI Class Initialized
INFO - 2017-09-06 09:43:20 --> Router Class Initialized
INFO - 2017-09-06 09:43:20 --> Output Class Initialized
INFO - 2017-09-06 09:43:20 --> Security Class Initialized
DEBUG - 2017-09-06 09:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 09:43:20 --> Input Class Initialized
INFO - 2017-09-06 09:43:20 --> Language Class Initialized
INFO - 2017-09-06 09:43:20 --> Loader Class Initialized
INFO - 2017-09-06 09:43:20 --> Helper loaded: url_helper
INFO - 2017-09-06 09:43:20 --> Database Driver Class Initialized
INFO - 2017-09-06 09:43:20 --> Email Class Initialized
INFO - 2017-09-06 09:43:20 --> Controller Class Initialized
DEBUG - 2017-09-06 09:43:20 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-06 09:43:20 --> Helper loaded: inflector_helper
INFO - 2017-09-06 09:43:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-06 09:43:20 --> Helper loaded: log_helper
INFO - 2017-09-06 09:43:20 --> Model Class Initialized
INFO - 2017-09-06 16:43:20 --> Final output sent to browser
DEBUG - 2017-09-06 16:43:20 --> Total execution time: 0.0743
INFO - 2017-09-06 09:44:04 --> Config Class Initialized
INFO - 2017-09-06 09:44:04 --> Hooks Class Initialized
DEBUG - 2017-09-06 09:44:04 --> UTF-8 Support Enabled
INFO - 2017-09-06 09:44:04 --> Utf8 Class Initialized
INFO - 2017-09-06 09:44:04 --> URI Class Initialized
INFO - 2017-09-06 09:44:04 --> Router Class Initialized
INFO - 2017-09-06 09:44:04 --> Output Class Initialized
INFO - 2017-09-06 09:44:04 --> Security Class Initialized
DEBUG - 2017-09-06 09:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 09:44:04 --> Input Class Initialized
INFO - 2017-09-06 09:44:04 --> Language Class Initialized
INFO - 2017-09-06 09:44:04 --> Loader Class Initialized
INFO - 2017-09-06 09:44:04 --> Helper loaded: url_helper
INFO - 2017-09-06 09:44:04 --> Database Driver Class Initialized
INFO - 2017-09-06 09:44:04 --> Email Class Initialized
INFO - 2017-09-06 09:44:04 --> Controller Class Initialized
DEBUG - 2017-09-06 09:44:04 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-06 09:44:04 --> Helper loaded: inflector_helper
INFO - 2017-09-06 09:44:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-06 09:44:04 --> Helper loaded: log_helper
INFO - 2017-09-06 09:44:04 --> Model Class Initialized
INFO - 2017-09-06 16:44:04 --> Final output sent to browser
DEBUG - 2017-09-06 16:44:04 --> Total execution time: 0.1076
INFO - 2017-09-06 09:44:09 --> Config Class Initialized
INFO - 2017-09-06 09:44:09 --> Hooks Class Initialized
DEBUG - 2017-09-06 09:44:09 --> UTF-8 Support Enabled
INFO - 2017-09-06 09:44:09 --> Utf8 Class Initialized
INFO - 2017-09-06 09:44:09 --> URI Class Initialized
INFO - 2017-09-06 09:44:09 --> Router Class Initialized
INFO - 2017-09-06 09:44:09 --> Output Class Initialized
INFO - 2017-09-06 09:44:09 --> Security Class Initialized
DEBUG - 2017-09-06 09:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 09:44:09 --> Input Class Initialized
INFO - 2017-09-06 09:44:09 --> Language Class Initialized
INFO - 2017-09-06 09:44:09 --> Loader Class Initialized
INFO - 2017-09-06 09:44:09 --> Helper loaded: url_helper
INFO - 2017-09-06 09:44:09 --> Database Driver Class Initialized
INFO - 2017-09-06 09:44:09 --> Email Class Initialized
INFO - 2017-09-06 09:44:09 --> Controller Class Initialized
DEBUG - 2017-09-06 09:44:09 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-06 09:44:09 --> Helper loaded: inflector_helper
INFO - 2017-09-06 09:44:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-06 09:44:09 --> Helper loaded: log_helper
INFO - 2017-09-06 09:44:09 --> Model Class Initialized
INFO - 2017-09-06 16:44:09 --> Final output sent to browser
DEBUG - 2017-09-06 16:44:09 --> Total execution time: 0.0717
INFO - 2017-09-06 09:44:13 --> Config Class Initialized
INFO - 2017-09-06 09:44:13 --> Hooks Class Initialized
DEBUG - 2017-09-06 09:44:13 --> UTF-8 Support Enabled
INFO - 2017-09-06 09:44:13 --> Utf8 Class Initialized
INFO - 2017-09-06 09:44:13 --> URI Class Initialized
INFO - 2017-09-06 09:44:13 --> Router Class Initialized
INFO - 2017-09-06 09:44:13 --> Output Class Initialized
INFO - 2017-09-06 09:44:13 --> Security Class Initialized
DEBUG - 2017-09-06 09:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 09:44:13 --> Input Class Initialized
INFO - 2017-09-06 09:44:13 --> Language Class Initialized
INFO - 2017-09-06 09:44:13 --> Loader Class Initialized
INFO - 2017-09-06 09:44:13 --> Helper loaded: url_helper
INFO - 2017-09-06 09:44:13 --> Database Driver Class Initialized
INFO - 2017-09-06 09:44:13 --> Email Class Initialized
INFO - 2017-09-06 09:44:13 --> Controller Class Initialized
DEBUG - 2017-09-06 09:44:13 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-06 09:44:13 --> Helper loaded: inflector_helper
INFO - 2017-09-06 09:44:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-06 09:44:13 --> Helper loaded: log_helper
INFO - 2017-09-06 09:44:13 --> Model Class Initialized
INFO - 2017-09-06 16:44:13 --> Final output sent to browser
DEBUG - 2017-09-06 16:44:13 --> Total execution time: 0.0700
INFO - 2017-09-06 09:44:15 --> Config Class Initialized
INFO - 2017-09-06 09:44:15 --> Hooks Class Initialized
DEBUG - 2017-09-06 09:44:15 --> UTF-8 Support Enabled
INFO - 2017-09-06 09:44:15 --> Utf8 Class Initialized
INFO - 2017-09-06 09:44:15 --> URI Class Initialized
INFO - 2017-09-06 09:44:15 --> Router Class Initialized
INFO - 2017-09-06 09:44:15 --> Output Class Initialized
INFO - 2017-09-06 09:44:15 --> Security Class Initialized
DEBUG - 2017-09-06 09:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 09:44:15 --> Input Class Initialized
INFO - 2017-09-06 09:44:15 --> Language Class Initialized
INFO - 2017-09-06 09:44:15 --> Loader Class Initialized
INFO - 2017-09-06 09:44:15 --> Helper loaded: url_helper
INFO - 2017-09-06 09:44:15 --> Database Driver Class Initialized
INFO - 2017-09-06 09:44:15 --> Email Class Initialized
INFO - 2017-09-06 09:44:15 --> Controller Class Initialized
DEBUG - 2017-09-06 09:44:15 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-06 09:44:15 --> Helper loaded: inflector_helper
INFO - 2017-09-06 09:44:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-06 09:44:15 --> Helper loaded: log_helper
INFO - 2017-09-06 09:44:15 --> Model Class Initialized
INFO - 2017-09-06 16:44:15 --> Final output sent to browser
DEBUG - 2017-09-06 16:44:15 --> Total execution time: 0.0789
INFO - 2017-09-06 09:45:52 --> Config Class Initialized
INFO - 2017-09-06 09:45:52 --> Hooks Class Initialized
DEBUG - 2017-09-06 09:45:52 --> UTF-8 Support Enabled
INFO - 2017-09-06 09:45:52 --> Utf8 Class Initialized
INFO - 2017-09-06 09:45:52 --> URI Class Initialized
INFO - 2017-09-06 09:45:52 --> Router Class Initialized
INFO - 2017-09-06 09:45:52 --> Output Class Initialized
INFO - 2017-09-06 09:45:52 --> Security Class Initialized
DEBUG - 2017-09-06 09:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 09:45:52 --> Input Class Initialized
INFO - 2017-09-06 09:45:52 --> Language Class Initialized
INFO - 2017-09-06 09:45:52 --> Loader Class Initialized
INFO - 2017-09-06 09:45:52 --> Helper loaded: url_helper
INFO - 2017-09-06 09:45:52 --> Database Driver Class Initialized
INFO - 2017-09-06 09:45:52 --> Email Class Initialized
INFO - 2017-09-06 09:45:52 --> Controller Class Initialized
DEBUG - 2017-09-06 09:45:52 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-06 09:45:52 --> Helper loaded: inflector_helper
INFO - 2017-09-06 09:45:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-06 09:45:52 --> Helper loaded: log_helper
INFO - 2017-09-06 09:45:52 --> Model Class Initialized
INFO - 2017-09-06 16:45:52 --> Final output sent to browser
DEBUG - 2017-09-06 16:45:52 --> Total execution time: 0.0828
INFO - 2017-09-06 09:45:56 --> Config Class Initialized
INFO - 2017-09-06 09:45:56 --> Hooks Class Initialized
DEBUG - 2017-09-06 09:45:56 --> UTF-8 Support Enabled
INFO - 2017-09-06 09:45:56 --> Utf8 Class Initialized
INFO - 2017-09-06 09:45:56 --> URI Class Initialized
INFO - 2017-09-06 09:45:56 --> Router Class Initialized
INFO - 2017-09-06 09:45:56 --> Output Class Initialized
INFO - 2017-09-06 09:45:56 --> Security Class Initialized
DEBUG - 2017-09-06 09:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 09:45:56 --> Input Class Initialized
INFO - 2017-09-06 09:45:56 --> Language Class Initialized
INFO - 2017-09-06 09:45:56 --> Loader Class Initialized
INFO - 2017-09-06 09:45:56 --> Helper loaded: url_helper
INFO - 2017-09-06 09:45:56 --> Database Driver Class Initialized
INFO - 2017-09-06 09:45:56 --> Email Class Initialized
INFO - 2017-09-06 09:45:56 --> Controller Class Initialized
DEBUG - 2017-09-06 09:45:56 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-06 09:45:56 --> Helper loaded: inflector_helper
INFO - 2017-09-06 09:45:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-06 09:45:56 --> Helper loaded: log_helper
INFO - 2017-09-06 09:45:56 --> Model Class Initialized
INFO - 2017-09-06 16:45:56 --> Final output sent to browser
DEBUG - 2017-09-06 16:45:56 --> Total execution time: 0.0717
INFO - 2017-09-06 09:45:59 --> Config Class Initialized
INFO - 2017-09-06 09:45:59 --> Hooks Class Initialized
DEBUG - 2017-09-06 09:45:59 --> UTF-8 Support Enabled
INFO - 2017-09-06 09:45:59 --> Utf8 Class Initialized
INFO - 2017-09-06 09:45:59 --> URI Class Initialized
INFO - 2017-09-06 09:45:59 --> Router Class Initialized
INFO - 2017-09-06 09:45:59 --> Output Class Initialized
INFO - 2017-09-06 09:45:59 --> Security Class Initialized
DEBUG - 2017-09-06 09:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 09:45:59 --> Input Class Initialized
INFO - 2017-09-06 09:45:59 --> Language Class Initialized
INFO - 2017-09-06 09:45:59 --> Loader Class Initialized
INFO - 2017-09-06 09:45:59 --> Helper loaded: url_helper
INFO - 2017-09-06 09:45:59 --> Database Driver Class Initialized
INFO - 2017-09-06 09:45:59 --> Email Class Initialized
INFO - 2017-09-06 09:45:59 --> Controller Class Initialized
DEBUG - 2017-09-06 09:45:59 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-06 09:45:59 --> Helper loaded: inflector_helper
INFO - 2017-09-06 09:45:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-06 09:45:59 --> Helper loaded: log_helper
INFO - 2017-09-06 09:45:59 --> Model Class Initialized
INFO - 2017-09-06 16:45:59 --> Final output sent to browser
DEBUG - 2017-09-06 16:45:59 --> Total execution time: 0.0725
INFO - 2017-09-06 09:46:01 --> Config Class Initialized
INFO - 2017-09-06 09:46:01 --> Hooks Class Initialized
DEBUG - 2017-09-06 09:46:01 --> UTF-8 Support Enabled
INFO - 2017-09-06 09:46:01 --> Utf8 Class Initialized
INFO - 2017-09-06 09:46:01 --> URI Class Initialized
INFO - 2017-09-06 09:46:01 --> Router Class Initialized
INFO - 2017-09-06 09:46:01 --> Output Class Initialized
INFO - 2017-09-06 09:46:01 --> Security Class Initialized
DEBUG - 2017-09-06 09:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 09:46:01 --> Input Class Initialized
INFO - 2017-09-06 09:46:01 --> Language Class Initialized
INFO - 2017-09-06 09:46:01 --> Loader Class Initialized
INFO - 2017-09-06 09:46:01 --> Helper loaded: url_helper
INFO - 2017-09-06 09:46:01 --> Database Driver Class Initialized
INFO - 2017-09-06 09:46:01 --> Email Class Initialized
INFO - 2017-09-06 09:46:01 --> Controller Class Initialized
DEBUG - 2017-09-06 09:46:01 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-06 09:46:01 --> Helper loaded: inflector_helper
INFO - 2017-09-06 09:46:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-06 09:46:01 --> Helper loaded: log_helper
INFO - 2017-09-06 09:46:01 --> Model Class Initialized
INFO - 2017-09-06 16:46:01 --> Final output sent to browser
DEBUG - 2017-09-06 16:46:01 --> Total execution time: 0.0757
INFO - 2017-09-06 09:46:04 --> Config Class Initialized
INFO - 2017-09-06 09:46:04 --> Hooks Class Initialized
DEBUG - 2017-09-06 09:46:04 --> UTF-8 Support Enabled
INFO - 2017-09-06 09:46:04 --> Utf8 Class Initialized
INFO - 2017-09-06 09:46:04 --> URI Class Initialized
INFO - 2017-09-06 09:46:04 --> Router Class Initialized
INFO - 2017-09-06 09:46:04 --> Output Class Initialized
INFO - 2017-09-06 09:46:04 --> Security Class Initialized
DEBUG - 2017-09-06 09:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 09:46:04 --> Input Class Initialized
INFO - 2017-09-06 09:46:04 --> Language Class Initialized
INFO - 2017-09-06 09:46:04 --> Loader Class Initialized
INFO - 2017-09-06 09:46:04 --> Helper loaded: url_helper
INFO - 2017-09-06 09:46:04 --> Database Driver Class Initialized
INFO - 2017-09-06 09:46:04 --> Email Class Initialized
INFO - 2017-09-06 09:46:04 --> Controller Class Initialized
DEBUG - 2017-09-06 09:46:04 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-06 09:46:04 --> Helper loaded: inflector_helper
INFO - 2017-09-06 09:46:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-06 09:46:04 --> Helper loaded: log_helper
INFO - 2017-09-06 09:46:04 --> Model Class Initialized
INFO - 2017-09-06 16:46:04 --> Final output sent to browser
DEBUG - 2017-09-06 16:46:04 --> Total execution time: 0.0790
INFO - 2017-09-06 09:46:06 --> Config Class Initialized
INFO - 2017-09-06 09:46:06 --> Hooks Class Initialized
DEBUG - 2017-09-06 09:46:06 --> UTF-8 Support Enabled
INFO - 2017-09-06 09:46:06 --> Utf8 Class Initialized
INFO - 2017-09-06 09:46:06 --> URI Class Initialized
INFO - 2017-09-06 09:46:06 --> Router Class Initialized
INFO - 2017-09-06 09:46:06 --> Output Class Initialized
INFO - 2017-09-06 09:46:06 --> Security Class Initialized
DEBUG - 2017-09-06 09:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 09:46:06 --> Input Class Initialized
INFO - 2017-09-06 09:46:06 --> Language Class Initialized
INFO - 2017-09-06 09:46:06 --> Loader Class Initialized
INFO - 2017-09-06 09:46:06 --> Helper loaded: url_helper
INFO - 2017-09-06 09:46:06 --> Database Driver Class Initialized
INFO - 2017-09-06 09:46:06 --> Email Class Initialized
INFO - 2017-09-06 09:46:06 --> Controller Class Initialized
DEBUG - 2017-09-06 09:46:06 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-06 09:46:06 --> Helper loaded: inflector_helper
INFO - 2017-09-06 09:46:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-06 09:46:06 --> Helper loaded: log_helper
INFO - 2017-09-06 09:46:06 --> Model Class Initialized
INFO - 2017-09-06 16:46:06 --> Final output sent to browser
DEBUG - 2017-09-06 16:46:06 --> Total execution time: 0.0722
INFO - 2017-09-06 09:46:09 --> Config Class Initialized
INFO - 2017-09-06 09:46:09 --> Hooks Class Initialized
DEBUG - 2017-09-06 09:46:09 --> UTF-8 Support Enabled
INFO - 2017-09-06 09:46:09 --> Utf8 Class Initialized
INFO - 2017-09-06 09:46:09 --> URI Class Initialized
INFO - 2017-09-06 09:46:09 --> Router Class Initialized
INFO - 2017-09-06 09:46:09 --> Output Class Initialized
INFO - 2017-09-06 09:46:09 --> Security Class Initialized
DEBUG - 2017-09-06 09:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 09:46:09 --> Input Class Initialized
INFO - 2017-09-06 09:46:09 --> Language Class Initialized
INFO - 2017-09-06 09:46:09 --> Loader Class Initialized
INFO - 2017-09-06 09:46:09 --> Helper loaded: url_helper
INFO - 2017-09-06 09:46:09 --> Database Driver Class Initialized
INFO - 2017-09-06 09:46:09 --> Email Class Initialized
INFO - 2017-09-06 09:46:09 --> Controller Class Initialized
DEBUG - 2017-09-06 09:46:09 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-06 09:46:09 --> Helper loaded: inflector_helper
INFO - 2017-09-06 09:46:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-06 09:46:09 --> Helper loaded: log_helper
INFO - 2017-09-06 09:46:09 --> Model Class Initialized
INFO - 2017-09-06 16:46:09 --> Final output sent to browser
DEBUG - 2017-09-06 16:46:09 --> Total execution time: 0.0684
INFO - 2017-09-06 09:46:11 --> Config Class Initialized
INFO - 2017-09-06 09:46:11 --> Hooks Class Initialized
DEBUG - 2017-09-06 09:46:11 --> UTF-8 Support Enabled
INFO - 2017-09-06 09:46:11 --> Utf8 Class Initialized
INFO - 2017-09-06 09:46:11 --> URI Class Initialized
INFO - 2017-09-06 09:46:11 --> Router Class Initialized
INFO - 2017-09-06 09:46:11 --> Output Class Initialized
INFO - 2017-09-06 09:46:11 --> Security Class Initialized
DEBUG - 2017-09-06 09:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 09:46:11 --> Input Class Initialized
INFO - 2017-09-06 09:46:11 --> Language Class Initialized
INFO - 2017-09-06 09:46:11 --> Loader Class Initialized
INFO - 2017-09-06 09:46:11 --> Helper loaded: url_helper
INFO - 2017-09-06 09:46:11 --> Database Driver Class Initialized
INFO - 2017-09-06 09:46:11 --> Email Class Initialized
INFO - 2017-09-06 09:46:11 --> Controller Class Initialized
DEBUG - 2017-09-06 09:46:11 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-06 09:46:11 --> Helper loaded: inflector_helper
INFO - 2017-09-06 09:46:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-06 09:46:11 --> Helper loaded: log_helper
INFO - 2017-09-06 09:46:11 --> Model Class Initialized
INFO - 2017-09-06 16:46:11 --> Final output sent to browser
DEBUG - 2017-09-06 16:46:11 --> Total execution time: 0.0716
INFO - 2017-09-06 09:46:13 --> Config Class Initialized
INFO - 2017-09-06 09:46:13 --> Hooks Class Initialized
DEBUG - 2017-09-06 09:46:13 --> UTF-8 Support Enabled
INFO - 2017-09-06 09:46:13 --> Utf8 Class Initialized
INFO - 2017-09-06 09:46:13 --> URI Class Initialized
INFO - 2017-09-06 09:46:13 --> Router Class Initialized
INFO - 2017-09-06 09:46:13 --> Output Class Initialized
INFO - 2017-09-06 09:46:13 --> Security Class Initialized
DEBUG - 2017-09-06 09:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 09:46:13 --> Input Class Initialized
INFO - 2017-09-06 09:46:13 --> Language Class Initialized
INFO - 2017-09-06 09:46:13 --> Loader Class Initialized
INFO - 2017-09-06 09:46:13 --> Helper loaded: url_helper
INFO - 2017-09-06 09:46:13 --> Database Driver Class Initialized
INFO - 2017-09-06 09:46:13 --> Email Class Initialized
INFO - 2017-09-06 09:46:13 --> Controller Class Initialized
DEBUG - 2017-09-06 09:46:13 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-06 09:46:13 --> Helper loaded: inflector_helper
INFO - 2017-09-06 09:46:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-06 09:46:13 --> Helper loaded: log_helper
INFO - 2017-09-06 09:46:13 --> Model Class Initialized
INFO - 2017-09-06 16:46:13 --> Final output sent to browser
DEBUG - 2017-09-06 16:46:13 --> Total execution time: 0.0961
