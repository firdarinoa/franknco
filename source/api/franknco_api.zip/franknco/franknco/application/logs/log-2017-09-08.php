<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-09-08 04:09:16 --> Config Class Initialized
INFO - 2017-09-08 04:09:16 --> Hooks Class Initialized
DEBUG - 2017-09-08 04:09:16 --> UTF-8 Support Enabled
INFO - 2017-09-08 04:09:16 --> Utf8 Class Initialized
INFO - 2017-09-08 04:09:16 --> URI Class Initialized
INFO - 2017-09-08 04:09:16 --> Router Class Initialized
INFO - 2017-09-08 04:09:16 --> Output Class Initialized
INFO - 2017-09-08 04:09:16 --> Security Class Initialized
DEBUG - 2017-09-08 04:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 04:09:16 --> Input Class Initialized
INFO - 2017-09-08 04:09:16 --> Language Class Initialized
INFO - 2017-09-08 04:09:16 --> Loader Class Initialized
INFO - 2017-09-08 04:09:16 --> Helper loaded: url_helper
INFO - 2017-09-08 04:09:16 --> Database Driver Class Initialized
INFO - 2017-09-08 04:09:16 --> Email Class Initialized
INFO - 2017-09-08 04:09:16 --> Controller Class Initialized
DEBUG - 2017-09-08 04:09:16 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 04:09:16 --> Helper loaded: inflector_helper
INFO - 2017-09-08 04:09:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 04:09:16 --> Helper loaded: log_helper
INFO - 2017-09-08 04:09:16 --> Model Class Initialized
INFO - 2017-09-08 11:09:16 --> Final output sent to browser
DEBUG - 2017-09-08 11:09:16 --> Total execution time: 0.3168
INFO - 2017-09-08 04:09:21 --> Config Class Initialized
INFO - 2017-09-08 04:09:21 --> Hooks Class Initialized
DEBUG - 2017-09-08 04:09:21 --> UTF-8 Support Enabled
INFO - 2017-09-08 04:09:21 --> Utf8 Class Initialized
INFO - 2017-09-08 04:09:21 --> URI Class Initialized
INFO - 2017-09-08 04:09:21 --> Router Class Initialized
INFO - 2017-09-08 04:09:21 --> Output Class Initialized
INFO - 2017-09-08 04:09:21 --> Security Class Initialized
DEBUG - 2017-09-08 04:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 04:09:21 --> Input Class Initialized
INFO - 2017-09-08 04:09:21 --> Language Class Initialized
INFO - 2017-09-08 04:09:21 --> Loader Class Initialized
INFO - 2017-09-08 04:09:21 --> Helper loaded: url_helper
INFO - 2017-09-08 04:09:21 --> Database Driver Class Initialized
INFO - 2017-09-08 04:09:21 --> Email Class Initialized
INFO - 2017-09-08 04:09:21 --> Controller Class Initialized
DEBUG - 2017-09-08 04:09:21 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 04:09:21 --> Helper loaded: inflector_helper
INFO - 2017-09-08 04:09:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 04:09:21 --> Helper loaded: log_helper
INFO - 2017-09-08 04:09:21 --> Model Class Initialized
INFO - 2017-09-08 11:09:21 --> Final output sent to browser
DEBUG - 2017-09-08 11:09:21 --> Total execution time: 0.1443
INFO - 2017-09-08 04:09:37 --> Config Class Initialized
INFO - 2017-09-08 04:09:37 --> Hooks Class Initialized
DEBUG - 2017-09-08 04:09:37 --> UTF-8 Support Enabled
INFO - 2017-09-08 04:09:37 --> Utf8 Class Initialized
INFO - 2017-09-08 04:09:37 --> URI Class Initialized
INFO - 2017-09-08 04:09:37 --> Router Class Initialized
INFO - 2017-09-08 04:09:37 --> Output Class Initialized
INFO - 2017-09-08 04:09:37 --> Security Class Initialized
DEBUG - 2017-09-08 04:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 04:09:37 --> Input Class Initialized
INFO - 2017-09-08 04:09:37 --> Language Class Initialized
INFO - 2017-09-08 04:09:37 --> Loader Class Initialized
INFO - 2017-09-08 04:09:37 --> Helper loaded: url_helper
INFO - 2017-09-08 04:09:37 --> Database Driver Class Initialized
INFO - 2017-09-08 04:09:37 --> Email Class Initialized
INFO - 2017-09-08 04:09:37 --> Controller Class Initialized
DEBUG - 2017-09-08 04:09:37 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 04:09:37 --> Helper loaded: inflector_helper
INFO - 2017-09-08 04:09:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 04:09:37 --> Helper loaded: log_helper
INFO - 2017-09-08 04:09:37 --> Model Class Initialized
INFO - 2017-09-08 11:09:37 --> Final output sent to browser
DEBUG - 2017-09-08 11:09:37 --> Total execution time: 0.0579
INFO - 2017-09-08 04:09:37 --> Config Class Initialized
INFO - 2017-09-08 04:09:37 --> Hooks Class Initialized
DEBUG - 2017-09-08 04:09:37 --> UTF-8 Support Enabled
INFO - 2017-09-08 04:09:37 --> Utf8 Class Initialized
INFO - 2017-09-08 04:09:37 --> URI Class Initialized
INFO - 2017-09-08 04:09:37 --> Router Class Initialized
INFO - 2017-09-08 04:09:37 --> Output Class Initialized
INFO - 2017-09-08 04:09:37 --> Security Class Initialized
DEBUG - 2017-09-08 04:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 04:09:37 --> Input Class Initialized
INFO - 2017-09-08 04:09:37 --> Language Class Initialized
INFO - 2017-09-08 04:09:37 --> Loader Class Initialized
INFO - 2017-09-08 04:09:37 --> Helper loaded: url_helper
INFO - 2017-09-08 04:09:37 --> Database Driver Class Initialized
INFO - 2017-09-08 04:09:37 --> Email Class Initialized
INFO - 2017-09-08 04:09:37 --> Controller Class Initialized
DEBUG - 2017-09-08 04:09:37 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 04:09:37 --> Helper loaded: inflector_helper
INFO - 2017-09-08 04:09:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 04:09:37 --> Helper loaded: log_helper
INFO - 2017-09-08 04:09:37 --> Model Class Initialized
INFO - 2017-09-08 11:09:37 --> Final output sent to browser
DEBUG - 2017-09-08 11:09:37 --> Total execution time: 0.0760
INFO - 2017-09-08 04:11:55 --> Config Class Initialized
INFO - 2017-09-08 04:11:55 --> Hooks Class Initialized
DEBUG - 2017-09-08 04:11:55 --> UTF-8 Support Enabled
INFO - 2017-09-08 04:11:55 --> Utf8 Class Initialized
INFO - 2017-09-08 04:11:55 --> URI Class Initialized
INFO - 2017-09-08 04:11:55 --> Router Class Initialized
INFO - 2017-09-08 04:11:55 --> Output Class Initialized
INFO - 2017-09-08 04:11:55 --> Security Class Initialized
DEBUG - 2017-09-08 04:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 04:11:55 --> Input Class Initialized
INFO - 2017-09-08 04:11:55 --> Language Class Initialized
INFO - 2017-09-08 04:11:55 --> Loader Class Initialized
INFO - 2017-09-08 04:11:55 --> Helper loaded: url_helper
INFO - 2017-09-08 04:11:55 --> Database Driver Class Initialized
INFO - 2017-09-08 04:11:55 --> Email Class Initialized
INFO - 2017-09-08 04:11:55 --> Controller Class Initialized
DEBUG - 2017-09-08 04:11:55 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 04:11:55 --> Helper loaded: inflector_helper
INFO - 2017-09-08 04:11:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 04:11:55 --> Helper loaded: log_helper
INFO - 2017-09-08 04:11:55 --> Model Class Initialized
INFO - 2017-09-08 11:11:55 --> Final output sent to browser
DEBUG - 2017-09-08 11:11:55 --> Total execution time: 0.0771
INFO - 2017-09-08 04:11:55 --> Config Class Initialized
INFO - 2017-09-08 04:11:55 --> Hooks Class Initialized
DEBUG - 2017-09-08 04:11:55 --> UTF-8 Support Enabled
INFO - 2017-09-08 04:11:55 --> Utf8 Class Initialized
INFO - 2017-09-08 04:11:55 --> URI Class Initialized
INFO - 2017-09-08 04:11:55 --> Router Class Initialized
INFO - 2017-09-08 04:11:55 --> Output Class Initialized
INFO - 2017-09-08 04:11:55 --> Security Class Initialized
DEBUG - 2017-09-08 04:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 04:11:55 --> Input Class Initialized
INFO - 2017-09-08 04:11:55 --> Language Class Initialized
INFO - 2017-09-08 04:11:55 --> Loader Class Initialized
INFO - 2017-09-08 04:11:55 --> Helper loaded: url_helper
INFO - 2017-09-08 04:11:55 --> Database Driver Class Initialized
INFO - 2017-09-08 04:11:55 --> Email Class Initialized
INFO - 2017-09-08 04:11:55 --> Controller Class Initialized
DEBUG - 2017-09-08 04:11:55 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 04:11:55 --> Helper loaded: inflector_helper
INFO - 2017-09-08 04:11:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 04:11:55 --> Helper loaded: log_helper
INFO - 2017-09-08 04:11:55 --> Model Class Initialized
INFO - 2017-09-08 11:11:55 --> Final output sent to browser
DEBUG - 2017-09-08 11:11:55 --> Total execution time: 0.0780
INFO - 2017-09-08 04:11:58 --> Config Class Initialized
INFO - 2017-09-08 04:11:58 --> Hooks Class Initialized
DEBUG - 2017-09-08 04:11:58 --> UTF-8 Support Enabled
INFO - 2017-09-08 04:11:58 --> Utf8 Class Initialized
INFO - 2017-09-08 04:11:58 --> URI Class Initialized
INFO - 2017-09-08 04:11:58 --> Router Class Initialized
INFO - 2017-09-08 04:11:58 --> Output Class Initialized
INFO - 2017-09-08 04:11:58 --> Security Class Initialized
DEBUG - 2017-09-08 04:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 04:11:58 --> Input Class Initialized
INFO - 2017-09-08 04:11:58 --> Language Class Initialized
INFO - 2017-09-08 04:11:58 --> Loader Class Initialized
INFO - 2017-09-08 04:11:58 --> Helper loaded: url_helper
INFO - 2017-09-08 04:11:58 --> Database Driver Class Initialized
INFO - 2017-09-08 04:11:58 --> Email Class Initialized
INFO - 2017-09-08 04:11:58 --> Controller Class Initialized
DEBUG - 2017-09-08 04:11:58 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 04:11:58 --> Helper loaded: inflector_helper
INFO - 2017-09-08 04:11:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 04:11:58 --> Helper loaded: log_helper
INFO - 2017-09-08 04:11:58 --> Model Class Initialized
INFO - 2017-09-08 11:11:58 --> Final output sent to browser
DEBUG - 2017-09-08 11:11:58 --> Total execution time: 0.0572
INFO - 2017-09-08 04:11:58 --> Config Class Initialized
INFO - 2017-09-08 04:11:58 --> Hooks Class Initialized
DEBUG - 2017-09-08 04:11:58 --> UTF-8 Support Enabled
INFO - 2017-09-08 04:11:58 --> Utf8 Class Initialized
INFO - 2017-09-08 04:11:58 --> URI Class Initialized
INFO - 2017-09-08 04:11:58 --> Router Class Initialized
INFO - 2017-09-08 04:11:58 --> Output Class Initialized
INFO - 2017-09-08 04:11:58 --> Security Class Initialized
DEBUG - 2017-09-08 04:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 04:11:58 --> Input Class Initialized
INFO - 2017-09-08 04:11:58 --> Language Class Initialized
INFO - 2017-09-08 04:11:58 --> Loader Class Initialized
INFO - 2017-09-08 04:11:58 --> Helper loaded: url_helper
INFO - 2017-09-08 04:11:58 --> Database Driver Class Initialized
INFO - 2017-09-08 04:11:58 --> Email Class Initialized
INFO - 2017-09-08 04:11:58 --> Controller Class Initialized
DEBUG - 2017-09-08 04:11:58 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 04:11:58 --> Helper loaded: inflector_helper
INFO - 2017-09-08 04:11:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 04:11:58 --> Helper loaded: log_helper
INFO - 2017-09-08 04:11:58 --> Model Class Initialized
INFO - 2017-09-08 11:11:58 --> Final output sent to browser
DEBUG - 2017-09-08 11:11:58 --> Total execution time: 0.0764
INFO - 2017-09-08 04:12:02 --> Config Class Initialized
INFO - 2017-09-08 04:12:02 --> Hooks Class Initialized
DEBUG - 2017-09-08 04:12:02 --> UTF-8 Support Enabled
INFO - 2017-09-08 04:12:02 --> Utf8 Class Initialized
INFO - 2017-09-08 04:12:02 --> URI Class Initialized
INFO - 2017-09-08 04:12:02 --> Router Class Initialized
INFO - 2017-09-08 04:12:02 --> Output Class Initialized
INFO - 2017-09-08 04:12:02 --> Security Class Initialized
DEBUG - 2017-09-08 04:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 04:12:02 --> Input Class Initialized
INFO - 2017-09-08 04:12:02 --> Language Class Initialized
INFO - 2017-09-08 04:12:02 --> Loader Class Initialized
INFO - 2017-09-08 04:12:02 --> Helper loaded: url_helper
INFO - 2017-09-08 04:12:02 --> Database Driver Class Initialized
INFO - 2017-09-08 04:12:02 --> Email Class Initialized
INFO - 2017-09-08 04:12:02 --> Controller Class Initialized
DEBUG - 2017-09-08 04:12:02 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 04:12:02 --> Helper loaded: inflector_helper
INFO - 2017-09-08 04:12:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 04:12:02 --> Helper loaded: log_helper
INFO - 2017-09-08 04:12:02 --> Model Class Initialized
INFO - 2017-09-08 11:12:02 --> Final output sent to browser
DEBUG - 2017-09-08 11:12:02 --> Total execution time: 0.0702
INFO - 2017-09-08 04:12:02 --> Config Class Initialized
INFO - 2017-09-08 04:12:02 --> Hooks Class Initialized
DEBUG - 2017-09-08 04:12:02 --> UTF-8 Support Enabled
INFO - 2017-09-08 04:12:02 --> Utf8 Class Initialized
INFO - 2017-09-08 04:12:02 --> URI Class Initialized
INFO - 2017-09-08 04:12:02 --> Router Class Initialized
INFO - 2017-09-08 04:12:02 --> Output Class Initialized
INFO - 2017-09-08 04:12:02 --> Security Class Initialized
DEBUG - 2017-09-08 04:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 04:12:02 --> Input Class Initialized
INFO - 2017-09-08 04:12:02 --> Language Class Initialized
INFO - 2017-09-08 04:12:02 --> Loader Class Initialized
INFO - 2017-09-08 04:12:02 --> Helper loaded: url_helper
INFO - 2017-09-08 04:12:02 --> Database Driver Class Initialized
INFO - 2017-09-08 04:12:02 --> Email Class Initialized
INFO - 2017-09-08 04:12:02 --> Controller Class Initialized
DEBUG - 2017-09-08 04:12:02 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 04:12:02 --> Helper loaded: inflector_helper
INFO - 2017-09-08 04:12:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 04:12:02 --> Helper loaded: log_helper
INFO - 2017-09-08 04:12:02 --> Model Class Initialized
INFO - 2017-09-08 11:12:02 --> Final output sent to browser
DEBUG - 2017-09-08 11:12:02 --> Total execution time: 0.1510
INFO - 2017-09-08 06:32:26 --> Config Class Initialized
INFO - 2017-09-08 06:32:26 --> Hooks Class Initialized
DEBUG - 2017-09-08 06:32:26 --> UTF-8 Support Enabled
INFO - 2017-09-08 06:32:26 --> Utf8 Class Initialized
INFO - 2017-09-08 06:32:26 --> URI Class Initialized
INFO - 2017-09-08 06:32:26 --> Router Class Initialized
INFO - 2017-09-08 06:32:26 --> Output Class Initialized
INFO - 2017-09-08 06:32:26 --> Security Class Initialized
DEBUG - 2017-09-08 06:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 06:32:26 --> Input Class Initialized
INFO - 2017-09-08 06:32:26 --> Language Class Initialized
INFO - 2017-09-08 06:32:26 --> Loader Class Initialized
INFO - 2017-09-08 06:32:27 --> Helper loaded: url_helper
INFO - 2017-09-08 06:32:27 --> Database Driver Class Initialized
INFO - 2017-09-08 06:32:27 --> Email Class Initialized
INFO - 2017-09-08 06:32:27 --> Controller Class Initialized
DEBUG - 2017-09-08 06:32:27 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 06:32:27 --> Helper loaded: inflector_helper
INFO - 2017-09-08 06:32:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 06:32:27 --> Helper loaded: log_helper
INFO - 2017-09-08 06:32:27 --> Model Class Initialized
INFO - 2017-09-08 13:32:27 --> Final output sent to browser
DEBUG - 2017-09-08 13:32:27 --> Total execution time: 0.5991
INFO - 2017-09-08 06:32:33 --> Config Class Initialized
INFO - 2017-09-08 06:32:33 --> Hooks Class Initialized
DEBUG - 2017-09-08 06:32:33 --> UTF-8 Support Enabled
INFO - 2017-09-08 06:32:33 --> Utf8 Class Initialized
INFO - 2017-09-08 06:32:33 --> URI Class Initialized
INFO - 2017-09-08 06:32:33 --> Router Class Initialized
INFO - 2017-09-08 06:32:33 --> Output Class Initialized
INFO - 2017-09-08 06:32:33 --> Security Class Initialized
DEBUG - 2017-09-08 06:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 06:32:33 --> Input Class Initialized
INFO - 2017-09-08 06:32:33 --> Language Class Initialized
INFO - 2017-09-08 06:32:33 --> Loader Class Initialized
INFO - 2017-09-08 06:32:33 --> Helper loaded: url_helper
INFO - 2017-09-08 06:32:33 --> Database Driver Class Initialized
INFO - 2017-09-08 06:32:33 --> Email Class Initialized
INFO - 2017-09-08 06:32:33 --> Controller Class Initialized
DEBUG - 2017-09-08 06:32:33 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 06:32:33 --> Helper loaded: inflector_helper
INFO - 2017-09-08 06:32:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 06:32:33 --> Helper loaded: log_helper
INFO - 2017-09-08 06:32:33 --> Model Class Initialized
INFO - 2017-09-08 13:32:33 --> Final output sent to browser
DEBUG - 2017-09-08 13:32:33 --> Total execution time: 0.1110
INFO - 2017-09-08 06:32:36 --> Config Class Initialized
INFO - 2017-09-08 06:32:36 --> Hooks Class Initialized
DEBUG - 2017-09-08 06:32:36 --> UTF-8 Support Enabled
INFO - 2017-09-08 06:32:36 --> Utf8 Class Initialized
INFO - 2017-09-08 06:32:36 --> URI Class Initialized
INFO - 2017-09-08 06:32:36 --> Router Class Initialized
INFO - 2017-09-08 06:32:36 --> Output Class Initialized
INFO - 2017-09-08 06:32:36 --> Security Class Initialized
DEBUG - 2017-09-08 06:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 06:32:36 --> Input Class Initialized
INFO - 2017-09-08 06:32:36 --> Language Class Initialized
INFO - 2017-09-08 06:32:36 --> Loader Class Initialized
INFO - 2017-09-08 06:32:36 --> Helper loaded: url_helper
INFO - 2017-09-08 06:32:36 --> Database Driver Class Initialized
INFO - 2017-09-08 06:32:36 --> Email Class Initialized
INFO - 2017-09-08 06:32:36 --> Controller Class Initialized
DEBUG - 2017-09-08 06:32:36 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 06:32:36 --> Helper loaded: inflector_helper
INFO - 2017-09-08 06:32:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 06:32:36 --> Helper loaded: log_helper
INFO - 2017-09-08 06:32:36 --> Model Class Initialized
INFO - 2017-09-08 13:32:36 --> Final output sent to browser
DEBUG - 2017-09-08 13:32:36 --> Total execution time: 0.0952
INFO - 2017-09-08 06:33:00 --> Config Class Initialized
INFO - 2017-09-08 06:33:00 --> Hooks Class Initialized
DEBUG - 2017-09-08 06:33:00 --> UTF-8 Support Enabled
INFO - 2017-09-08 06:33:00 --> Utf8 Class Initialized
INFO - 2017-09-08 06:33:00 --> URI Class Initialized
INFO - 2017-09-08 06:33:00 --> Router Class Initialized
INFO - 2017-09-08 06:33:00 --> Output Class Initialized
INFO - 2017-09-08 06:33:00 --> Security Class Initialized
DEBUG - 2017-09-08 06:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 06:33:00 --> Input Class Initialized
INFO - 2017-09-08 06:33:00 --> Language Class Initialized
INFO - 2017-09-08 06:33:00 --> Loader Class Initialized
INFO - 2017-09-08 06:33:00 --> Helper loaded: url_helper
INFO - 2017-09-08 06:33:00 --> Database Driver Class Initialized
INFO - 2017-09-08 06:33:00 --> Email Class Initialized
INFO - 2017-09-08 06:33:00 --> Controller Class Initialized
DEBUG - 2017-09-08 06:33:00 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 06:33:00 --> Helper loaded: inflector_helper
INFO - 2017-09-08 06:33:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 06:33:00 --> Helper loaded: log_helper
INFO - 2017-09-08 06:33:00 --> Model Class Initialized
ERROR - 2017-09-08 13:33:00 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\franknco\application\models\api_model.php 422
INFO - 2017-09-08 13:33:00 --> Final output sent to browser
DEBUG - 2017-09-08 13:33:00 --> Total execution time: 0.0895
INFO - 2017-09-08 06:33:11 --> Config Class Initialized
INFO - 2017-09-08 06:33:11 --> Hooks Class Initialized
DEBUG - 2017-09-08 06:33:11 --> UTF-8 Support Enabled
INFO - 2017-09-08 06:33:11 --> Utf8 Class Initialized
INFO - 2017-09-08 06:33:11 --> URI Class Initialized
INFO - 2017-09-08 06:33:11 --> Router Class Initialized
INFO - 2017-09-08 06:33:11 --> Output Class Initialized
INFO - 2017-09-08 06:33:11 --> Security Class Initialized
DEBUG - 2017-09-08 06:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 06:33:11 --> Input Class Initialized
INFO - 2017-09-08 06:33:11 --> Language Class Initialized
INFO - 2017-09-08 06:33:11 --> Loader Class Initialized
INFO - 2017-09-08 06:33:11 --> Helper loaded: url_helper
INFO - 2017-09-08 06:33:11 --> Database Driver Class Initialized
INFO - 2017-09-08 06:33:11 --> Email Class Initialized
INFO - 2017-09-08 06:33:11 --> Controller Class Initialized
DEBUG - 2017-09-08 06:33:11 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 06:33:11 --> Helper loaded: inflector_helper
INFO - 2017-09-08 06:33:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 06:33:11 --> Helper loaded: log_helper
INFO - 2017-09-08 06:33:11 --> Model Class Initialized
ERROR - 2017-09-08 13:33:11 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\franknco\application\models\api_model.php 422
INFO - 2017-09-08 13:33:11 --> Final output sent to browser
DEBUG - 2017-09-08 13:33:11 --> Total execution time: 0.0695
INFO - 2017-09-08 06:33:15 --> Config Class Initialized
INFO - 2017-09-08 06:33:15 --> Hooks Class Initialized
DEBUG - 2017-09-08 06:33:15 --> UTF-8 Support Enabled
INFO - 2017-09-08 06:33:15 --> Utf8 Class Initialized
INFO - 2017-09-08 06:33:15 --> URI Class Initialized
INFO - 2017-09-08 06:33:15 --> Router Class Initialized
INFO - 2017-09-08 06:33:15 --> Output Class Initialized
INFO - 2017-09-08 06:33:15 --> Security Class Initialized
DEBUG - 2017-09-08 06:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 06:33:15 --> Input Class Initialized
INFO - 2017-09-08 06:33:15 --> Language Class Initialized
INFO - 2017-09-08 06:33:15 --> Loader Class Initialized
INFO - 2017-09-08 06:33:15 --> Helper loaded: url_helper
INFO - 2017-09-08 06:33:15 --> Database Driver Class Initialized
INFO - 2017-09-08 06:33:15 --> Email Class Initialized
INFO - 2017-09-08 06:33:15 --> Controller Class Initialized
DEBUG - 2017-09-08 06:33:15 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 06:33:15 --> Helper loaded: inflector_helper
INFO - 2017-09-08 06:33:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 06:33:15 --> Helper loaded: log_helper
INFO - 2017-09-08 06:33:15 --> Model Class Initialized
INFO - 2017-09-08 13:33:15 --> Final output sent to browser
DEBUG - 2017-09-08 13:33:15 --> Total execution time: 0.0606
INFO - 2017-09-08 06:33:15 --> Config Class Initialized
INFO - 2017-09-08 06:33:15 --> Hooks Class Initialized
DEBUG - 2017-09-08 06:33:15 --> UTF-8 Support Enabled
INFO - 2017-09-08 06:33:15 --> Utf8 Class Initialized
INFO - 2017-09-08 06:33:15 --> URI Class Initialized
INFO - 2017-09-08 06:33:15 --> Router Class Initialized
INFO - 2017-09-08 06:33:15 --> Output Class Initialized
INFO - 2017-09-08 06:33:15 --> Security Class Initialized
DEBUG - 2017-09-08 06:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 06:33:15 --> Input Class Initialized
INFO - 2017-09-08 06:33:15 --> Language Class Initialized
INFO - 2017-09-08 06:33:15 --> Loader Class Initialized
INFO - 2017-09-08 06:33:15 --> Helper loaded: url_helper
INFO - 2017-09-08 06:33:15 --> Database Driver Class Initialized
INFO - 2017-09-08 06:33:15 --> Email Class Initialized
INFO - 2017-09-08 06:33:15 --> Controller Class Initialized
DEBUG - 2017-09-08 06:33:15 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 06:33:15 --> Helper loaded: inflector_helper
INFO - 2017-09-08 06:33:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 06:33:15 --> Helper loaded: log_helper
INFO - 2017-09-08 06:33:15 --> Model Class Initialized
INFO - 2017-09-08 13:33:15 --> Final output sent to browser
DEBUG - 2017-09-08 13:33:15 --> Total execution time: 0.0830
INFO - 2017-09-08 06:43:23 --> Config Class Initialized
INFO - 2017-09-08 06:43:23 --> Hooks Class Initialized
DEBUG - 2017-09-08 06:43:23 --> UTF-8 Support Enabled
INFO - 2017-09-08 06:43:23 --> Utf8 Class Initialized
INFO - 2017-09-08 06:43:23 --> URI Class Initialized
INFO - 2017-09-08 06:43:23 --> Router Class Initialized
INFO - 2017-09-08 06:43:23 --> Output Class Initialized
INFO - 2017-09-08 06:43:23 --> Security Class Initialized
DEBUG - 2017-09-08 06:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 06:43:23 --> Input Class Initialized
INFO - 2017-09-08 06:43:23 --> Language Class Initialized
INFO - 2017-09-08 06:43:23 --> Loader Class Initialized
INFO - 2017-09-08 06:43:23 --> Helper loaded: url_helper
INFO - 2017-09-08 06:43:23 --> Database Driver Class Initialized
INFO - 2017-09-08 06:43:23 --> Email Class Initialized
INFO - 2017-09-08 06:43:23 --> Controller Class Initialized
DEBUG - 2017-09-08 06:43:23 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 06:43:23 --> Helper loaded: inflector_helper
INFO - 2017-09-08 06:43:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 06:43:23 --> Helper loaded: log_helper
INFO - 2017-09-08 06:43:23 --> Model Class Initialized
INFO - 2017-09-08 13:43:23 --> Final output sent to browser
DEBUG - 2017-09-08 13:43:23 --> Total execution time: 0.0680
INFO - 2017-09-08 06:43:38 --> Config Class Initialized
INFO - 2017-09-08 06:43:38 --> Hooks Class Initialized
DEBUG - 2017-09-08 06:43:38 --> UTF-8 Support Enabled
INFO - 2017-09-08 06:43:38 --> Utf8 Class Initialized
INFO - 2017-09-08 06:43:38 --> URI Class Initialized
INFO - 2017-09-08 06:43:38 --> Router Class Initialized
INFO - 2017-09-08 06:43:38 --> Output Class Initialized
INFO - 2017-09-08 06:43:38 --> Security Class Initialized
DEBUG - 2017-09-08 06:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 06:43:38 --> Input Class Initialized
INFO - 2017-09-08 06:43:38 --> Language Class Initialized
INFO - 2017-09-08 06:43:38 --> Loader Class Initialized
INFO - 2017-09-08 06:43:38 --> Helper loaded: url_helper
INFO - 2017-09-08 06:43:38 --> Database Driver Class Initialized
INFO - 2017-09-08 06:43:38 --> Email Class Initialized
INFO - 2017-09-08 06:43:38 --> Controller Class Initialized
DEBUG - 2017-09-08 06:43:38 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 06:43:38 --> Helper loaded: inflector_helper
INFO - 2017-09-08 06:43:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 06:43:38 --> Helper loaded: log_helper
INFO - 2017-09-08 06:43:38 --> Model Class Initialized
INFO - 2017-09-08 13:43:38 --> Final output sent to browser
DEBUG - 2017-09-08 13:43:38 --> Total execution time: 0.0574
INFO - 2017-09-08 06:43:53 --> Config Class Initialized
INFO - 2017-09-08 06:43:53 --> Hooks Class Initialized
DEBUG - 2017-09-08 06:43:53 --> UTF-8 Support Enabled
INFO - 2017-09-08 06:43:53 --> Utf8 Class Initialized
INFO - 2017-09-08 06:43:53 --> URI Class Initialized
INFO - 2017-09-08 06:43:53 --> Router Class Initialized
INFO - 2017-09-08 06:43:53 --> Output Class Initialized
INFO - 2017-09-08 06:43:53 --> Security Class Initialized
DEBUG - 2017-09-08 06:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 06:43:53 --> Input Class Initialized
INFO - 2017-09-08 06:43:53 --> Language Class Initialized
INFO - 2017-09-08 06:43:53 --> Loader Class Initialized
INFO - 2017-09-08 06:43:53 --> Helper loaded: url_helper
INFO - 2017-09-08 06:43:53 --> Database Driver Class Initialized
INFO - 2017-09-08 06:43:53 --> Email Class Initialized
INFO - 2017-09-08 06:43:53 --> Controller Class Initialized
DEBUG - 2017-09-08 06:43:53 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 06:43:53 --> Helper loaded: inflector_helper
INFO - 2017-09-08 06:43:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 06:43:53 --> Helper loaded: log_helper
INFO - 2017-09-08 06:43:53 --> Model Class Initialized
INFO - 2017-09-08 13:43:53 --> Final output sent to browser
DEBUG - 2017-09-08 13:43:53 --> Total execution time: 0.0738
INFO - 2017-09-08 06:52:14 --> Config Class Initialized
INFO - 2017-09-08 06:52:14 --> Hooks Class Initialized
DEBUG - 2017-09-08 06:52:14 --> UTF-8 Support Enabled
INFO - 2017-09-08 06:52:14 --> Utf8 Class Initialized
INFO - 2017-09-08 06:52:14 --> URI Class Initialized
INFO - 2017-09-08 06:52:14 --> Router Class Initialized
INFO - 2017-09-08 06:52:14 --> Output Class Initialized
INFO - 2017-09-08 06:52:14 --> Security Class Initialized
DEBUG - 2017-09-08 06:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 06:52:14 --> Input Class Initialized
INFO - 2017-09-08 06:52:14 --> Language Class Initialized
INFO - 2017-09-08 06:52:14 --> Loader Class Initialized
INFO - 2017-09-08 06:52:14 --> Helper loaded: url_helper
INFO - 2017-09-08 06:52:14 --> Database Driver Class Initialized
INFO - 2017-09-08 06:52:14 --> Email Class Initialized
INFO - 2017-09-08 06:52:14 --> Controller Class Initialized
DEBUG - 2017-09-08 06:52:14 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 06:52:14 --> Helper loaded: inflector_helper
INFO - 2017-09-08 06:52:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 06:52:14 --> Helper loaded: log_helper
INFO - 2017-09-08 06:52:14 --> Model Class Initialized
INFO - 2017-09-08 13:52:14 --> Final output sent to browser
DEBUG - 2017-09-08 13:52:14 --> Total execution time: 0.0577
INFO - 2017-09-08 06:52:35 --> Config Class Initialized
INFO - 2017-09-08 06:52:35 --> Hooks Class Initialized
DEBUG - 2017-09-08 06:52:35 --> UTF-8 Support Enabled
INFO - 2017-09-08 06:52:35 --> Utf8 Class Initialized
INFO - 2017-09-08 06:52:35 --> URI Class Initialized
INFO - 2017-09-08 06:52:35 --> Router Class Initialized
INFO - 2017-09-08 06:52:35 --> Output Class Initialized
INFO - 2017-09-08 06:52:35 --> Security Class Initialized
DEBUG - 2017-09-08 06:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 06:52:35 --> Input Class Initialized
INFO - 2017-09-08 06:52:35 --> Language Class Initialized
INFO - 2017-09-08 06:52:35 --> Loader Class Initialized
INFO - 2017-09-08 06:52:35 --> Helper loaded: url_helper
INFO - 2017-09-08 06:52:35 --> Database Driver Class Initialized
INFO - 2017-09-08 06:52:35 --> Email Class Initialized
INFO - 2017-09-08 06:52:35 --> Controller Class Initialized
DEBUG - 2017-09-08 06:52:35 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 06:52:35 --> Helper loaded: inflector_helper
INFO - 2017-09-08 06:52:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 06:52:35 --> Helper loaded: log_helper
INFO - 2017-09-08 06:52:35 --> Model Class Initialized
INFO - 2017-09-08 13:52:35 --> Final output sent to browser
DEBUG - 2017-09-08 13:52:35 --> Total execution time: 0.0546
INFO - 2017-09-08 06:52:49 --> Config Class Initialized
INFO - 2017-09-08 06:52:49 --> Hooks Class Initialized
DEBUG - 2017-09-08 06:52:49 --> UTF-8 Support Enabled
INFO - 2017-09-08 06:52:49 --> Utf8 Class Initialized
INFO - 2017-09-08 06:52:49 --> URI Class Initialized
INFO - 2017-09-08 06:52:49 --> Router Class Initialized
INFO - 2017-09-08 06:52:49 --> Output Class Initialized
INFO - 2017-09-08 06:52:49 --> Security Class Initialized
DEBUG - 2017-09-08 06:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 06:52:49 --> Input Class Initialized
INFO - 2017-09-08 06:52:49 --> Language Class Initialized
INFO - 2017-09-08 06:52:49 --> Loader Class Initialized
INFO - 2017-09-08 06:52:49 --> Helper loaded: url_helper
INFO - 2017-09-08 06:52:49 --> Database Driver Class Initialized
INFO - 2017-09-08 06:52:49 --> Email Class Initialized
INFO - 2017-09-08 06:52:49 --> Controller Class Initialized
DEBUG - 2017-09-08 06:52:49 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 06:52:49 --> Helper loaded: inflector_helper
INFO - 2017-09-08 06:52:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 06:52:49 --> Helper loaded: log_helper
INFO - 2017-09-08 06:52:49 --> Model Class Initialized
INFO - 2017-09-08 13:52:49 --> Final output sent to browser
DEBUG - 2017-09-08 13:52:49 --> Total execution time: 0.0529
INFO - 2017-09-08 06:52:57 --> Config Class Initialized
INFO - 2017-09-08 06:52:57 --> Hooks Class Initialized
DEBUG - 2017-09-08 06:52:57 --> UTF-8 Support Enabled
INFO - 2017-09-08 06:52:57 --> Utf8 Class Initialized
INFO - 2017-09-08 06:52:57 --> URI Class Initialized
INFO - 2017-09-08 06:52:57 --> Router Class Initialized
INFO - 2017-09-08 06:52:57 --> Output Class Initialized
INFO - 2017-09-08 06:52:57 --> Security Class Initialized
DEBUG - 2017-09-08 06:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 06:52:57 --> Input Class Initialized
INFO - 2017-09-08 06:52:57 --> Language Class Initialized
INFO - 2017-09-08 06:52:57 --> Loader Class Initialized
INFO - 2017-09-08 06:52:57 --> Helper loaded: url_helper
INFO - 2017-09-08 06:52:57 --> Database Driver Class Initialized
INFO - 2017-09-08 06:52:57 --> Email Class Initialized
INFO - 2017-09-08 06:52:57 --> Controller Class Initialized
DEBUG - 2017-09-08 06:52:57 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 06:52:57 --> Helper loaded: inflector_helper
INFO - 2017-09-08 06:52:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 06:52:57 --> Helper loaded: log_helper
INFO - 2017-09-08 06:52:57 --> Model Class Initialized
INFO - 2017-09-08 13:52:57 --> Final output sent to browser
DEBUG - 2017-09-08 13:52:57 --> Total execution time: 0.0545
INFO - 2017-09-08 06:53:20 --> Config Class Initialized
INFO - 2017-09-08 06:53:20 --> Hooks Class Initialized
DEBUG - 2017-09-08 06:53:20 --> UTF-8 Support Enabled
INFO - 2017-09-08 06:53:20 --> Utf8 Class Initialized
INFO - 2017-09-08 06:53:20 --> URI Class Initialized
INFO - 2017-09-08 06:53:20 --> Router Class Initialized
INFO - 2017-09-08 06:53:20 --> Output Class Initialized
INFO - 2017-09-08 06:53:20 --> Security Class Initialized
DEBUG - 2017-09-08 06:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 06:53:20 --> Input Class Initialized
INFO - 2017-09-08 06:53:20 --> Language Class Initialized
INFO - 2017-09-08 06:53:20 --> Loader Class Initialized
INFO - 2017-09-08 06:53:20 --> Helper loaded: url_helper
INFO - 2017-09-08 06:53:20 --> Database Driver Class Initialized
INFO - 2017-09-08 06:53:20 --> Email Class Initialized
INFO - 2017-09-08 06:53:20 --> Controller Class Initialized
DEBUG - 2017-09-08 06:53:20 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 06:53:20 --> Helper loaded: inflector_helper
INFO - 2017-09-08 06:53:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 06:53:20 --> Helper loaded: log_helper
INFO - 2017-09-08 06:53:20 --> Model Class Initialized
INFO - 2017-09-08 13:53:20 --> Final output sent to browser
DEBUG - 2017-09-08 13:53:20 --> Total execution time: 0.0535
INFO - 2017-09-08 06:53:26 --> Config Class Initialized
INFO - 2017-09-08 06:53:26 --> Hooks Class Initialized
DEBUG - 2017-09-08 06:53:26 --> UTF-8 Support Enabled
INFO - 2017-09-08 06:53:26 --> Utf8 Class Initialized
INFO - 2017-09-08 06:53:26 --> URI Class Initialized
INFO - 2017-09-08 06:53:26 --> Router Class Initialized
INFO - 2017-09-08 06:53:26 --> Output Class Initialized
INFO - 2017-09-08 06:53:26 --> Security Class Initialized
DEBUG - 2017-09-08 06:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 06:53:26 --> Input Class Initialized
INFO - 2017-09-08 06:53:26 --> Language Class Initialized
INFO - 2017-09-08 06:53:26 --> Loader Class Initialized
INFO - 2017-09-08 06:53:26 --> Helper loaded: url_helper
INFO - 2017-09-08 06:53:26 --> Database Driver Class Initialized
INFO - 2017-09-08 06:53:26 --> Email Class Initialized
INFO - 2017-09-08 06:53:26 --> Controller Class Initialized
DEBUG - 2017-09-08 06:53:26 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 06:53:26 --> Helper loaded: inflector_helper
INFO - 2017-09-08 06:53:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 06:53:26 --> Helper loaded: log_helper
INFO - 2017-09-08 06:53:26 --> Model Class Initialized
INFO - 2017-09-08 13:53:26 --> Final output sent to browser
DEBUG - 2017-09-08 13:53:26 --> Total execution time: 0.0543
INFO - 2017-09-08 06:53:52 --> Config Class Initialized
INFO - 2017-09-08 06:53:52 --> Hooks Class Initialized
DEBUG - 2017-09-08 06:53:52 --> UTF-8 Support Enabled
INFO - 2017-09-08 06:53:52 --> Utf8 Class Initialized
INFO - 2017-09-08 06:53:52 --> URI Class Initialized
INFO - 2017-09-08 06:53:52 --> Router Class Initialized
INFO - 2017-09-08 06:53:52 --> Output Class Initialized
INFO - 2017-09-08 06:53:52 --> Security Class Initialized
DEBUG - 2017-09-08 06:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 06:53:52 --> Input Class Initialized
INFO - 2017-09-08 06:53:52 --> Language Class Initialized
INFO - 2017-09-08 06:53:52 --> Loader Class Initialized
INFO - 2017-09-08 06:53:52 --> Helper loaded: url_helper
INFO - 2017-09-08 06:53:52 --> Database Driver Class Initialized
INFO - 2017-09-08 06:53:52 --> Email Class Initialized
INFO - 2017-09-08 06:53:52 --> Controller Class Initialized
DEBUG - 2017-09-08 06:53:52 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 06:53:52 --> Helper loaded: inflector_helper
INFO - 2017-09-08 06:53:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 06:53:52 --> Helper loaded: log_helper
INFO - 2017-09-08 06:53:52 --> Model Class Initialized
INFO - 2017-09-08 13:53:52 --> Final output sent to browser
DEBUG - 2017-09-08 13:53:52 --> Total execution time: 0.0566
INFO - 2017-09-08 06:54:00 --> Config Class Initialized
INFO - 2017-09-08 06:54:00 --> Hooks Class Initialized
DEBUG - 2017-09-08 06:54:00 --> UTF-8 Support Enabled
INFO - 2017-09-08 06:54:00 --> Utf8 Class Initialized
INFO - 2017-09-08 06:54:00 --> URI Class Initialized
INFO - 2017-09-08 06:54:00 --> Router Class Initialized
INFO - 2017-09-08 06:54:00 --> Output Class Initialized
INFO - 2017-09-08 06:54:00 --> Security Class Initialized
DEBUG - 2017-09-08 06:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 06:54:00 --> Input Class Initialized
INFO - 2017-09-08 06:54:00 --> Language Class Initialized
INFO - 2017-09-08 06:54:00 --> Loader Class Initialized
INFO - 2017-09-08 06:54:00 --> Helper loaded: url_helper
INFO - 2017-09-08 06:54:00 --> Database Driver Class Initialized
INFO - 2017-09-08 06:54:00 --> Email Class Initialized
INFO - 2017-09-08 06:54:00 --> Controller Class Initialized
DEBUG - 2017-09-08 06:54:00 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 06:54:00 --> Helper loaded: inflector_helper
INFO - 2017-09-08 06:54:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 06:54:00 --> Helper loaded: log_helper
INFO - 2017-09-08 06:54:00 --> Model Class Initialized
INFO - 2017-09-08 13:54:00 --> Final output sent to browser
DEBUG - 2017-09-08 13:54:00 --> Total execution time: 0.0604
INFO - 2017-09-08 06:54:04 --> Config Class Initialized
INFO - 2017-09-08 06:54:04 --> Hooks Class Initialized
DEBUG - 2017-09-08 06:54:04 --> UTF-8 Support Enabled
INFO - 2017-09-08 06:54:04 --> Utf8 Class Initialized
INFO - 2017-09-08 06:54:04 --> URI Class Initialized
INFO - 2017-09-08 06:54:04 --> Router Class Initialized
INFO - 2017-09-08 06:54:04 --> Output Class Initialized
INFO - 2017-09-08 06:54:04 --> Security Class Initialized
DEBUG - 2017-09-08 06:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 06:54:04 --> Input Class Initialized
INFO - 2017-09-08 06:54:04 --> Language Class Initialized
INFO - 2017-09-08 06:54:04 --> Loader Class Initialized
INFO - 2017-09-08 06:54:04 --> Helper loaded: url_helper
INFO - 2017-09-08 06:54:04 --> Database Driver Class Initialized
INFO - 2017-09-08 06:54:04 --> Email Class Initialized
INFO - 2017-09-08 06:54:04 --> Controller Class Initialized
DEBUG - 2017-09-08 06:54:04 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 06:54:04 --> Helper loaded: inflector_helper
INFO - 2017-09-08 06:54:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 06:54:04 --> Helper loaded: log_helper
INFO - 2017-09-08 06:54:04 --> Model Class Initialized
INFO - 2017-09-08 13:54:04 --> Final output sent to browser
DEBUG - 2017-09-08 13:54:04 --> Total execution time: 0.0613
INFO - 2017-09-08 06:54:24 --> Config Class Initialized
INFO - 2017-09-08 06:54:24 --> Hooks Class Initialized
DEBUG - 2017-09-08 06:54:24 --> UTF-8 Support Enabled
INFO - 2017-09-08 06:54:24 --> Utf8 Class Initialized
INFO - 2017-09-08 06:54:24 --> URI Class Initialized
INFO - 2017-09-08 06:54:24 --> Router Class Initialized
INFO - 2017-09-08 06:54:24 --> Output Class Initialized
INFO - 2017-09-08 06:54:24 --> Security Class Initialized
DEBUG - 2017-09-08 06:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 06:54:24 --> Input Class Initialized
INFO - 2017-09-08 06:54:24 --> Language Class Initialized
INFO - 2017-09-08 06:54:24 --> Loader Class Initialized
INFO - 2017-09-08 06:54:24 --> Helper loaded: url_helper
INFO - 2017-09-08 06:54:24 --> Database Driver Class Initialized
INFO - 2017-09-08 06:54:24 --> Email Class Initialized
INFO - 2017-09-08 06:54:24 --> Controller Class Initialized
DEBUG - 2017-09-08 06:54:24 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 06:54:24 --> Helper loaded: inflector_helper
INFO - 2017-09-08 06:54:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 06:54:24 --> Helper loaded: log_helper
INFO - 2017-09-08 06:54:24 --> Model Class Initialized
INFO - 2017-09-08 13:54:24 --> Final output sent to browser
DEBUG - 2017-09-08 13:54:24 --> Total execution time: 0.0706
INFO - 2017-09-08 06:54:31 --> Config Class Initialized
INFO - 2017-09-08 06:54:31 --> Hooks Class Initialized
DEBUG - 2017-09-08 06:54:31 --> UTF-8 Support Enabled
INFO - 2017-09-08 06:54:31 --> Utf8 Class Initialized
INFO - 2017-09-08 06:54:31 --> URI Class Initialized
INFO - 2017-09-08 06:54:31 --> Router Class Initialized
INFO - 2017-09-08 06:54:31 --> Output Class Initialized
INFO - 2017-09-08 06:54:31 --> Security Class Initialized
DEBUG - 2017-09-08 06:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 06:54:31 --> Input Class Initialized
INFO - 2017-09-08 06:54:31 --> Language Class Initialized
INFO - 2017-09-08 06:54:31 --> Loader Class Initialized
INFO - 2017-09-08 06:54:31 --> Helper loaded: url_helper
INFO - 2017-09-08 06:54:31 --> Database Driver Class Initialized
INFO - 2017-09-08 06:54:31 --> Email Class Initialized
INFO - 2017-09-08 06:54:31 --> Controller Class Initialized
DEBUG - 2017-09-08 06:54:31 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 06:54:31 --> Helper loaded: inflector_helper
INFO - 2017-09-08 06:54:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 06:54:31 --> Helper loaded: log_helper
INFO - 2017-09-08 06:54:31 --> Model Class Initialized
INFO - 2017-09-08 13:54:31 --> Final output sent to browser
DEBUG - 2017-09-08 13:54:31 --> Total execution time: 0.0572
INFO - 2017-09-08 06:54:54 --> Config Class Initialized
INFO - 2017-09-08 06:54:54 --> Hooks Class Initialized
DEBUG - 2017-09-08 06:54:54 --> UTF-8 Support Enabled
INFO - 2017-09-08 06:54:54 --> Utf8 Class Initialized
INFO - 2017-09-08 06:54:54 --> URI Class Initialized
INFO - 2017-09-08 06:54:54 --> Router Class Initialized
INFO - 2017-09-08 06:54:54 --> Output Class Initialized
INFO - 2017-09-08 06:54:54 --> Security Class Initialized
DEBUG - 2017-09-08 06:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 06:54:54 --> Input Class Initialized
INFO - 2017-09-08 06:54:54 --> Language Class Initialized
INFO - 2017-09-08 06:54:54 --> Loader Class Initialized
INFO - 2017-09-08 06:54:54 --> Helper loaded: url_helper
INFO - 2017-09-08 06:54:54 --> Database Driver Class Initialized
INFO - 2017-09-08 06:54:54 --> Email Class Initialized
INFO - 2017-09-08 06:54:54 --> Controller Class Initialized
DEBUG - 2017-09-08 06:54:54 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 06:54:54 --> Helper loaded: inflector_helper
INFO - 2017-09-08 06:54:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 06:54:54 --> Helper loaded: log_helper
INFO - 2017-09-08 06:54:54 --> Model Class Initialized
INFO - 2017-09-08 13:54:54 --> Final output sent to browser
DEBUG - 2017-09-08 13:54:54 --> Total execution time: 0.0558
INFO - 2017-09-08 06:55:02 --> Config Class Initialized
INFO - 2017-09-08 06:55:02 --> Hooks Class Initialized
DEBUG - 2017-09-08 06:55:02 --> UTF-8 Support Enabled
INFO - 2017-09-08 06:55:02 --> Utf8 Class Initialized
INFO - 2017-09-08 06:55:02 --> URI Class Initialized
INFO - 2017-09-08 06:55:02 --> Router Class Initialized
INFO - 2017-09-08 06:55:02 --> Output Class Initialized
INFO - 2017-09-08 06:55:02 --> Security Class Initialized
DEBUG - 2017-09-08 06:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 06:55:02 --> Input Class Initialized
INFO - 2017-09-08 06:55:02 --> Language Class Initialized
INFO - 2017-09-08 06:55:02 --> Loader Class Initialized
INFO - 2017-09-08 06:55:02 --> Helper loaded: url_helper
INFO - 2017-09-08 06:55:02 --> Database Driver Class Initialized
INFO - 2017-09-08 06:55:02 --> Email Class Initialized
INFO - 2017-09-08 06:55:02 --> Controller Class Initialized
DEBUG - 2017-09-08 06:55:02 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 06:55:02 --> Helper loaded: inflector_helper
INFO - 2017-09-08 06:55:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 06:55:02 --> Helper loaded: log_helper
INFO - 2017-09-08 06:55:02 --> Model Class Initialized
INFO - 2017-09-08 13:55:02 --> Final output sent to browser
DEBUG - 2017-09-08 13:55:02 --> Total execution time: 0.0650
INFO - 2017-09-08 06:55:15 --> Config Class Initialized
INFO - 2017-09-08 06:55:15 --> Hooks Class Initialized
DEBUG - 2017-09-08 06:55:15 --> UTF-8 Support Enabled
INFO - 2017-09-08 06:55:15 --> Utf8 Class Initialized
INFO - 2017-09-08 06:55:15 --> URI Class Initialized
INFO - 2017-09-08 06:55:15 --> Router Class Initialized
INFO - 2017-09-08 06:55:15 --> Output Class Initialized
INFO - 2017-09-08 06:55:15 --> Security Class Initialized
DEBUG - 2017-09-08 06:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 06:55:15 --> Input Class Initialized
INFO - 2017-09-08 06:55:15 --> Language Class Initialized
INFO - 2017-09-08 06:55:15 --> Loader Class Initialized
INFO - 2017-09-08 06:55:15 --> Helper loaded: url_helper
INFO - 2017-09-08 06:55:15 --> Database Driver Class Initialized
INFO - 2017-09-08 06:55:15 --> Email Class Initialized
INFO - 2017-09-08 06:55:15 --> Controller Class Initialized
DEBUG - 2017-09-08 06:55:15 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 06:55:15 --> Helper loaded: inflector_helper
INFO - 2017-09-08 06:55:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 06:55:15 --> Helper loaded: log_helper
INFO - 2017-09-08 06:55:15 --> Model Class Initialized
INFO - 2017-09-08 13:55:15 --> Final output sent to browser
DEBUG - 2017-09-08 13:55:15 --> Total execution time: 0.0564
INFO - 2017-09-08 06:55:27 --> Config Class Initialized
INFO - 2017-09-08 06:55:27 --> Hooks Class Initialized
DEBUG - 2017-09-08 06:55:27 --> UTF-8 Support Enabled
INFO - 2017-09-08 06:55:27 --> Utf8 Class Initialized
INFO - 2017-09-08 06:55:27 --> URI Class Initialized
INFO - 2017-09-08 06:55:27 --> Router Class Initialized
INFO - 2017-09-08 06:55:27 --> Output Class Initialized
INFO - 2017-09-08 06:55:27 --> Security Class Initialized
DEBUG - 2017-09-08 06:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 06:55:27 --> Input Class Initialized
INFO - 2017-09-08 06:55:27 --> Language Class Initialized
INFO - 2017-09-08 06:55:27 --> Loader Class Initialized
INFO - 2017-09-08 06:55:27 --> Helper loaded: url_helper
INFO - 2017-09-08 06:55:27 --> Database Driver Class Initialized
INFO - 2017-09-08 06:55:27 --> Email Class Initialized
INFO - 2017-09-08 06:55:27 --> Controller Class Initialized
DEBUG - 2017-09-08 06:55:27 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 06:55:27 --> Helper loaded: inflector_helper
INFO - 2017-09-08 06:55:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 06:55:27 --> Helper loaded: log_helper
INFO - 2017-09-08 06:55:27 --> Model Class Initialized
INFO - 2017-09-08 13:55:27 --> Final output sent to browser
DEBUG - 2017-09-08 13:55:27 --> Total execution time: 0.0884
INFO - 2017-09-08 06:55:53 --> Config Class Initialized
INFO - 2017-09-08 06:55:53 --> Hooks Class Initialized
DEBUG - 2017-09-08 06:55:54 --> UTF-8 Support Enabled
INFO - 2017-09-08 06:55:54 --> Utf8 Class Initialized
INFO - 2017-09-08 06:55:54 --> URI Class Initialized
INFO - 2017-09-08 06:55:54 --> Router Class Initialized
INFO - 2017-09-08 06:55:54 --> Output Class Initialized
INFO - 2017-09-08 06:55:54 --> Security Class Initialized
DEBUG - 2017-09-08 06:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 06:55:54 --> Input Class Initialized
INFO - 2017-09-08 06:55:54 --> Language Class Initialized
INFO - 2017-09-08 06:55:54 --> Loader Class Initialized
INFO - 2017-09-08 06:55:54 --> Helper loaded: url_helper
INFO - 2017-09-08 06:55:54 --> Database Driver Class Initialized
INFO - 2017-09-08 06:55:54 --> Email Class Initialized
INFO - 2017-09-08 06:55:54 --> Controller Class Initialized
DEBUG - 2017-09-08 06:55:54 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 06:55:54 --> Helper loaded: inflector_helper
INFO - 2017-09-08 06:55:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 06:55:54 --> Helper loaded: log_helper
INFO - 2017-09-08 06:55:54 --> Model Class Initialized
INFO - 2017-09-08 13:55:54 --> Final output sent to browser
DEBUG - 2017-09-08 13:55:54 --> Total execution time: 0.0578
INFO - 2017-09-08 06:56:01 --> Config Class Initialized
INFO - 2017-09-08 06:56:01 --> Hooks Class Initialized
DEBUG - 2017-09-08 06:56:01 --> UTF-8 Support Enabled
INFO - 2017-09-08 06:56:01 --> Utf8 Class Initialized
INFO - 2017-09-08 06:56:01 --> URI Class Initialized
INFO - 2017-09-08 06:56:01 --> Router Class Initialized
INFO - 2017-09-08 06:56:01 --> Output Class Initialized
INFO - 2017-09-08 06:56:01 --> Security Class Initialized
DEBUG - 2017-09-08 06:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 06:56:01 --> Input Class Initialized
INFO - 2017-09-08 06:56:01 --> Language Class Initialized
INFO - 2017-09-08 06:56:01 --> Loader Class Initialized
INFO - 2017-09-08 06:56:01 --> Helper loaded: url_helper
INFO - 2017-09-08 06:56:01 --> Database Driver Class Initialized
INFO - 2017-09-08 06:56:01 --> Email Class Initialized
INFO - 2017-09-08 06:56:01 --> Controller Class Initialized
DEBUG - 2017-09-08 06:56:01 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 06:56:01 --> Helper loaded: inflector_helper
INFO - 2017-09-08 06:56:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 06:56:01 --> Helper loaded: log_helper
INFO - 2017-09-08 06:56:01 --> Model Class Initialized
INFO - 2017-09-08 13:56:01 --> Final output sent to browser
DEBUG - 2017-09-08 13:56:01 --> Total execution time: 0.0581
INFO - 2017-09-08 06:59:01 --> Config Class Initialized
INFO - 2017-09-08 06:59:01 --> Hooks Class Initialized
DEBUG - 2017-09-08 06:59:01 --> UTF-8 Support Enabled
INFO - 2017-09-08 06:59:01 --> Utf8 Class Initialized
INFO - 2017-09-08 06:59:01 --> URI Class Initialized
INFO - 2017-09-08 06:59:01 --> Router Class Initialized
INFO - 2017-09-08 06:59:01 --> Output Class Initialized
INFO - 2017-09-08 06:59:01 --> Security Class Initialized
DEBUG - 2017-09-08 06:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 06:59:01 --> Input Class Initialized
INFO - 2017-09-08 06:59:01 --> Language Class Initialized
INFO - 2017-09-08 06:59:01 --> Loader Class Initialized
INFO - 2017-09-08 06:59:01 --> Helper loaded: url_helper
INFO - 2017-09-08 06:59:01 --> Database Driver Class Initialized
INFO - 2017-09-08 06:59:01 --> Email Class Initialized
INFO - 2017-09-08 06:59:01 --> Controller Class Initialized
DEBUG - 2017-09-08 06:59:01 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 06:59:01 --> Helper loaded: inflector_helper
INFO - 2017-09-08 06:59:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 06:59:01 --> Helper loaded: log_helper
INFO - 2017-09-08 06:59:01 --> Model Class Initialized
INFO - 2017-09-08 13:59:01 --> Final output sent to browser
DEBUG - 2017-09-08 13:59:01 --> Total execution time: 0.0628
INFO - 2017-09-08 06:59:34 --> Config Class Initialized
INFO - 2017-09-08 06:59:34 --> Hooks Class Initialized
DEBUG - 2017-09-08 06:59:34 --> UTF-8 Support Enabled
INFO - 2017-09-08 06:59:34 --> Utf8 Class Initialized
INFO - 2017-09-08 06:59:34 --> URI Class Initialized
INFO - 2017-09-08 06:59:34 --> Router Class Initialized
INFO - 2017-09-08 06:59:34 --> Output Class Initialized
INFO - 2017-09-08 06:59:34 --> Security Class Initialized
DEBUG - 2017-09-08 06:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 06:59:34 --> Input Class Initialized
INFO - 2017-09-08 06:59:34 --> Language Class Initialized
INFO - 2017-09-08 06:59:34 --> Loader Class Initialized
INFO - 2017-09-08 06:59:34 --> Helper loaded: url_helper
INFO - 2017-09-08 06:59:34 --> Database Driver Class Initialized
INFO - 2017-09-08 06:59:34 --> Email Class Initialized
INFO - 2017-09-08 06:59:34 --> Controller Class Initialized
DEBUG - 2017-09-08 06:59:34 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 06:59:34 --> Helper loaded: inflector_helper
INFO - 2017-09-08 06:59:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 06:59:34 --> Helper loaded: log_helper
INFO - 2017-09-08 06:59:34 --> Model Class Initialized
INFO - 2017-09-08 13:59:34 --> Final output sent to browser
DEBUG - 2017-09-08 13:59:34 --> Total execution time: 0.0581
INFO - 2017-09-08 06:59:52 --> Config Class Initialized
INFO - 2017-09-08 06:59:52 --> Hooks Class Initialized
DEBUG - 2017-09-08 06:59:52 --> UTF-8 Support Enabled
INFO - 2017-09-08 06:59:52 --> Utf8 Class Initialized
INFO - 2017-09-08 06:59:52 --> URI Class Initialized
INFO - 2017-09-08 06:59:52 --> Router Class Initialized
INFO - 2017-09-08 06:59:52 --> Output Class Initialized
INFO - 2017-09-08 06:59:52 --> Security Class Initialized
DEBUG - 2017-09-08 06:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 06:59:52 --> Input Class Initialized
INFO - 2017-09-08 06:59:52 --> Language Class Initialized
INFO - 2017-09-08 06:59:52 --> Loader Class Initialized
INFO - 2017-09-08 06:59:52 --> Helper loaded: url_helper
INFO - 2017-09-08 06:59:52 --> Database Driver Class Initialized
INFO - 2017-09-08 06:59:52 --> Email Class Initialized
INFO - 2017-09-08 06:59:52 --> Controller Class Initialized
DEBUG - 2017-09-08 06:59:52 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 06:59:52 --> Helper loaded: inflector_helper
INFO - 2017-09-08 06:59:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 06:59:52 --> Helper loaded: log_helper
INFO - 2017-09-08 06:59:52 --> Model Class Initialized
INFO - 2017-09-08 13:59:52 --> Final output sent to browser
DEBUG - 2017-09-08 13:59:52 --> Total execution time: 0.0556
INFO - 2017-09-08 07:00:27 --> Config Class Initialized
INFO - 2017-09-08 07:00:27 --> Hooks Class Initialized
DEBUG - 2017-09-08 07:00:27 --> UTF-8 Support Enabled
INFO - 2017-09-08 07:00:27 --> Utf8 Class Initialized
INFO - 2017-09-08 07:00:27 --> URI Class Initialized
INFO - 2017-09-08 07:00:27 --> Router Class Initialized
INFO - 2017-09-08 07:00:27 --> Output Class Initialized
INFO - 2017-09-08 07:00:27 --> Security Class Initialized
DEBUG - 2017-09-08 07:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 07:00:27 --> Input Class Initialized
INFO - 2017-09-08 07:00:27 --> Language Class Initialized
INFO - 2017-09-08 07:00:27 --> Loader Class Initialized
INFO - 2017-09-08 07:00:27 --> Helper loaded: url_helper
INFO - 2017-09-08 07:00:27 --> Database Driver Class Initialized
INFO - 2017-09-08 07:00:27 --> Email Class Initialized
INFO - 2017-09-08 07:00:27 --> Controller Class Initialized
DEBUG - 2017-09-08 07:00:27 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 07:00:27 --> Helper loaded: inflector_helper
INFO - 2017-09-08 07:00:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 07:00:27 --> Helper loaded: log_helper
INFO - 2017-09-08 07:00:27 --> Model Class Initialized
INFO - 2017-09-08 14:00:27 --> Final output sent to browser
DEBUG - 2017-09-08 14:00:27 --> Total execution time: 0.0543
INFO - 2017-09-08 07:00:56 --> Config Class Initialized
INFO - 2017-09-08 07:00:56 --> Hooks Class Initialized
DEBUG - 2017-09-08 07:00:56 --> UTF-8 Support Enabled
INFO - 2017-09-08 07:00:56 --> Utf8 Class Initialized
INFO - 2017-09-08 07:00:56 --> URI Class Initialized
INFO - 2017-09-08 07:00:56 --> Router Class Initialized
INFO - 2017-09-08 07:00:56 --> Output Class Initialized
INFO - 2017-09-08 07:00:56 --> Security Class Initialized
DEBUG - 2017-09-08 07:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 07:00:56 --> Input Class Initialized
INFO - 2017-09-08 07:00:56 --> Language Class Initialized
INFO - 2017-09-08 07:00:56 --> Loader Class Initialized
INFO - 2017-09-08 07:00:56 --> Helper loaded: url_helper
INFO - 2017-09-08 07:00:56 --> Database Driver Class Initialized
INFO - 2017-09-08 07:00:56 --> Email Class Initialized
INFO - 2017-09-08 07:00:56 --> Controller Class Initialized
DEBUG - 2017-09-08 07:00:56 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 07:00:56 --> Helper loaded: inflector_helper
INFO - 2017-09-08 07:00:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 07:00:56 --> Helper loaded: log_helper
INFO - 2017-09-08 07:00:56 --> Model Class Initialized
INFO - 2017-09-08 14:00:56 --> Final output sent to browser
DEBUG - 2017-09-08 14:00:56 --> Total execution time: 0.0582
INFO - 2017-09-08 07:01:27 --> Config Class Initialized
INFO - 2017-09-08 07:01:27 --> Hooks Class Initialized
DEBUG - 2017-09-08 07:01:27 --> UTF-8 Support Enabled
INFO - 2017-09-08 07:01:27 --> Utf8 Class Initialized
INFO - 2017-09-08 07:01:27 --> URI Class Initialized
INFO - 2017-09-08 07:01:27 --> Router Class Initialized
INFO - 2017-09-08 07:01:27 --> Output Class Initialized
INFO - 2017-09-08 07:01:27 --> Security Class Initialized
DEBUG - 2017-09-08 07:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 07:01:27 --> Input Class Initialized
INFO - 2017-09-08 07:01:27 --> Language Class Initialized
INFO - 2017-09-08 07:01:27 --> Loader Class Initialized
INFO - 2017-09-08 07:01:27 --> Helper loaded: url_helper
INFO - 2017-09-08 07:01:27 --> Database Driver Class Initialized
INFO - 2017-09-08 07:01:27 --> Email Class Initialized
INFO - 2017-09-08 07:01:27 --> Controller Class Initialized
DEBUG - 2017-09-08 07:01:27 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 07:01:27 --> Helper loaded: inflector_helper
INFO - 2017-09-08 07:01:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 07:01:27 --> Helper loaded: log_helper
INFO - 2017-09-08 07:01:27 --> Model Class Initialized
INFO - 2017-09-08 14:01:27 --> Final output sent to browser
DEBUG - 2017-09-08 14:01:27 --> Total execution time: 0.0750
INFO - 2017-09-08 07:01:31 --> Config Class Initialized
INFO - 2017-09-08 07:01:31 --> Hooks Class Initialized
DEBUG - 2017-09-08 07:01:31 --> UTF-8 Support Enabled
INFO - 2017-09-08 07:01:31 --> Utf8 Class Initialized
INFO - 2017-09-08 07:01:31 --> URI Class Initialized
INFO - 2017-09-08 07:01:31 --> Router Class Initialized
INFO - 2017-09-08 07:01:31 --> Output Class Initialized
INFO - 2017-09-08 07:01:31 --> Security Class Initialized
DEBUG - 2017-09-08 07:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 07:01:31 --> Input Class Initialized
INFO - 2017-09-08 07:01:31 --> Language Class Initialized
INFO - 2017-09-08 07:01:31 --> Loader Class Initialized
INFO - 2017-09-08 07:01:31 --> Helper loaded: url_helper
INFO - 2017-09-08 07:01:31 --> Database Driver Class Initialized
INFO - 2017-09-08 07:01:31 --> Email Class Initialized
INFO - 2017-09-08 07:01:31 --> Controller Class Initialized
DEBUG - 2017-09-08 07:01:31 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 07:01:31 --> Helper loaded: inflector_helper
INFO - 2017-09-08 07:01:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 07:01:31 --> Helper loaded: log_helper
INFO - 2017-09-08 07:01:31 --> Model Class Initialized
INFO - 2017-09-08 14:01:31 --> Final output sent to browser
DEBUG - 2017-09-08 14:01:31 --> Total execution time: 0.0630
INFO - 2017-09-08 07:01:34 --> Config Class Initialized
INFO - 2017-09-08 07:01:34 --> Hooks Class Initialized
DEBUG - 2017-09-08 07:01:34 --> UTF-8 Support Enabled
INFO - 2017-09-08 07:01:34 --> Utf8 Class Initialized
INFO - 2017-09-08 07:01:34 --> URI Class Initialized
INFO - 2017-09-08 07:01:34 --> Router Class Initialized
INFO - 2017-09-08 07:01:34 --> Output Class Initialized
INFO - 2017-09-08 07:01:34 --> Security Class Initialized
DEBUG - 2017-09-08 07:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 07:01:34 --> Input Class Initialized
INFO - 2017-09-08 07:01:34 --> Language Class Initialized
INFO - 2017-09-08 07:01:34 --> Loader Class Initialized
INFO - 2017-09-08 07:01:34 --> Helper loaded: url_helper
INFO - 2017-09-08 07:01:34 --> Database Driver Class Initialized
INFO - 2017-09-08 07:01:34 --> Email Class Initialized
INFO - 2017-09-08 07:01:34 --> Controller Class Initialized
DEBUG - 2017-09-08 07:01:34 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 07:01:34 --> Helper loaded: inflector_helper
INFO - 2017-09-08 07:01:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 07:01:34 --> Helper loaded: log_helper
INFO - 2017-09-08 07:01:34 --> Model Class Initialized
INFO - 2017-09-08 14:01:34 --> Final output sent to browser
DEBUG - 2017-09-08 14:01:34 --> Total execution time: 0.0804
INFO - 2017-09-08 07:01:52 --> Config Class Initialized
INFO - 2017-09-08 07:01:52 --> Hooks Class Initialized
DEBUG - 2017-09-08 07:01:52 --> UTF-8 Support Enabled
INFO - 2017-09-08 07:01:52 --> Utf8 Class Initialized
INFO - 2017-09-08 07:01:52 --> URI Class Initialized
INFO - 2017-09-08 07:01:52 --> Router Class Initialized
INFO - 2017-09-08 07:01:52 --> Output Class Initialized
INFO - 2017-09-08 07:01:52 --> Security Class Initialized
DEBUG - 2017-09-08 07:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 07:01:52 --> Input Class Initialized
INFO - 2017-09-08 07:01:52 --> Language Class Initialized
INFO - 2017-09-08 07:01:52 --> Loader Class Initialized
INFO - 2017-09-08 07:01:52 --> Helper loaded: url_helper
INFO - 2017-09-08 07:01:52 --> Database Driver Class Initialized
INFO - 2017-09-08 07:01:52 --> Email Class Initialized
INFO - 2017-09-08 07:01:52 --> Controller Class Initialized
DEBUG - 2017-09-08 07:01:52 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 07:01:52 --> Helper loaded: inflector_helper
INFO - 2017-09-08 07:01:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 07:01:52 --> Helper loaded: log_helper
INFO - 2017-09-08 07:01:52 --> Model Class Initialized
INFO - 2017-09-08 14:01:52 --> Final output sent to browser
DEBUG - 2017-09-08 14:01:52 --> Total execution time: 0.0667
INFO - 2017-09-08 07:01:52 --> Config Class Initialized
INFO - 2017-09-08 07:01:52 --> Hooks Class Initialized
DEBUG - 2017-09-08 07:01:52 --> UTF-8 Support Enabled
INFO - 2017-09-08 07:01:52 --> Utf8 Class Initialized
INFO - 2017-09-08 07:01:52 --> URI Class Initialized
INFO - 2017-09-08 07:01:52 --> Router Class Initialized
INFO - 2017-09-08 07:01:52 --> Output Class Initialized
INFO - 2017-09-08 07:01:52 --> Security Class Initialized
DEBUG - 2017-09-08 07:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 07:01:52 --> Input Class Initialized
INFO - 2017-09-08 07:01:52 --> Language Class Initialized
INFO - 2017-09-08 07:01:52 --> Loader Class Initialized
INFO - 2017-09-08 07:01:52 --> Helper loaded: url_helper
INFO - 2017-09-08 07:01:52 --> Database Driver Class Initialized
INFO - 2017-09-08 07:01:52 --> Email Class Initialized
INFO - 2017-09-08 07:01:52 --> Controller Class Initialized
DEBUG - 2017-09-08 07:01:52 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 07:01:52 --> Helper loaded: inflector_helper
INFO - 2017-09-08 07:01:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 07:01:52 --> Helper loaded: log_helper
INFO - 2017-09-08 07:01:52 --> Model Class Initialized
INFO - 2017-09-08 14:01:52 --> Final output sent to browser
DEBUG - 2017-09-08 14:01:52 --> Total execution time: 0.0872
INFO - 2017-09-08 07:01:56 --> Config Class Initialized
INFO - 2017-09-08 07:01:56 --> Hooks Class Initialized
DEBUG - 2017-09-08 07:01:56 --> UTF-8 Support Enabled
INFO - 2017-09-08 07:01:56 --> Utf8 Class Initialized
INFO - 2017-09-08 07:01:56 --> URI Class Initialized
INFO - 2017-09-08 07:01:56 --> Router Class Initialized
INFO - 2017-09-08 07:01:56 --> Output Class Initialized
INFO - 2017-09-08 07:01:56 --> Security Class Initialized
DEBUG - 2017-09-08 07:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 07:01:56 --> Input Class Initialized
INFO - 2017-09-08 07:01:56 --> Language Class Initialized
INFO - 2017-09-08 07:01:56 --> Loader Class Initialized
INFO - 2017-09-08 07:01:56 --> Helper loaded: url_helper
INFO - 2017-09-08 07:01:56 --> Database Driver Class Initialized
INFO - 2017-09-08 07:01:56 --> Email Class Initialized
INFO - 2017-09-08 07:01:56 --> Controller Class Initialized
DEBUG - 2017-09-08 07:01:56 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 07:01:56 --> Helper loaded: inflector_helper
INFO - 2017-09-08 07:01:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 07:01:56 --> Helper loaded: log_helper
INFO - 2017-09-08 07:01:56 --> Model Class Initialized
ERROR - 2017-09-08 14:01:56 --> Severity: Warning --> hex2bin(): Input string must be hexadecimal string C:\wamp64\www\franknco\application\models\api_model.php 704
ERROR - 2017-09-08 14:01:56 --> Severity: Warning --> mdecrypt_generic(): An empty string was passed C:\wamp64\www\franknco\application\models\api_model.php 704
ERROR - 2017-09-08 14:01:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: insert into user_member(fullname,dob,address,email,hp,passwd)
INFO - 2017-09-08 14:01:56 --> Language file loaded: language/english/db_lang.php
INFO - 2017-09-08 07:02:35 --> Config Class Initialized
INFO - 2017-09-08 07:02:35 --> Hooks Class Initialized
DEBUG - 2017-09-08 07:02:35 --> UTF-8 Support Enabled
INFO - 2017-09-08 07:02:35 --> Utf8 Class Initialized
INFO - 2017-09-08 07:02:35 --> URI Class Initialized
INFO - 2017-09-08 07:02:35 --> Router Class Initialized
INFO - 2017-09-08 07:02:35 --> Output Class Initialized
INFO - 2017-09-08 07:02:35 --> Security Class Initialized
DEBUG - 2017-09-08 07:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 07:02:35 --> Input Class Initialized
INFO - 2017-09-08 07:02:35 --> Language Class Initialized
INFO - 2017-09-08 07:02:35 --> Loader Class Initialized
INFO - 2017-09-08 07:02:35 --> Helper loaded: url_helper
INFO - 2017-09-08 07:02:35 --> Database Driver Class Initialized
INFO - 2017-09-08 07:02:35 --> Email Class Initialized
INFO - 2017-09-08 07:02:35 --> Controller Class Initialized
DEBUG - 2017-09-08 07:02:35 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 07:02:35 --> Helper loaded: inflector_helper
INFO - 2017-09-08 07:02:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 07:02:35 --> Helper loaded: log_helper
INFO - 2017-09-08 07:02:35 --> Model Class Initialized
INFO - 2017-09-08 14:02:35 --> Final output sent to browser
DEBUG - 2017-09-08 14:02:35 --> Total execution time: 0.0548
INFO - 2017-09-08 07:03:23 --> Config Class Initialized
INFO - 2017-09-08 07:03:23 --> Hooks Class Initialized
DEBUG - 2017-09-08 07:03:23 --> UTF-8 Support Enabled
INFO - 2017-09-08 07:03:23 --> Utf8 Class Initialized
INFO - 2017-09-08 07:03:23 --> URI Class Initialized
INFO - 2017-09-08 07:03:23 --> Router Class Initialized
INFO - 2017-09-08 07:03:23 --> Output Class Initialized
INFO - 2017-09-08 07:03:23 --> Security Class Initialized
DEBUG - 2017-09-08 07:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 07:03:23 --> Input Class Initialized
INFO - 2017-09-08 07:03:23 --> Language Class Initialized
INFO - 2017-09-08 07:03:23 --> Loader Class Initialized
INFO - 2017-09-08 07:03:23 --> Helper loaded: url_helper
INFO - 2017-09-08 07:03:23 --> Database Driver Class Initialized
INFO - 2017-09-08 07:03:23 --> Email Class Initialized
INFO - 2017-09-08 07:03:23 --> Controller Class Initialized
DEBUG - 2017-09-08 07:03:23 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 07:03:23 --> Helper loaded: inflector_helper
INFO - 2017-09-08 07:03:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 07:03:23 --> Helper loaded: log_helper
INFO - 2017-09-08 07:03:23 --> Model Class Initialized
ERROR - 2017-09-08 14:03:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: insert into user_member(fullname,dob,address,email,hp,passwd)
INFO - 2017-09-08 14:03:23 --> Language file loaded: language/english/db_lang.php
INFO - 2017-09-08 07:03:47 --> Config Class Initialized
INFO - 2017-09-08 07:03:47 --> Hooks Class Initialized
DEBUG - 2017-09-08 07:03:47 --> UTF-8 Support Enabled
INFO - 2017-09-08 07:03:47 --> Utf8 Class Initialized
INFO - 2017-09-08 07:03:47 --> URI Class Initialized
INFO - 2017-09-08 07:03:47 --> Router Class Initialized
INFO - 2017-09-08 07:03:47 --> Output Class Initialized
INFO - 2017-09-08 07:03:47 --> Security Class Initialized
DEBUG - 2017-09-08 07:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 07:03:48 --> Input Class Initialized
INFO - 2017-09-08 07:03:48 --> Language Class Initialized
INFO - 2017-09-08 07:03:48 --> Loader Class Initialized
INFO - 2017-09-08 07:03:48 --> Helper loaded: url_helper
INFO - 2017-09-08 07:03:48 --> Database Driver Class Initialized
INFO - 2017-09-08 07:03:48 --> Email Class Initialized
INFO - 2017-09-08 07:03:48 --> Controller Class Initialized
DEBUG - 2017-09-08 07:03:48 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 07:03:48 --> Helper loaded: inflector_helper
INFO - 2017-09-08 07:03:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 07:03:48 --> Helper loaded: log_helper
INFO - 2017-09-08 07:03:48 --> Model Class Initialized
INFO - 2017-09-08 14:03:48 --> Final output sent to browser
DEBUG - 2017-09-08 14:03:48 --> Total execution time: 0.0578
INFO - 2017-09-08 07:05:44 --> Config Class Initialized
INFO - 2017-09-08 07:05:44 --> Hooks Class Initialized
DEBUG - 2017-09-08 07:05:44 --> UTF-8 Support Enabled
INFO - 2017-09-08 07:05:44 --> Utf8 Class Initialized
INFO - 2017-09-08 07:05:44 --> URI Class Initialized
INFO - 2017-09-08 07:05:44 --> Router Class Initialized
INFO - 2017-09-08 07:05:44 --> Output Class Initialized
INFO - 2017-09-08 07:05:44 --> Security Class Initialized
DEBUG - 2017-09-08 07:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 07:05:44 --> Input Class Initialized
INFO - 2017-09-08 07:05:44 --> Language Class Initialized
INFO - 2017-09-08 07:05:44 --> Loader Class Initialized
INFO - 2017-09-08 07:05:44 --> Helper loaded: url_helper
INFO - 2017-09-08 07:05:44 --> Database Driver Class Initialized
INFO - 2017-09-08 07:05:44 --> Email Class Initialized
INFO - 2017-09-08 07:05:44 --> Controller Class Initialized
DEBUG - 2017-09-08 07:05:44 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 07:05:44 --> Helper loaded: inflector_helper
INFO - 2017-09-08 07:05:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 07:05:44 --> Helper loaded: log_helper
INFO - 2017-09-08 07:05:44 --> Model Class Initialized
ERROR - 2017-09-08 14:05:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: insert into user_member(fullname,dob,address,email,hp,passwd)
INFO - 2017-09-08 14:05:44 --> Language file loaded: language/english/db_lang.php
INFO - 2017-09-08 07:05:46 --> Config Class Initialized
INFO - 2017-09-08 07:05:46 --> Hooks Class Initialized
DEBUG - 2017-09-08 07:05:46 --> UTF-8 Support Enabled
INFO - 2017-09-08 07:05:46 --> Utf8 Class Initialized
INFO - 2017-09-08 07:05:46 --> URI Class Initialized
INFO - 2017-09-08 07:05:46 --> Router Class Initialized
INFO - 2017-09-08 07:05:46 --> Output Class Initialized
INFO - 2017-09-08 07:05:46 --> Security Class Initialized
DEBUG - 2017-09-08 07:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 07:05:46 --> Input Class Initialized
INFO - 2017-09-08 07:05:46 --> Language Class Initialized
INFO - 2017-09-08 07:05:46 --> Loader Class Initialized
INFO - 2017-09-08 07:05:46 --> Helper loaded: url_helper
INFO - 2017-09-08 07:05:46 --> Database Driver Class Initialized
INFO - 2017-09-08 07:05:46 --> Email Class Initialized
INFO - 2017-09-08 07:05:46 --> Controller Class Initialized
DEBUG - 2017-09-08 07:05:46 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 07:05:46 --> Helper loaded: inflector_helper
INFO - 2017-09-08 07:05:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 07:05:46 --> Helper loaded: log_helper
INFO - 2017-09-08 07:05:46 --> Model Class Initialized
ERROR - 2017-09-08 14:05:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: insert into user_member(fullname,dob,address,email,hp,passwd)
INFO - 2017-09-08 14:05:46 --> Language file loaded: language/english/db_lang.php
INFO - 2017-09-08 07:06:08 --> Config Class Initialized
INFO - 2017-09-08 07:06:08 --> Hooks Class Initialized
DEBUG - 2017-09-08 07:06:08 --> UTF-8 Support Enabled
INFO - 2017-09-08 07:06:08 --> Utf8 Class Initialized
INFO - 2017-09-08 07:06:08 --> URI Class Initialized
INFO - 2017-09-08 07:06:08 --> Router Class Initialized
INFO - 2017-09-08 07:06:08 --> Output Class Initialized
INFO - 2017-09-08 07:06:08 --> Security Class Initialized
DEBUG - 2017-09-08 07:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 07:06:08 --> Input Class Initialized
INFO - 2017-09-08 07:06:08 --> Language Class Initialized
INFO - 2017-09-08 07:06:08 --> Loader Class Initialized
INFO - 2017-09-08 07:06:08 --> Helper loaded: url_helper
INFO - 2017-09-08 07:06:08 --> Database Driver Class Initialized
INFO - 2017-09-08 07:06:08 --> Email Class Initialized
INFO - 2017-09-08 07:06:08 --> Controller Class Initialized
DEBUG - 2017-09-08 07:06:08 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 07:06:08 --> Helper loaded: inflector_helper
INFO - 2017-09-08 07:06:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 07:06:08 --> Helper loaded: log_helper
INFO - 2017-09-08 07:06:08 --> Model Class Initialized
INFO - 2017-09-08 14:06:08 --> Final output sent to browser
DEBUG - 2017-09-08 14:06:08 --> Total execution time: 0.0859
INFO - 2017-09-08 07:08:10 --> Config Class Initialized
INFO - 2017-09-08 07:08:10 --> Hooks Class Initialized
DEBUG - 2017-09-08 07:08:10 --> UTF-8 Support Enabled
INFO - 2017-09-08 07:08:10 --> Utf8 Class Initialized
INFO - 2017-09-08 07:08:10 --> URI Class Initialized
INFO - 2017-09-08 07:08:10 --> Router Class Initialized
INFO - 2017-09-08 07:08:10 --> Output Class Initialized
INFO - 2017-09-08 07:08:10 --> Security Class Initialized
DEBUG - 2017-09-08 07:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 07:08:10 --> Input Class Initialized
INFO - 2017-09-08 07:08:10 --> Language Class Initialized
INFO - 2017-09-08 07:08:10 --> Loader Class Initialized
INFO - 2017-09-08 07:08:10 --> Helper loaded: url_helper
INFO - 2017-09-08 07:08:10 --> Database Driver Class Initialized
INFO - 2017-09-08 07:08:10 --> Email Class Initialized
INFO - 2017-09-08 07:08:10 --> Controller Class Initialized
DEBUG - 2017-09-08 07:08:10 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 07:08:10 --> Helper loaded: inflector_helper
INFO - 2017-09-08 07:08:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 07:08:10 --> Helper loaded: log_helper
INFO - 2017-09-08 07:08:10 --> Model Class Initialized
ERROR - 2017-09-08 14:08:10 --> Query error: Field 'TOKEN' doesn't have a default value - Invalid query: insert into user_member(fullname,dob,address,email,hp,passwd)
                           values('71374C6E3535376C6C79673D','1992-10-25','59465050484C563847725456777373796139373879413D3D','6A466C7037715246575172386F7433374D70376861673D3D','4D7871704E365861673778545239396E36384D4458513D3D','74782B7A4E6746556F79756D313557666E2F32387A683278396E48705341734B694F325330503779375368355972614363385738766F357551386A2B6D69706D706C6F72625649433032536265454B6762756A485A773D3D')
INFO - 2017-09-08 14:08:10 --> Language file loaded: language/english/db_lang.php
INFO - 2017-09-08 07:12:23 --> Config Class Initialized
INFO - 2017-09-08 07:12:23 --> Hooks Class Initialized
DEBUG - 2017-09-08 07:12:23 --> UTF-8 Support Enabled
INFO - 2017-09-08 07:12:23 --> Utf8 Class Initialized
INFO - 2017-09-08 07:12:23 --> URI Class Initialized
INFO - 2017-09-08 07:12:23 --> Router Class Initialized
INFO - 2017-09-08 07:12:23 --> Output Class Initialized
INFO - 2017-09-08 07:12:23 --> Security Class Initialized
DEBUG - 2017-09-08 07:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 07:12:23 --> Input Class Initialized
INFO - 2017-09-08 07:12:23 --> Language Class Initialized
INFO - 2017-09-08 07:12:23 --> Loader Class Initialized
INFO - 2017-09-08 07:12:23 --> Helper loaded: url_helper
INFO - 2017-09-08 07:12:23 --> Database Driver Class Initialized
INFO - 2017-09-08 07:12:23 --> Email Class Initialized
INFO - 2017-09-08 07:12:23 --> Controller Class Initialized
DEBUG - 2017-09-08 07:12:23 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 07:12:23 --> Helper loaded: inflector_helper
INFO - 2017-09-08 07:12:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 07:12:23 --> Helper loaded: log_helper
INFO - 2017-09-08 07:12:23 --> Model Class Initialized
ERROR - 2017-09-08 14:12:23 --> Severity: Notice --> Undefined variable: sign_up C:\wamp64\www\franknco\application\models\api_model.php 98
INFO - 2017-09-08 14:12:23 --> Final output sent to browser
DEBUG - 2017-09-08 14:12:23 --> Total execution time: 0.1045
INFO - 2017-09-08 07:15:03 --> Config Class Initialized
INFO - 2017-09-08 07:15:03 --> Hooks Class Initialized
DEBUG - 2017-09-08 07:15:03 --> UTF-8 Support Enabled
INFO - 2017-09-08 07:15:03 --> Utf8 Class Initialized
INFO - 2017-09-08 07:15:03 --> URI Class Initialized
INFO - 2017-09-08 07:15:03 --> Router Class Initialized
INFO - 2017-09-08 07:15:03 --> Output Class Initialized
INFO - 2017-09-08 07:15:03 --> Security Class Initialized
DEBUG - 2017-09-08 07:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 07:15:03 --> Input Class Initialized
INFO - 2017-09-08 07:15:03 --> Language Class Initialized
INFO - 2017-09-08 07:15:03 --> Loader Class Initialized
INFO - 2017-09-08 07:15:03 --> Helper loaded: url_helper
INFO - 2017-09-08 07:15:03 --> Database Driver Class Initialized
INFO - 2017-09-08 07:15:03 --> Email Class Initialized
INFO - 2017-09-08 07:15:03 --> Controller Class Initialized
DEBUG - 2017-09-08 07:15:03 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 07:15:03 --> Helper loaded: inflector_helper
INFO - 2017-09-08 07:15:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 07:15:03 --> Helper loaded: log_helper
INFO - 2017-09-08 07:15:03 --> Model Class Initialized
ERROR - 2017-09-08 14:15:03 --> Severity: Notice --> Undefined variable: sign_up C:\wamp64\www\franknco\application\models\api_model.php 98
INFO - 2017-09-08 14:15:03 --> Final output sent to browser
DEBUG - 2017-09-08 14:15:03 --> Total execution time: 0.0908
INFO - 2017-09-08 07:16:40 --> Config Class Initialized
INFO - 2017-09-08 07:16:40 --> Hooks Class Initialized
DEBUG - 2017-09-08 07:16:40 --> UTF-8 Support Enabled
INFO - 2017-09-08 07:16:40 --> Utf8 Class Initialized
INFO - 2017-09-08 07:16:40 --> URI Class Initialized
INFO - 2017-09-08 07:16:40 --> Router Class Initialized
INFO - 2017-09-08 07:16:40 --> Output Class Initialized
INFO - 2017-09-08 07:16:40 --> Security Class Initialized
DEBUG - 2017-09-08 07:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 07:16:40 --> Input Class Initialized
INFO - 2017-09-08 07:16:40 --> Language Class Initialized
INFO - 2017-09-08 07:16:40 --> Loader Class Initialized
INFO - 2017-09-08 07:16:40 --> Helper loaded: url_helper
INFO - 2017-09-08 07:16:40 --> Database Driver Class Initialized
INFO - 2017-09-08 07:16:40 --> Email Class Initialized
INFO - 2017-09-08 07:16:40 --> Controller Class Initialized
DEBUG - 2017-09-08 07:16:40 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 07:16:40 --> Helper loaded: inflector_helper
INFO - 2017-09-08 07:16:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 07:16:40 --> Helper loaded: log_helper
INFO - 2017-09-08 07:16:40 --> Model Class Initialized
ERROR - 2017-09-08 14:16:40 --> Severity: Notice --> Undefined variable: sign_up C:\wamp64\www\franknco\application\models\api_model.php 98
INFO - 2017-09-08 14:16:40 --> Final output sent to browser
DEBUG - 2017-09-08 14:16:40 --> Total execution time: 0.0831
INFO - 2017-09-08 07:16:43 --> Config Class Initialized
INFO - 2017-09-08 07:16:43 --> Hooks Class Initialized
DEBUG - 2017-09-08 07:16:43 --> UTF-8 Support Enabled
INFO - 2017-09-08 07:16:43 --> Utf8 Class Initialized
INFO - 2017-09-08 07:16:43 --> URI Class Initialized
INFO - 2017-09-08 07:16:43 --> Router Class Initialized
INFO - 2017-09-08 07:16:43 --> Output Class Initialized
INFO - 2017-09-08 07:16:43 --> Security Class Initialized
DEBUG - 2017-09-08 07:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 07:16:43 --> Input Class Initialized
INFO - 2017-09-08 07:16:43 --> Language Class Initialized
INFO - 2017-09-08 07:16:43 --> Loader Class Initialized
INFO - 2017-09-08 07:16:43 --> Helper loaded: url_helper
INFO - 2017-09-08 07:16:43 --> Database Driver Class Initialized
INFO - 2017-09-08 07:16:43 --> Email Class Initialized
INFO - 2017-09-08 07:16:43 --> Controller Class Initialized
DEBUG - 2017-09-08 07:16:43 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 07:16:43 --> Helper loaded: inflector_helper
INFO - 2017-09-08 07:16:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 07:16:43 --> Helper loaded: log_helper
INFO - 2017-09-08 07:16:43 --> Model Class Initialized
INFO - 2017-09-08 14:16:43 --> Final output sent to browser
DEBUG - 2017-09-08 14:16:43 --> Total execution time: 0.0743
INFO - 2017-09-08 07:16:46 --> Config Class Initialized
INFO - 2017-09-08 07:16:46 --> Hooks Class Initialized
DEBUG - 2017-09-08 07:16:46 --> UTF-8 Support Enabled
INFO - 2017-09-08 07:16:46 --> Utf8 Class Initialized
INFO - 2017-09-08 07:16:46 --> URI Class Initialized
INFO - 2017-09-08 07:16:46 --> Router Class Initialized
INFO - 2017-09-08 07:16:46 --> Output Class Initialized
INFO - 2017-09-08 07:16:46 --> Security Class Initialized
DEBUG - 2017-09-08 07:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 07:16:46 --> Input Class Initialized
INFO - 2017-09-08 07:16:46 --> Language Class Initialized
INFO - 2017-09-08 07:16:46 --> Loader Class Initialized
INFO - 2017-09-08 07:16:46 --> Helper loaded: url_helper
INFO - 2017-09-08 07:16:46 --> Database Driver Class Initialized
INFO - 2017-09-08 07:16:46 --> Email Class Initialized
INFO - 2017-09-08 07:16:46 --> Controller Class Initialized
DEBUG - 2017-09-08 07:16:46 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 07:16:46 --> Helper loaded: inflector_helper
INFO - 2017-09-08 07:16:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 07:16:46 --> Helper loaded: log_helper
INFO - 2017-09-08 07:16:46 --> Model Class Initialized
INFO - 2017-09-08 14:16:46 --> Final output sent to browser
DEBUG - 2017-09-08 14:16:46 --> Total execution time: 0.0723
INFO - 2017-09-08 07:17:02 --> Config Class Initialized
INFO - 2017-09-08 07:17:02 --> Hooks Class Initialized
DEBUG - 2017-09-08 07:17:02 --> UTF-8 Support Enabled
INFO - 2017-09-08 07:17:02 --> Utf8 Class Initialized
INFO - 2017-09-08 07:17:02 --> URI Class Initialized
INFO - 2017-09-08 07:17:02 --> Router Class Initialized
INFO - 2017-09-08 07:17:02 --> Output Class Initialized
INFO - 2017-09-08 07:17:02 --> Security Class Initialized
DEBUG - 2017-09-08 07:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 07:17:02 --> Input Class Initialized
INFO - 2017-09-08 07:17:02 --> Language Class Initialized
INFO - 2017-09-08 07:17:02 --> Loader Class Initialized
INFO - 2017-09-08 07:17:02 --> Helper loaded: url_helper
INFO - 2017-09-08 07:17:02 --> Database Driver Class Initialized
INFO - 2017-09-08 07:17:02 --> Email Class Initialized
INFO - 2017-09-08 07:17:02 --> Controller Class Initialized
DEBUG - 2017-09-08 07:17:02 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 07:17:02 --> Helper loaded: inflector_helper
INFO - 2017-09-08 07:17:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 07:17:02 --> Helper loaded: log_helper
INFO - 2017-09-08 07:17:02 --> Model Class Initialized
ERROR - 2017-09-08 14:17:02 --> Severity: Notice --> Undefined variable: sign_up C:\wamp64\www\franknco\application\models\api_model.php 98
INFO - 2017-09-08 14:17:02 --> Final output sent to browser
DEBUG - 2017-09-08 14:17:02 --> Total execution time: 0.1193
INFO - 2017-09-08 07:17:38 --> Config Class Initialized
INFO - 2017-09-08 07:17:38 --> Hooks Class Initialized
DEBUG - 2017-09-08 07:17:38 --> UTF-8 Support Enabled
INFO - 2017-09-08 07:17:38 --> Utf8 Class Initialized
INFO - 2017-09-08 07:17:38 --> URI Class Initialized
INFO - 2017-09-08 07:17:38 --> Router Class Initialized
INFO - 2017-09-08 07:17:38 --> Output Class Initialized
INFO - 2017-09-08 07:17:38 --> Security Class Initialized
DEBUG - 2017-09-08 07:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 07:17:38 --> Input Class Initialized
INFO - 2017-09-08 07:17:38 --> Language Class Initialized
INFO - 2017-09-08 07:17:38 --> Loader Class Initialized
INFO - 2017-09-08 07:17:38 --> Helper loaded: url_helper
INFO - 2017-09-08 07:17:38 --> Database Driver Class Initialized
INFO - 2017-09-08 07:17:38 --> Email Class Initialized
INFO - 2017-09-08 07:17:38 --> Controller Class Initialized
DEBUG - 2017-09-08 07:17:38 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 07:17:38 --> Helper loaded: inflector_helper
INFO - 2017-09-08 07:17:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 07:17:38 --> Helper loaded: log_helper
INFO - 2017-09-08 07:17:38 --> Model Class Initialized
ERROR - 2017-09-08 14:17:38 --> Severity: Notice --> Undefined variable: sign_up C:\wamp64\www\franknco\application\models\api_model.php 98
INFO - 2017-09-08 14:17:38 --> Final output sent to browser
DEBUG - 2017-09-08 14:17:38 --> Total execution time: 0.0935
INFO - 2017-09-08 07:19:43 --> Config Class Initialized
INFO - 2017-09-08 07:19:43 --> Hooks Class Initialized
DEBUG - 2017-09-08 07:19:43 --> UTF-8 Support Enabled
INFO - 2017-09-08 07:19:43 --> Utf8 Class Initialized
INFO - 2017-09-08 07:19:43 --> URI Class Initialized
INFO - 2017-09-08 07:19:43 --> Router Class Initialized
INFO - 2017-09-08 07:19:43 --> Output Class Initialized
INFO - 2017-09-08 07:19:43 --> Security Class Initialized
DEBUG - 2017-09-08 07:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 07:19:43 --> Input Class Initialized
INFO - 2017-09-08 07:19:43 --> Language Class Initialized
INFO - 2017-09-08 07:19:43 --> Loader Class Initialized
INFO - 2017-09-08 07:19:43 --> Helper loaded: url_helper
INFO - 2017-09-08 07:19:43 --> Database Driver Class Initialized
INFO - 2017-09-08 07:19:43 --> Email Class Initialized
INFO - 2017-09-08 07:19:43 --> Controller Class Initialized
DEBUG - 2017-09-08 07:19:43 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 07:19:43 --> Helper loaded: inflector_helper
INFO - 2017-09-08 07:19:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 07:19:43 --> Helper loaded: log_helper
INFO - 2017-09-08 07:19:43 --> Model Class Initialized
INFO - 2017-09-08 14:19:43 --> Final output sent to browser
DEBUG - 2017-09-08 14:19:43 --> Total execution time: 0.0748
INFO - 2017-09-08 07:20:13 --> Config Class Initialized
INFO - 2017-09-08 07:20:13 --> Hooks Class Initialized
DEBUG - 2017-09-08 07:20:13 --> UTF-8 Support Enabled
INFO - 2017-09-08 07:20:13 --> Utf8 Class Initialized
INFO - 2017-09-08 07:20:13 --> URI Class Initialized
INFO - 2017-09-08 07:20:13 --> Router Class Initialized
INFO - 2017-09-08 07:20:13 --> Output Class Initialized
INFO - 2017-09-08 07:20:13 --> Security Class Initialized
DEBUG - 2017-09-08 07:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 07:20:13 --> Input Class Initialized
INFO - 2017-09-08 07:20:13 --> Language Class Initialized
INFO - 2017-09-08 07:20:13 --> Loader Class Initialized
INFO - 2017-09-08 07:20:13 --> Helper loaded: url_helper
INFO - 2017-09-08 07:20:13 --> Database Driver Class Initialized
INFO - 2017-09-08 07:20:13 --> Email Class Initialized
INFO - 2017-09-08 07:20:13 --> Controller Class Initialized
DEBUG - 2017-09-08 07:20:13 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 07:20:13 --> Helper loaded: inflector_helper
INFO - 2017-09-08 07:20:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 07:20:13 --> Helper loaded: log_helper
INFO - 2017-09-08 07:20:13 --> Model Class Initialized
INFO - 2017-09-08 14:20:13 --> Final output sent to browser
DEBUG - 2017-09-08 14:20:13 --> Total execution time: 0.0830
INFO - 2017-09-08 07:20:26 --> Config Class Initialized
INFO - 2017-09-08 07:20:26 --> Hooks Class Initialized
DEBUG - 2017-09-08 07:20:26 --> UTF-8 Support Enabled
INFO - 2017-09-08 07:20:26 --> Utf8 Class Initialized
INFO - 2017-09-08 07:20:26 --> URI Class Initialized
INFO - 2017-09-08 07:20:26 --> Router Class Initialized
INFO - 2017-09-08 07:20:26 --> Output Class Initialized
INFO - 2017-09-08 07:20:26 --> Security Class Initialized
DEBUG - 2017-09-08 07:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 07:20:26 --> Input Class Initialized
INFO - 2017-09-08 07:20:26 --> Language Class Initialized
INFO - 2017-09-08 07:20:26 --> Loader Class Initialized
INFO - 2017-09-08 07:20:26 --> Helper loaded: url_helper
INFO - 2017-09-08 07:20:26 --> Database Driver Class Initialized
INFO - 2017-09-08 07:20:26 --> Email Class Initialized
INFO - 2017-09-08 07:20:26 --> Controller Class Initialized
DEBUG - 2017-09-08 07:20:26 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 07:20:26 --> Helper loaded: inflector_helper
INFO - 2017-09-08 07:20:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 07:20:26 --> Helper loaded: log_helper
INFO - 2017-09-08 07:20:26 --> Model Class Initialized
ERROR - 2017-09-08 14:20:26 --> Severity: Notice --> Undefined variable: sign_up C:\wamp64\www\franknco\application\models\api_model.php 99
INFO - 2017-09-08 14:20:26 --> Final output sent to browser
DEBUG - 2017-09-08 14:20:26 --> Total execution time: 0.0973
INFO - 2017-09-08 07:21:44 --> Config Class Initialized
INFO - 2017-09-08 07:21:44 --> Hooks Class Initialized
DEBUG - 2017-09-08 07:21:44 --> UTF-8 Support Enabled
INFO - 2017-09-08 07:21:44 --> Utf8 Class Initialized
INFO - 2017-09-08 07:21:44 --> URI Class Initialized
INFO - 2017-09-08 07:21:44 --> Router Class Initialized
INFO - 2017-09-08 07:21:44 --> Output Class Initialized
INFO - 2017-09-08 07:21:44 --> Security Class Initialized
DEBUG - 2017-09-08 07:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 07:21:44 --> Input Class Initialized
INFO - 2017-09-08 07:21:44 --> Language Class Initialized
INFO - 2017-09-08 07:21:44 --> Loader Class Initialized
INFO - 2017-09-08 07:21:44 --> Helper loaded: url_helper
INFO - 2017-09-08 07:21:44 --> Database Driver Class Initialized
INFO - 2017-09-08 07:21:44 --> Email Class Initialized
INFO - 2017-09-08 07:21:44 --> Controller Class Initialized
DEBUG - 2017-09-08 07:21:44 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 07:21:44 --> Helper loaded: inflector_helper
INFO - 2017-09-08 07:21:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 07:21:44 --> Helper loaded: log_helper
INFO - 2017-09-08 07:21:44 --> Model Class Initialized
ERROR - 2017-09-08 14:21:44 --> Severity: Notice --> Undefined variable: sign_up C:\wamp64\www\franknco\application\models\api_model.php 98
INFO - 2017-09-08 14:21:44 --> Final output sent to browser
DEBUG - 2017-09-08 14:21:44 --> Total execution time: 0.0777
INFO - 2017-09-08 07:21:57 --> Config Class Initialized
INFO - 2017-09-08 07:21:57 --> Hooks Class Initialized
DEBUG - 2017-09-08 07:21:57 --> UTF-8 Support Enabled
INFO - 2017-09-08 07:21:57 --> Utf8 Class Initialized
INFO - 2017-09-08 07:21:57 --> URI Class Initialized
INFO - 2017-09-08 07:21:57 --> Router Class Initialized
INFO - 2017-09-08 07:21:57 --> Output Class Initialized
INFO - 2017-09-08 07:21:57 --> Security Class Initialized
DEBUG - 2017-09-08 07:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 07:21:57 --> Input Class Initialized
INFO - 2017-09-08 07:21:57 --> Language Class Initialized
INFO - 2017-09-08 07:21:57 --> Loader Class Initialized
INFO - 2017-09-08 07:21:57 --> Helper loaded: url_helper
INFO - 2017-09-08 07:21:57 --> Database Driver Class Initialized
INFO - 2017-09-08 07:21:58 --> Email Class Initialized
INFO - 2017-09-08 07:21:58 --> Controller Class Initialized
DEBUG - 2017-09-08 07:21:58 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 07:21:58 --> Helper loaded: inflector_helper
INFO - 2017-09-08 07:21:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 07:21:58 --> Helper loaded: log_helper
INFO - 2017-09-08 07:21:58 --> Model Class Initialized
ERROR - 2017-09-08 14:21:58 --> Severity: Notice --> Undefined variable: sign_up C:\wamp64\www\franknco\application\models\api_model.php 98
INFO - 2017-09-08 14:21:58 --> Final output sent to browser
DEBUG - 2017-09-08 14:21:58 --> Total execution time: 0.0790
INFO - 2017-09-08 07:22:10 --> Config Class Initialized
INFO - 2017-09-08 07:22:10 --> Hooks Class Initialized
DEBUG - 2017-09-08 07:22:10 --> UTF-8 Support Enabled
INFO - 2017-09-08 07:22:10 --> Utf8 Class Initialized
INFO - 2017-09-08 07:22:10 --> URI Class Initialized
INFO - 2017-09-08 07:22:10 --> Router Class Initialized
INFO - 2017-09-08 07:22:10 --> Output Class Initialized
INFO - 2017-09-08 07:22:10 --> Security Class Initialized
DEBUG - 2017-09-08 07:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 07:22:10 --> Input Class Initialized
INFO - 2017-09-08 07:22:10 --> Language Class Initialized
INFO - 2017-09-08 07:22:10 --> Loader Class Initialized
INFO - 2017-09-08 07:22:10 --> Helper loaded: url_helper
INFO - 2017-09-08 07:22:10 --> Database Driver Class Initialized
INFO - 2017-09-08 07:22:10 --> Email Class Initialized
INFO - 2017-09-08 07:22:10 --> Controller Class Initialized
DEBUG - 2017-09-08 07:22:10 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 07:22:10 --> Helper loaded: inflector_helper
INFO - 2017-09-08 07:22:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 07:22:10 --> Helper loaded: log_helper
INFO - 2017-09-08 07:22:10 --> Model Class Initialized
ERROR - 2017-09-08 14:22:10 --> Severity: Notice --> Undefined variable: sign_up C:\wamp64\www\franknco\application\models\api_model.php 98
INFO - 2017-09-08 14:22:10 --> Final output sent to browser
DEBUG - 2017-09-08 14:22:10 --> Total execution time: 0.0910
INFO - 2017-09-08 07:22:43 --> Config Class Initialized
INFO - 2017-09-08 07:22:43 --> Hooks Class Initialized
DEBUG - 2017-09-08 07:22:43 --> UTF-8 Support Enabled
INFO - 2017-09-08 07:22:43 --> Utf8 Class Initialized
INFO - 2017-09-08 07:22:43 --> URI Class Initialized
INFO - 2017-09-08 07:22:43 --> Router Class Initialized
INFO - 2017-09-08 07:22:43 --> Output Class Initialized
INFO - 2017-09-08 07:22:43 --> Security Class Initialized
DEBUG - 2017-09-08 07:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 07:22:43 --> Input Class Initialized
INFO - 2017-09-08 07:22:43 --> Language Class Initialized
INFO - 2017-09-08 07:22:43 --> Loader Class Initialized
INFO - 2017-09-08 07:22:43 --> Helper loaded: url_helper
INFO - 2017-09-08 07:22:43 --> Database Driver Class Initialized
INFO - 2017-09-08 07:22:43 --> Email Class Initialized
INFO - 2017-09-08 07:22:43 --> Controller Class Initialized
DEBUG - 2017-09-08 07:22:43 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 07:22:43 --> Helper loaded: inflector_helper
INFO - 2017-09-08 07:22:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 07:22:43 --> Helper loaded: log_helper
INFO - 2017-09-08 07:22:43 --> Model Class Initialized
INFO - 2017-09-08 14:22:43 --> Final output sent to browser
DEBUG - 2017-09-08 14:22:43 --> Total execution time: 0.0705
INFO - 2017-09-08 07:22:53 --> Config Class Initialized
INFO - 2017-09-08 07:22:53 --> Hooks Class Initialized
DEBUG - 2017-09-08 07:22:53 --> UTF-8 Support Enabled
INFO - 2017-09-08 07:22:53 --> Utf8 Class Initialized
INFO - 2017-09-08 07:22:53 --> URI Class Initialized
INFO - 2017-09-08 07:22:53 --> Router Class Initialized
INFO - 2017-09-08 07:22:53 --> Output Class Initialized
INFO - 2017-09-08 07:22:53 --> Security Class Initialized
DEBUG - 2017-09-08 07:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 07:22:53 --> Input Class Initialized
INFO - 2017-09-08 07:22:53 --> Language Class Initialized
INFO - 2017-09-08 07:22:53 --> Loader Class Initialized
INFO - 2017-09-08 07:22:53 --> Helper loaded: url_helper
INFO - 2017-09-08 07:22:53 --> Database Driver Class Initialized
INFO - 2017-09-08 07:22:53 --> Email Class Initialized
INFO - 2017-09-08 07:22:53 --> Controller Class Initialized
DEBUG - 2017-09-08 07:22:53 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 07:22:53 --> Helper loaded: inflector_helper
INFO - 2017-09-08 07:22:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 07:22:53 --> Helper loaded: log_helper
INFO - 2017-09-08 07:22:53 --> Model Class Initialized
INFO - 2017-09-08 14:22:53 --> Final output sent to browser
DEBUG - 2017-09-08 14:22:53 --> Total execution time: 0.0917
INFO - 2017-09-08 07:23:06 --> Config Class Initialized
INFO - 2017-09-08 07:23:06 --> Hooks Class Initialized
DEBUG - 2017-09-08 07:23:06 --> UTF-8 Support Enabled
INFO - 2017-09-08 07:23:06 --> Utf8 Class Initialized
INFO - 2017-09-08 07:23:06 --> URI Class Initialized
INFO - 2017-09-08 07:23:06 --> Router Class Initialized
INFO - 2017-09-08 07:23:06 --> Output Class Initialized
INFO - 2017-09-08 07:23:06 --> Security Class Initialized
DEBUG - 2017-09-08 07:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 07:23:06 --> Input Class Initialized
INFO - 2017-09-08 07:23:06 --> Language Class Initialized
INFO - 2017-09-08 07:23:06 --> Loader Class Initialized
INFO - 2017-09-08 07:23:06 --> Helper loaded: url_helper
INFO - 2017-09-08 07:23:06 --> Database Driver Class Initialized
INFO - 2017-09-08 07:23:06 --> Email Class Initialized
INFO - 2017-09-08 07:23:06 --> Controller Class Initialized
DEBUG - 2017-09-08 07:23:06 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 07:23:06 --> Helper loaded: inflector_helper
INFO - 2017-09-08 07:23:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 07:23:06 --> Helper loaded: log_helper
INFO - 2017-09-08 07:23:06 --> Model Class Initialized
INFO - 2017-09-08 14:23:06 --> Final output sent to browser
DEBUG - 2017-09-08 14:23:06 --> Total execution time: 0.0889
INFO - 2017-09-08 07:23:51 --> Config Class Initialized
INFO - 2017-09-08 07:23:51 --> Hooks Class Initialized
DEBUG - 2017-09-08 07:23:51 --> UTF-8 Support Enabled
INFO - 2017-09-08 07:23:51 --> Utf8 Class Initialized
INFO - 2017-09-08 07:23:51 --> URI Class Initialized
INFO - 2017-09-08 07:23:51 --> Router Class Initialized
INFO - 2017-09-08 07:23:51 --> Output Class Initialized
INFO - 2017-09-08 07:23:51 --> Security Class Initialized
DEBUG - 2017-09-08 07:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 07:23:51 --> Input Class Initialized
INFO - 2017-09-08 07:23:51 --> Language Class Initialized
INFO - 2017-09-08 07:23:51 --> Loader Class Initialized
INFO - 2017-09-08 07:23:51 --> Helper loaded: url_helper
INFO - 2017-09-08 07:23:51 --> Database Driver Class Initialized
INFO - 2017-09-08 07:23:51 --> Email Class Initialized
INFO - 2017-09-08 07:23:51 --> Controller Class Initialized
DEBUG - 2017-09-08 07:23:51 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 07:23:51 --> Helper loaded: inflector_helper
INFO - 2017-09-08 07:23:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 07:23:51 --> Helper loaded: log_helper
INFO - 2017-09-08 07:23:51 --> Model Class Initialized
ERROR - 2017-09-08 14:23:51 --> Severity: Notice --> Undefined variable: sign_up C:\wamp64\www\franknco\application\models\api_model.php 98
INFO - 2017-09-08 14:23:51 --> Final output sent to browser
DEBUG - 2017-09-08 14:23:51 --> Total execution time: 0.0949
INFO - 2017-09-08 07:24:13 --> Config Class Initialized
INFO - 2017-09-08 07:24:13 --> Hooks Class Initialized
DEBUG - 2017-09-08 07:24:13 --> UTF-8 Support Enabled
INFO - 2017-09-08 07:24:13 --> Utf8 Class Initialized
INFO - 2017-09-08 07:24:13 --> URI Class Initialized
INFO - 2017-09-08 07:24:13 --> Router Class Initialized
INFO - 2017-09-08 07:24:13 --> Output Class Initialized
INFO - 2017-09-08 07:24:13 --> Security Class Initialized
DEBUG - 2017-09-08 07:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 07:24:13 --> Input Class Initialized
INFO - 2017-09-08 07:24:13 --> Language Class Initialized
INFO - 2017-09-08 07:24:13 --> Loader Class Initialized
INFO - 2017-09-08 07:24:13 --> Helper loaded: url_helper
INFO - 2017-09-08 07:24:13 --> Database Driver Class Initialized
INFO - 2017-09-08 07:24:13 --> Email Class Initialized
INFO - 2017-09-08 07:24:13 --> Controller Class Initialized
DEBUG - 2017-09-08 07:24:13 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 07:24:13 --> Helper loaded: inflector_helper
INFO - 2017-09-08 07:24:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 07:24:13 --> Helper loaded: log_helper
INFO - 2017-09-08 07:24:13 --> Model Class Initialized
INFO - 2017-09-08 14:24:13 --> Final output sent to browser
DEBUG - 2017-09-08 14:24:13 --> Total execution time: 0.0787
INFO - 2017-09-08 07:24:25 --> Config Class Initialized
INFO - 2017-09-08 07:24:25 --> Hooks Class Initialized
DEBUG - 2017-09-08 07:24:25 --> UTF-8 Support Enabled
INFO - 2017-09-08 07:24:25 --> Utf8 Class Initialized
INFO - 2017-09-08 07:24:25 --> URI Class Initialized
INFO - 2017-09-08 07:24:25 --> Router Class Initialized
INFO - 2017-09-08 07:24:25 --> Output Class Initialized
INFO - 2017-09-08 07:24:25 --> Security Class Initialized
DEBUG - 2017-09-08 07:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 07:24:25 --> Input Class Initialized
INFO - 2017-09-08 07:24:25 --> Language Class Initialized
INFO - 2017-09-08 07:24:25 --> Loader Class Initialized
INFO - 2017-09-08 07:24:25 --> Helper loaded: url_helper
INFO - 2017-09-08 07:24:25 --> Database Driver Class Initialized
INFO - 2017-09-08 07:24:25 --> Email Class Initialized
INFO - 2017-09-08 07:24:25 --> Controller Class Initialized
DEBUG - 2017-09-08 07:24:25 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 07:24:25 --> Helper loaded: inflector_helper
INFO - 2017-09-08 07:24:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 07:24:25 --> Helper loaded: log_helper
INFO - 2017-09-08 07:24:25 --> Model Class Initialized
INFO - 2017-09-08 14:24:25 --> Final output sent to browser
DEBUG - 2017-09-08 14:24:25 --> Total execution time: 0.0960
INFO - 2017-09-08 07:39:11 --> Config Class Initialized
INFO - 2017-09-08 07:39:11 --> Hooks Class Initialized
DEBUG - 2017-09-08 07:39:11 --> UTF-8 Support Enabled
INFO - 2017-09-08 07:39:11 --> Utf8 Class Initialized
INFO - 2017-09-08 07:39:11 --> URI Class Initialized
INFO - 2017-09-08 07:39:11 --> Router Class Initialized
INFO - 2017-09-08 07:39:11 --> Output Class Initialized
INFO - 2017-09-08 07:39:11 --> Security Class Initialized
DEBUG - 2017-09-08 07:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 07:39:11 --> Input Class Initialized
INFO - 2017-09-08 07:39:11 --> Language Class Initialized
INFO - 2017-09-08 07:39:11 --> Loader Class Initialized
INFO - 2017-09-08 07:39:11 --> Helper loaded: url_helper
INFO - 2017-09-08 07:39:11 --> Database Driver Class Initialized
INFO - 2017-09-08 07:39:11 --> Email Class Initialized
INFO - 2017-09-08 07:39:11 --> Controller Class Initialized
DEBUG - 2017-09-08 07:39:11 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 07:39:11 --> Helper loaded: inflector_helper
INFO - 2017-09-08 07:39:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 07:39:11 --> Helper loaded: log_helper
INFO - 2017-09-08 07:39:11 --> Model Class Initialized
INFO - 2017-09-08 14:39:11 --> Final output sent to browser
DEBUG - 2017-09-08 14:39:11 --> Total execution time: 0.1147
INFO - 2017-09-08 07:39:26 --> Config Class Initialized
INFO - 2017-09-08 07:39:26 --> Hooks Class Initialized
DEBUG - 2017-09-08 07:39:26 --> UTF-8 Support Enabled
INFO - 2017-09-08 07:39:26 --> Utf8 Class Initialized
INFO - 2017-09-08 07:39:26 --> URI Class Initialized
INFO - 2017-09-08 07:39:26 --> Router Class Initialized
INFO - 2017-09-08 07:39:26 --> Output Class Initialized
INFO - 2017-09-08 07:39:26 --> Security Class Initialized
DEBUG - 2017-09-08 07:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 07:39:26 --> Input Class Initialized
INFO - 2017-09-08 07:39:26 --> Language Class Initialized
INFO - 2017-09-08 07:39:26 --> Loader Class Initialized
INFO - 2017-09-08 07:39:26 --> Helper loaded: url_helper
INFO - 2017-09-08 07:39:26 --> Database Driver Class Initialized
INFO - 2017-09-08 07:39:26 --> Email Class Initialized
INFO - 2017-09-08 07:39:26 --> Controller Class Initialized
DEBUG - 2017-09-08 07:39:26 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 07:39:26 --> Helper loaded: inflector_helper
INFO - 2017-09-08 07:39:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 07:39:26 --> Helper loaded: log_helper
INFO - 2017-09-08 07:39:26 --> Model Class Initialized
INFO - 2017-09-08 14:39:26 --> Final output sent to browser
DEBUG - 2017-09-08 14:39:26 --> Total execution time: 0.0981
INFO - 2017-09-08 07:39:50 --> Config Class Initialized
INFO - 2017-09-08 07:39:50 --> Hooks Class Initialized
DEBUG - 2017-09-08 07:39:50 --> UTF-8 Support Enabled
INFO - 2017-09-08 07:39:50 --> Utf8 Class Initialized
INFO - 2017-09-08 07:39:50 --> URI Class Initialized
INFO - 2017-09-08 07:39:50 --> Router Class Initialized
INFO - 2017-09-08 07:39:50 --> Output Class Initialized
INFO - 2017-09-08 07:39:50 --> Security Class Initialized
DEBUG - 2017-09-08 07:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 07:39:50 --> Input Class Initialized
INFO - 2017-09-08 07:39:50 --> Language Class Initialized
INFO - 2017-09-08 07:39:50 --> Loader Class Initialized
INFO - 2017-09-08 07:39:50 --> Helper loaded: url_helper
INFO - 2017-09-08 07:39:50 --> Database Driver Class Initialized
INFO - 2017-09-08 07:39:50 --> Email Class Initialized
INFO - 2017-09-08 07:39:50 --> Controller Class Initialized
DEBUG - 2017-09-08 07:39:50 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 07:39:50 --> Helper loaded: inflector_helper
INFO - 2017-09-08 07:39:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 07:39:50 --> Helper loaded: log_helper
INFO - 2017-09-08 07:39:50 --> Model Class Initialized
INFO - 2017-09-08 14:39:50 --> Final output sent to browser
DEBUG - 2017-09-08 14:39:50 --> Total execution time: 0.1404
INFO - 2017-09-08 07:41:53 --> Config Class Initialized
INFO - 2017-09-08 07:41:53 --> Hooks Class Initialized
DEBUG - 2017-09-08 07:41:53 --> UTF-8 Support Enabled
INFO - 2017-09-08 07:41:53 --> Utf8 Class Initialized
INFO - 2017-09-08 07:41:53 --> URI Class Initialized
INFO - 2017-09-08 07:41:53 --> Router Class Initialized
INFO - 2017-09-08 07:41:53 --> Output Class Initialized
INFO - 2017-09-08 07:41:53 --> Security Class Initialized
DEBUG - 2017-09-08 07:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 07:41:53 --> Input Class Initialized
INFO - 2017-09-08 07:41:53 --> Language Class Initialized
INFO - 2017-09-08 07:41:53 --> Loader Class Initialized
INFO - 2017-09-08 07:41:53 --> Helper loaded: url_helper
INFO - 2017-09-08 07:41:53 --> Database Driver Class Initialized
INFO - 2017-09-08 07:41:53 --> Email Class Initialized
INFO - 2017-09-08 07:41:53 --> Controller Class Initialized
DEBUG - 2017-09-08 07:41:53 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 07:41:53 --> Helper loaded: inflector_helper
INFO - 2017-09-08 07:41:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 07:41:53 --> Helper loaded: log_helper
INFO - 2017-09-08 07:41:53 --> Model Class Initialized
INFO - 2017-09-08 14:41:53 --> Final output sent to browser
DEBUG - 2017-09-08 14:41:53 --> Total execution time: 0.1057
INFO - 2017-09-08 07:43:41 --> Config Class Initialized
INFO - 2017-09-08 07:43:41 --> Hooks Class Initialized
DEBUG - 2017-09-08 07:43:41 --> UTF-8 Support Enabled
INFO - 2017-09-08 07:43:41 --> Utf8 Class Initialized
INFO - 2017-09-08 07:43:41 --> URI Class Initialized
INFO - 2017-09-08 07:43:41 --> Router Class Initialized
INFO - 2017-09-08 07:43:41 --> Output Class Initialized
INFO - 2017-09-08 07:43:41 --> Security Class Initialized
DEBUG - 2017-09-08 07:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 07:43:41 --> Input Class Initialized
INFO - 2017-09-08 07:43:41 --> Language Class Initialized
INFO - 2017-09-08 07:43:41 --> Loader Class Initialized
INFO - 2017-09-08 07:43:41 --> Helper loaded: url_helper
INFO - 2017-09-08 07:43:41 --> Database Driver Class Initialized
INFO - 2017-09-08 07:43:42 --> Email Class Initialized
INFO - 2017-09-08 07:43:42 --> Controller Class Initialized
DEBUG - 2017-09-08 07:43:42 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 07:43:42 --> Helper loaded: inflector_helper
INFO - 2017-09-08 07:43:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 07:43:42 --> Helper loaded: log_helper
INFO - 2017-09-08 07:43:42 --> Model Class Initialized
ERROR - 2017-09-08 14:43:42 --> Query error: Unknown column 'activation_date' in 'field list' - Invalid query: insert into user_member(fullname,dob,address,email,hp,passwd,login_attemp,activation_date)
                           values('71374C6E3535376C6C79673D','1992-10-25','59465050484C563847725456777373796139373879413D3D','6A466C7037715246575172386F7433374D70376861673D3D','4D7871704E365861673778545239396E36384D4458513D3D','74782B7A4E6746556F79756D313557666E2F32387A683278396E48705341734B694F325330503779375368355972614363385738766F357551386A2B6D69706D706C6F72625649433032536265454B6762756A485A773D3D','71426C4F72336B315164493D',now())
INFO - 2017-09-08 14:43:42 --> Language file loaded: language/english/db_lang.php
INFO - 2017-09-08 07:45:06 --> Config Class Initialized
INFO - 2017-09-08 07:45:06 --> Hooks Class Initialized
DEBUG - 2017-09-08 07:45:06 --> UTF-8 Support Enabled
INFO - 2017-09-08 07:45:06 --> Utf8 Class Initialized
INFO - 2017-09-08 07:45:06 --> URI Class Initialized
INFO - 2017-09-08 07:45:06 --> Router Class Initialized
INFO - 2017-09-08 07:45:06 --> Output Class Initialized
INFO - 2017-09-08 07:45:06 --> Security Class Initialized
DEBUG - 2017-09-08 07:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 07:45:06 --> Input Class Initialized
INFO - 2017-09-08 07:45:06 --> Language Class Initialized
INFO - 2017-09-08 07:45:06 --> Loader Class Initialized
INFO - 2017-09-08 07:45:06 --> Helper loaded: url_helper
INFO - 2017-09-08 07:45:06 --> Database Driver Class Initialized
INFO - 2017-09-08 07:45:06 --> Email Class Initialized
INFO - 2017-09-08 07:45:06 --> Controller Class Initialized
DEBUG - 2017-09-08 07:45:06 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 07:45:06 --> Helper loaded: inflector_helper
INFO - 2017-09-08 07:45:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 07:45:06 --> Helper loaded: log_helper
INFO - 2017-09-08 07:45:06 --> Model Class Initialized
INFO - 2017-09-08 14:45:06 --> Final output sent to browser
DEBUG - 2017-09-08 14:45:06 --> Total execution time: 0.0972
INFO - 2017-09-08 07:49:51 --> Config Class Initialized
INFO - 2017-09-08 07:49:51 --> Hooks Class Initialized
DEBUG - 2017-09-08 07:49:51 --> UTF-8 Support Enabled
INFO - 2017-09-08 07:49:51 --> Utf8 Class Initialized
INFO - 2017-09-08 07:49:51 --> URI Class Initialized
INFO - 2017-09-08 07:49:51 --> Router Class Initialized
INFO - 2017-09-08 07:49:51 --> Output Class Initialized
INFO - 2017-09-08 07:49:51 --> Security Class Initialized
DEBUG - 2017-09-08 07:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 07:49:51 --> Input Class Initialized
INFO - 2017-09-08 07:49:51 --> Language Class Initialized
INFO - 2017-09-08 07:49:51 --> Loader Class Initialized
INFO - 2017-09-08 07:49:51 --> Helper loaded: url_helper
INFO - 2017-09-08 07:49:51 --> Database Driver Class Initialized
INFO - 2017-09-08 07:49:51 --> Email Class Initialized
INFO - 2017-09-08 07:49:51 --> Controller Class Initialized
DEBUG - 2017-09-08 07:49:51 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 07:49:51 --> Helper loaded: inflector_helper
INFO - 2017-09-08 07:49:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 07:49:51 --> Helper loaded: log_helper
INFO - 2017-09-08 07:49:51 --> Model Class Initialized
INFO - 2017-09-08 14:49:51 --> Final output sent to browser
DEBUG - 2017-09-08 14:49:51 --> Total execution time: 0.0718
INFO - 2017-09-08 07:49:54 --> Config Class Initialized
INFO - 2017-09-08 07:49:54 --> Hooks Class Initialized
DEBUG - 2017-09-08 07:49:54 --> UTF-8 Support Enabled
INFO - 2017-09-08 07:49:54 --> Utf8 Class Initialized
INFO - 2017-09-08 07:49:54 --> URI Class Initialized
INFO - 2017-09-08 07:49:54 --> Router Class Initialized
INFO - 2017-09-08 07:49:54 --> Output Class Initialized
INFO - 2017-09-08 07:49:54 --> Security Class Initialized
DEBUG - 2017-09-08 07:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 07:49:54 --> Input Class Initialized
INFO - 2017-09-08 07:49:54 --> Language Class Initialized
INFO - 2017-09-08 07:49:54 --> Loader Class Initialized
INFO - 2017-09-08 07:49:54 --> Helper loaded: url_helper
INFO - 2017-09-08 07:49:54 --> Database Driver Class Initialized
INFO - 2017-09-08 07:49:54 --> Email Class Initialized
INFO - 2017-09-08 07:49:54 --> Controller Class Initialized
DEBUG - 2017-09-08 07:49:54 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 07:49:54 --> Helper loaded: inflector_helper
INFO - 2017-09-08 07:49:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 07:49:54 --> Helper loaded: log_helper
INFO - 2017-09-08 07:49:54 --> Model Class Initialized
INFO - 2017-09-08 14:49:54 --> Final output sent to browser
DEBUG - 2017-09-08 14:49:54 --> Total execution time: 0.1829
INFO - 2017-09-08 07:50:08 --> Config Class Initialized
INFO - 2017-09-08 07:50:08 --> Hooks Class Initialized
DEBUG - 2017-09-08 07:50:08 --> UTF-8 Support Enabled
INFO - 2017-09-08 07:50:08 --> Utf8 Class Initialized
INFO - 2017-09-08 07:50:08 --> URI Class Initialized
INFO - 2017-09-08 07:50:08 --> Router Class Initialized
INFO - 2017-09-08 07:50:08 --> Output Class Initialized
INFO - 2017-09-08 07:50:08 --> Security Class Initialized
DEBUG - 2017-09-08 07:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 07:50:08 --> Input Class Initialized
INFO - 2017-09-08 07:50:08 --> Language Class Initialized
INFO - 2017-09-08 07:50:08 --> Loader Class Initialized
INFO - 2017-09-08 07:50:08 --> Helper loaded: url_helper
INFO - 2017-09-08 07:50:08 --> Database Driver Class Initialized
INFO - 2017-09-08 07:50:08 --> Email Class Initialized
INFO - 2017-09-08 07:50:08 --> Controller Class Initialized
DEBUG - 2017-09-08 07:50:08 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 07:50:08 --> Helper loaded: inflector_helper
INFO - 2017-09-08 07:50:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 07:50:08 --> Helper loaded: log_helper
INFO - 2017-09-08 07:50:08 --> Model Class Initialized
ERROR - 2017-09-08 14:50:08 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\franknco\application\models\api_model.php 421
INFO - 2017-09-08 14:50:08 --> Final output sent to browser
DEBUG - 2017-09-08 14:50:08 --> Total execution time: 0.0606
INFO - 2017-09-08 07:50:11 --> Config Class Initialized
INFO - 2017-09-08 07:50:11 --> Hooks Class Initialized
DEBUG - 2017-09-08 07:50:11 --> UTF-8 Support Enabled
INFO - 2017-09-08 07:50:11 --> Utf8 Class Initialized
INFO - 2017-09-08 07:50:11 --> URI Class Initialized
INFO - 2017-09-08 07:50:11 --> Router Class Initialized
INFO - 2017-09-08 07:50:11 --> Output Class Initialized
INFO - 2017-09-08 07:50:11 --> Security Class Initialized
DEBUG - 2017-09-08 07:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 07:50:11 --> Input Class Initialized
INFO - 2017-09-08 07:50:11 --> Language Class Initialized
INFO - 2017-09-08 07:50:11 --> Loader Class Initialized
INFO - 2017-09-08 07:50:11 --> Helper loaded: url_helper
INFO - 2017-09-08 07:50:11 --> Database Driver Class Initialized
INFO - 2017-09-08 07:50:11 --> Email Class Initialized
INFO - 2017-09-08 07:50:11 --> Controller Class Initialized
DEBUG - 2017-09-08 07:50:11 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 07:50:11 --> Helper loaded: inflector_helper
INFO - 2017-09-08 07:50:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 07:50:11 --> Helper loaded: log_helper
INFO - 2017-09-08 07:50:11 --> Model Class Initialized
INFO - 2017-09-08 14:50:11 --> Final output sent to browser
DEBUG - 2017-09-08 14:50:11 --> Total execution time: 0.0828
INFO - 2017-09-08 07:50:11 --> Config Class Initialized
INFO - 2017-09-08 07:50:11 --> Hooks Class Initialized
DEBUG - 2017-09-08 07:50:11 --> UTF-8 Support Enabled
INFO - 2017-09-08 07:50:11 --> Utf8 Class Initialized
INFO - 2017-09-08 07:50:11 --> URI Class Initialized
INFO - 2017-09-08 07:50:11 --> Router Class Initialized
INFO - 2017-09-08 07:50:11 --> Output Class Initialized
INFO - 2017-09-08 07:50:11 --> Security Class Initialized
DEBUG - 2017-09-08 07:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 07:50:11 --> Input Class Initialized
INFO - 2017-09-08 07:50:11 --> Language Class Initialized
INFO - 2017-09-08 07:50:12 --> Loader Class Initialized
INFO - 2017-09-08 07:50:12 --> Helper loaded: url_helper
INFO - 2017-09-08 07:50:12 --> Database Driver Class Initialized
INFO - 2017-09-08 07:50:12 --> Email Class Initialized
INFO - 2017-09-08 07:50:12 --> Controller Class Initialized
DEBUG - 2017-09-08 07:50:12 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 07:50:12 --> Helper loaded: inflector_helper
INFO - 2017-09-08 07:50:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 07:50:12 --> Helper loaded: log_helper
INFO - 2017-09-08 07:50:12 --> Model Class Initialized
INFO - 2017-09-08 14:50:12 --> Final output sent to browser
DEBUG - 2017-09-08 14:50:12 --> Total execution time: 0.1252
INFO - 2017-09-08 07:50:41 --> Config Class Initialized
INFO - 2017-09-08 07:50:41 --> Hooks Class Initialized
DEBUG - 2017-09-08 07:50:41 --> UTF-8 Support Enabled
INFO - 2017-09-08 07:50:41 --> Utf8 Class Initialized
INFO - 2017-09-08 07:50:41 --> URI Class Initialized
INFO - 2017-09-08 07:50:41 --> Router Class Initialized
INFO - 2017-09-08 07:50:41 --> Output Class Initialized
INFO - 2017-09-08 07:50:41 --> Security Class Initialized
DEBUG - 2017-09-08 07:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 07:50:41 --> Input Class Initialized
INFO - 2017-09-08 07:50:41 --> Language Class Initialized
INFO - 2017-09-08 07:50:41 --> Loader Class Initialized
INFO - 2017-09-08 07:50:41 --> Helper loaded: url_helper
INFO - 2017-09-08 07:50:41 --> Database Driver Class Initialized
INFO - 2017-09-08 07:50:41 --> Email Class Initialized
INFO - 2017-09-08 07:50:41 --> Controller Class Initialized
DEBUG - 2017-09-08 07:50:41 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 07:50:41 --> Helper loaded: inflector_helper
INFO - 2017-09-08 07:50:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 07:50:41 --> Helper loaded: log_helper
INFO - 2017-09-08 07:50:41 --> Model Class Initialized
INFO - 2017-09-08 14:50:41 --> Final output sent to browser
DEBUG - 2017-09-08 14:50:41 --> Total execution time: 0.0622
INFO - 2017-09-08 07:50:41 --> Config Class Initialized
INFO - 2017-09-08 07:50:41 --> Hooks Class Initialized
DEBUG - 2017-09-08 07:50:41 --> UTF-8 Support Enabled
INFO - 2017-09-08 07:50:41 --> Utf8 Class Initialized
INFO - 2017-09-08 07:50:41 --> URI Class Initialized
INFO - 2017-09-08 07:50:41 --> Router Class Initialized
INFO - 2017-09-08 07:50:41 --> Output Class Initialized
INFO - 2017-09-08 07:50:41 --> Security Class Initialized
DEBUG - 2017-09-08 07:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 07:50:41 --> Input Class Initialized
INFO - 2017-09-08 07:50:41 --> Language Class Initialized
INFO - 2017-09-08 07:50:41 --> Loader Class Initialized
INFO - 2017-09-08 07:50:41 --> Helper loaded: url_helper
INFO - 2017-09-08 07:50:41 --> Database Driver Class Initialized
INFO - 2017-09-08 07:50:41 --> Email Class Initialized
INFO - 2017-09-08 07:50:41 --> Controller Class Initialized
DEBUG - 2017-09-08 07:50:41 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 07:50:41 --> Helper loaded: inflector_helper
INFO - 2017-09-08 07:50:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 07:50:41 --> Helper loaded: log_helper
INFO - 2017-09-08 07:50:41 --> Model Class Initialized
INFO - 2017-09-08 14:50:41 --> Final output sent to browser
DEBUG - 2017-09-08 14:50:41 --> Total execution time: 0.0692
INFO - 2017-09-08 07:50:48 --> Config Class Initialized
INFO - 2017-09-08 07:50:48 --> Hooks Class Initialized
DEBUG - 2017-09-08 07:50:48 --> UTF-8 Support Enabled
INFO - 2017-09-08 07:50:48 --> Utf8 Class Initialized
INFO - 2017-09-08 07:50:48 --> URI Class Initialized
INFO - 2017-09-08 07:50:48 --> Router Class Initialized
INFO - 2017-09-08 07:50:48 --> Output Class Initialized
INFO - 2017-09-08 07:50:48 --> Security Class Initialized
DEBUG - 2017-09-08 07:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 07:50:48 --> Input Class Initialized
INFO - 2017-09-08 07:50:48 --> Language Class Initialized
INFO - 2017-09-08 07:50:48 --> Loader Class Initialized
INFO - 2017-09-08 07:50:48 --> Helper loaded: url_helper
INFO - 2017-09-08 07:50:48 --> Database Driver Class Initialized
INFO - 2017-09-08 07:50:48 --> Email Class Initialized
INFO - 2017-09-08 07:50:48 --> Controller Class Initialized
DEBUG - 2017-09-08 07:50:48 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 07:50:48 --> Helper loaded: inflector_helper
INFO - 2017-09-08 07:50:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 07:50:48 --> Helper loaded: log_helper
INFO - 2017-09-08 07:50:48 --> Model Class Initialized
INFO - 2017-09-08 14:50:48 --> Final output sent to browser
DEBUG - 2017-09-08 14:50:48 --> Total execution time: 0.0582
INFO - 2017-09-08 07:50:48 --> Config Class Initialized
INFO - 2017-09-08 07:50:48 --> Hooks Class Initialized
DEBUG - 2017-09-08 07:50:48 --> UTF-8 Support Enabled
INFO - 2017-09-08 07:50:48 --> Utf8 Class Initialized
INFO - 2017-09-08 07:50:48 --> URI Class Initialized
INFO - 2017-09-08 07:50:48 --> Router Class Initialized
INFO - 2017-09-08 07:50:48 --> Output Class Initialized
INFO - 2017-09-08 07:50:48 --> Security Class Initialized
DEBUG - 2017-09-08 07:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 07:50:48 --> Input Class Initialized
INFO - 2017-09-08 07:50:48 --> Language Class Initialized
INFO - 2017-09-08 07:50:48 --> Loader Class Initialized
INFO - 2017-09-08 07:50:48 --> Helper loaded: url_helper
INFO - 2017-09-08 07:50:48 --> Database Driver Class Initialized
INFO - 2017-09-08 07:50:48 --> Email Class Initialized
INFO - 2017-09-08 07:50:48 --> Controller Class Initialized
DEBUG - 2017-09-08 07:50:48 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 07:50:48 --> Helper loaded: inflector_helper
INFO - 2017-09-08 07:50:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 07:50:48 --> Helper loaded: log_helper
INFO - 2017-09-08 07:50:48 --> Model Class Initialized
INFO - 2017-09-08 14:50:48 --> Final output sent to browser
DEBUG - 2017-09-08 14:50:48 --> Total execution time: 0.0835
INFO - 2017-09-08 07:56:55 --> Config Class Initialized
INFO - 2017-09-08 07:56:55 --> Hooks Class Initialized
DEBUG - 2017-09-08 07:56:55 --> UTF-8 Support Enabled
INFO - 2017-09-08 07:56:55 --> Utf8 Class Initialized
INFO - 2017-09-08 07:56:55 --> URI Class Initialized
INFO - 2017-09-08 07:56:55 --> Router Class Initialized
INFO - 2017-09-08 07:56:55 --> Output Class Initialized
INFO - 2017-09-08 07:56:55 --> Security Class Initialized
DEBUG - 2017-09-08 07:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 07:56:55 --> Input Class Initialized
INFO - 2017-09-08 07:56:55 --> Language Class Initialized
INFO - 2017-09-08 07:56:55 --> Loader Class Initialized
INFO - 2017-09-08 07:56:55 --> Helper loaded: url_helper
INFO - 2017-09-08 07:56:55 --> Database Driver Class Initialized
INFO - 2017-09-08 07:56:55 --> Email Class Initialized
INFO - 2017-09-08 07:56:55 --> Controller Class Initialized
DEBUG - 2017-09-08 07:56:55 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 07:56:55 --> Helper loaded: inflector_helper
INFO - 2017-09-08 07:56:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 07:56:55 --> Helper loaded: log_helper
INFO - 2017-09-08 07:56:55 --> Model Class Initialized
INFO - 2017-09-08 14:56:55 --> Final output sent to browser
DEBUG - 2017-09-08 14:56:55 --> Total execution time: 0.0740
INFO - 2017-09-08 08:12:19 --> Config Class Initialized
INFO - 2017-09-08 08:12:19 --> Hooks Class Initialized
DEBUG - 2017-09-08 08:12:19 --> UTF-8 Support Enabled
INFO - 2017-09-08 08:12:19 --> Utf8 Class Initialized
INFO - 2017-09-08 08:12:19 --> URI Class Initialized
INFO - 2017-09-08 08:12:19 --> Router Class Initialized
INFO - 2017-09-08 08:12:19 --> Output Class Initialized
INFO - 2017-09-08 08:12:19 --> Security Class Initialized
DEBUG - 2017-09-08 08:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 08:12:19 --> Input Class Initialized
INFO - 2017-09-08 08:12:19 --> Language Class Initialized
INFO - 2017-09-08 08:12:19 --> Loader Class Initialized
INFO - 2017-09-08 08:12:19 --> Helper loaded: url_helper
INFO - 2017-09-08 08:12:19 --> Database Driver Class Initialized
INFO - 2017-09-08 08:12:19 --> Email Class Initialized
INFO - 2017-09-08 08:12:19 --> Controller Class Initialized
DEBUG - 2017-09-08 08:12:19 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 08:12:19 --> Helper loaded: inflector_helper
INFO - 2017-09-08 08:12:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 08:12:19 --> Helper loaded: log_helper
INFO - 2017-09-08 08:12:19 --> Model Class Initialized
INFO - 2017-09-08 15:12:19 --> Final output sent to browser
DEBUG - 2017-09-08 15:12:19 --> Total execution time: 0.0576
INFO - 2017-09-08 08:12:24 --> Config Class Initialized
INFO - 2017-09-08 08:12:24 --> Hooks Class Initialized
DEBUG - 2017-09-08 08:12:24 --> UTF-8 Support Enabled
INFO - 2017-09-08 08:12:24 --> Utf8 Class Initialized
INFO - 2017-09-08 08:12:24 --> URI Class Initialized
INFO - 2017-09-08 08:12:24 --> Router Class Initialized
INFO - 2017-09-08 08:12:24 --> Output Class Initialized
INFO - 2017-09-08 08:12:24 --> Security Class Initialized
DEBUG - 2017-09-08 08:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 08:12:24 --> Input Class Initialized
INFO - 2017-09-08 08:12:24 --> Language Class Initialized
INFO - 2017-09-08 08:12:24 --> Loader Class Initialized
INFO - 2017-09-08 08:12:24 --> Helper loaded: url_helper
INFO - 2017-09-08 08:12:24 --> Database Driver Class Initialized
INFO - 2017-09-08 08:12:24 --> Email Class Initialized
INFO - 2017-09-08 08:12:24 --> Controller Class Initialized
DEBUG - 2017-09-08 08:12:24 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 08:12:24 --> Helper loaded: inflector_helper
INFO - 2017-09-08 08:12:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 08:12:24 --> Helper loaded: log_helper
INFO - 2017-09-08 08:12:24 --> Model Class Initialized
INFO - 2017-09-08 15:12:24 --> Final output sent to browser
DEBUG - 2017-09-08 15:12:24 --> Total execution time: 0.0815
INFO - 2017-09-08 08:12:39 --> Config Class Initialized
INFO - 2017-09-08 08:12:39 --> Hooks Class Initialized
DEBUG - 2017-09-08 08:12:39 --> UTF-8 Support Enabled
INFO - 2017-09-08 08:12:39 --> Utf8 Class Initialized
INFO - 2017-09-08 08:12:39 --> URI Class Initialized
INFO - 2017-09-08 08:12:39 --> Router Class Initialized
INFO - 2017-09-08 08:12:39 --> Output Class Initialized
INFO - 2017-09-08 08:12:39 --> Security Class Initialized
DEBUG - 2017-09-08 08:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 08:12:39 --> Input Class Initialized
INFO - 2017-09-08 08:12:39 --> Language Class Initialized
INFO - 2017-09-08 08:12:39 --> Loader Class Initialized
INFO - 2017-09-08 08:12:39 --> Helper loaded: url_helper
INFO - 2017-09-08 08:12:39 --> Database Driver Class Initialized
INFO - 2017-09-08 08:12:39 --> Email Class Initialized
INFO - 2017-09-08 08:12:39 --> Controller Class Initialized
DEBUG - 2017-09-08 08:12:39 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 08:12:39 --> Helper loaded: inflector_helper
INFO - 2017-09-08 08:12:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 08:12:39 --> Helper loaded: log_helper
INFO - 2017-09-08 08:12:39 --> Model Class Initialized
INFO - 2017-09-08 15:12:39 --> Final output sent to browser
DEBUG - 2017-09-08 15:12:39 --> Total execution time: 0.0583
INFO - 2017-09-08 08:12:39 --> Config Class Initialized
INFO - 2017-09-08 08:12:39 --> Hooks Class Initialized
DEBUG - 2017-09-08 08:12:39 --> UTF-8 Support Enabled
INFO - 2017-09-08 08:12:39 --> Utf8 Class Initialized
INFO - 2017-09-08 08:12:39 --> URI Class Initialized
INFO - 2017-09-08 08:12:39 --> Router Class Initialized
INFO - 2017-09-08 08:12:39 --> Output Class Initialized
INFO - 2017-09-08 08:12:39 --> Security Class Initialized
DEBUG - 2017-09-08 08:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 08:12:39 --> Input Class Initialized
INFO - 2017-09-08 08:12:39 --> Language Class Initialized
INFO - 2017-09-08 08:12:39 --> Loader Class Initialized
INFO - 2017-09-08 08:12:39 --> Helper loaded: url_helper
INFO - 2017-09-08 08:12:39 --> Database Driver Class Initialized
INFO - 2017-09-08 08:12:39 --> Email Class Initialized
INFO - 2017-09-08 08:12:39 --> Controller Class Initialized
DEBUG - 2017-09-08 08:12:39 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 08:12:39 --> Helper loaded: inflector_helper
INFO - 2017-09-08 08:12:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 08:12:39 --> Helper loaded: log_helper
INFO - 2017-09-08 08:12:39 --> Model Class Initialized
INFO - 2017-09-08 15:12:39 --> Final output sent to browser
DEBUG - 2017-09-08 15:12:39 --> Total execution time: 0.0745
INFO - 2017-09-08 08:13:01 --> Config Class Initialized
INFO - 2017-09-08 08:13:01 --> Hooks Class Initialized
DEBUG - 2017-09-08 08:13:01 --> UTF-8 Support Enabled
INFO - 2017-09-08 08:13:01 --> Utf8 Class Initialized
INFO - 2017-09-08 08:13:01 --> URI Class Initialized
INFO - 2017-09-08 08:13:01 --> Router Class Initialized
INFO - 2017-09-08 08:13:01 --> Output Class Initialized
INFO - 2017-09-08 08:13:01 --> Security Class Initialized
DEBUG - 2017-09-08 08:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 08:13:01 --> Input Class Initialized
INFO - 2017-09-08 08:13:01 --> Language Class Initialized
INFO - 2017-09-08 08:13:01 --> Loader Class Initialized
INFO - 2017-09-08 08:13:01 --> Helper loaded: url_helper
INFO - 2017-09-08 08:13:01 --> Database Driver Class Initialized
INFO - 2017-09-08 08:13:01 --> Email Class Initialized
INFO - 2017-09-08 08:13:01 --> Controller Class Initialized
DEBUG - 2017-09-08 08:13:01 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 08:13:01 --> Helper loaded: inflector_helper
INFO - 2017-09-08 08:13:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 08:13:01 --> Helper loaded: log_helper
INFO - 2017-09-08 08:13:01 --> Model Class Initialized
INFO - 2017-09-08 15:13:01 --> Final output sent to browser
DEBUG - 2017-09-08 15:13:01 --> Total execution time: 0.0912
INFO - 2017-09-08 08:13:01 --> Config Class Initialized
INFO - 2017-09-08 08:13:01 --> Hooks Class Initialized
DEBUG - 2017-09-08 08:13:01 --> UTF-8 Support Enabled
INFO - 2017-09-08 08:13:01 --> Utf8 Class Initialized
INFO - 2017-09-08 08:13:01 --> URI Class Initialized
INFO - 2017-09-08 08:13:01 --> Router Class Initialized
INFO - 2017-09-08 08:13:01 --> Output Class Initialized
INFO - 2017-09-08 08:13:01 --> Security Class Initialized
DEBUG - 2017-09-08 08:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 08:13:01 --> Input Class Initialized
INFO - 2017-09-08 08:13:01 --> Language Class Initialized
INFO - 2017-09-08 08:13:01 --> Loader Class Initialized
INFO - 2017-09-08 08:13:01 --> Helper loaded: url_helper
INFO - 2017-09-08 08:13:01 --> Database Driver Class Initialized
INFO - 2017-09-08 08:13:01 --> Email Class Initialized
INFO - 2017-09-08 08:13:01 --> Controller Class Initialized
DEBUG - 2017-09-08 08:13:01 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 08:13:01 --> Helper loaded: inflector_helper
INFO - 2017-09-08 08:13:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 08:13:01 --> Helper loaded: log_helper
INFO - 2017-09-08 08:13:01 --> Model Class Initialized
INFO - 2017-09-08 15:13:01 --> Final output sent to browser
DEBUG - 2017-09-08 15:13:01 --> Total execution time: 0.0775
INFO - 2017-09-08 08:14:04 --> Config Class Initialized
INFO - 2017-09-08 08:14:04 --> Hooks Class Initialized
DEBUG - 2017-09-08 08:14:04 --> UTF-8 Support Enabled
INFO - 2017-09-08 08:14:04 --> Utf8 Class Initialized
INFO - 2017-09-08 08:14:04 --> URI Class Initialized
INFO - 2017-09-08 08:14:04 --> Router Class Initialized
INFO - 2017-09-08 08:14:04 --> Output Class Initialized
INFO - 2017-09-08 08:14:04 --> Security Class Initialized
DEBUG - 2017-09-08 08:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 08:14:04 --> Input Class Initialized
INFO - 2017-09-08 08:14:04 --> Language Class Initialized
INFO - 2017-09-08 08:14:04 --> Loader Class Initialized
INFO - 2017-09-08 08:14:04 --> Helper loaded: url_helper
INFO - 2017-09-08 08:14:04 --> Database Driver Class Initialized
INFO - 2017-09-08 08:14:04 --> Email Class Initialized
INFO - 2017-09-08 08:14:04 --> Controller Class Initialized
DEBUG - 2017-09-08 08:14:04 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 08:14:04 --> Helper loaded: inflector_helper
INFO - 2017-09-08 08:14:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 08:14:04 --> Helper loaded: log_helper
INFO - 2017-09-08 08:14:04 --> Model Class Initialized
INFO - 2017-09-08 15:14:04 --> Final output sent to browser
DEBUG - 2017-09-08 15:14:04 --> Total execution time: 0.0614
INFO - 2017-09-08 08:14:04 --> Config Class Initialized
INFO - 2017-09-08 08:14:04 --> Hooks Class Initialized
DEBUG - 2017-09-08 08:14:04 --> UTF-8 Support Enabled
INFO - 2017-09-08 08:14:04 --> Utf8 Class Initialized
INFO - 2017-09-08 08:14:04 --> URI Class Initialized
INFO - 2017-09-08 08:14:04 --> Router Class Initialized
INFO - 2017-09-08 08:14:04 --> Output Class Initialized
INFO - 2017-09-08 08:14:04 --> Security Class Initialized
DEBUG - 2017-09-08 08:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 08:14:04 --> Input Class Initialized
INFO - 2017-09-08 08:14:04 --> Language Class Initialized
INFO - 2017-09-08 08:14:04 --> Loader Class Initialized
INFO - 2017-09-08 08:14:04 --> Helper loaded: url_helper
INFO - 2017-09-08 08:14:04 --> Database Driver Class Initialized
INFO - 2017-09-08 08:14:04 --> Email Class Initialized
INFO - 2017-09-08 08:14:04 --> Controller Class Initialized
DEBUG - 2017-09-08 08:14:04 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 08:14:04 --> Helper loaded: inflector_helper
INFO - 2017-09-08 08:14:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 08:14:04 --> Helper loaded: log_helper
INFO - 2017-09-08 08:14:04 --> Model Class Initialized
INFO - 2017-09-08 15:14:04 --> Final output sent to browser
DEBUG - 2017-09-08 15:14:04 --> Total execution time: 0.0954
INFO - 2017-09-08 08:15:13 --> Config Class Initialized
INFO - 2017-09-08 08:15:13 --> Hooks Class Initialized
DEBUG - 2017-09-08 08:15:13 --> UTF-8 Support Enabled
INFO - 2017-09-08 08:15:13 --> Utf8 Class Initialized
INFO - 2017-09-08 08:15:13 --> URI Class Initialized
INFO - 2017-09-08 08:15:13 --> Router Class Initialized
INFO - 2017-09-08 08:15:13 --> Output Class Initialized
INFO - 2017-09-08 08:15:13 --> Security Class Initialized
DEBUG - 2017-09-08 08:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 08:15:13 --> Input Class Initialized
INFO - 2017-09-08 08:15:13 --> Language Class Initialized
INFO - 2017-09-08 08:15:13 --> Loader Class Initialized
INFO - 2017-09-08 08:15:13 --> Helper loaded: url_helper
INFO - 2017-09-08 08:15:13 --> Database Driver Class Initialized
INFO - 2017-09-08 08:15:13 --> Email Class Initialized
INFO - 2017-09-08 08:15:13 --> Controller Class Initialized
DEBUG - 2017-09-08 08:15:13 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 08:15:13 --> Helper loaded: inflector_helper
INFO - 2017-09-08 08:15:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 08:15:13 --> Helper loaded: log_helper
INFO - 2017-09-08 08:15:13 --> Model Class Initialized
INFO - 2017-09-08 15:15:13 --> Final output sent to browser
DEBUG - 2017-09-08 15:15:13 --> Total execution time: 0.0580
INFO - 2017-09-08 08:15:13 --> Config Class Initialized
INFO - 2017-09-08 08:15:13 --> Hooks Class Initialized
DEBUG - 2017-09-08 08:15:13 --> UTF-8 Support Enabled
INFO - 2017-09-08 08:15:13 --> Utf8 Class Initialized
INFO - 2017-09-08 08:15:13 --> URI Class Initialized
INFO - 2017-09-08 08:15:13 --> Router Class Initialized
INFO - 2017-09-08 08:15:13 --> Output Class Initialized
INFO - 2017-09-08 08:15:13 --> Security Class Initialized
DEBUG - 2017-09-08 08:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 08:15:13 --> Input Class Initialized
INFO - 2017-09-08 08:15:13 --> Language Class Initialized
INFO - 2017-09-08 08:15:13 --> Loader Class Initialized
INFO - 2017-09-08 08:15:13 --> Helper loaded: url_helper
INFO - 2017-09-08 08:15:13 --> Database Driver Class Initialized
INFO - 2017-09-08 08:15:13 --> Email Class Initialized
INFO - 2017-09-08 08:15:13 --> Controller Class Initialized
DEBUG - 2017-09-08 08:15:13 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 08:15:13 --> Helper loaded: inflector_helper
INFO - 2017-09-08 08:15:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 08:15:13 --> Helper loaded: log_helper
INFO - 2017-09-08 08:15:13 --> Model Class Initialized
INFO - 2017-09-08 15:15:13 --> Final output sent to browser
DEBUG - 2017-09-08 15:15:13 --> Total execution time: 0.0740
INFO - 2017-09-08 08:26:26 --> Config Class Initialized
INFO - 2017-09-08 08:26:26 --> Hooks Class Initialized
DEBUG - 2017-09-08 08:26:26 --> UTF-8 Support Enabled
INFO - 2017-09-08 08:26:26 --> Utf8 Class Initialized
INFO - 2017-09-08 08:26:26 --> URI Class Initialized
INFO - 2017-09-08 08:26:26 --> Router Class Initialized
INFO - 2017-09-08 08:26:26 --> Output Class Initialized
INFO - 2017-09-08 08:26:26 --> Security Class Initialized
DEBUG - 2017-09-08 08:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 08:26:26 --> Input Class Initialized
INFO - 2017-09-08 08:26:26 --> Language Class Initialized
INFO - 2017-09-08 08:26:26 --> Loader Class Initialized
INFO - 2017-09-08 08:26:26 --> Helper loaded: url_helper
INFO - 2017-09-08 08:26:26 --> Database Driver Class Initialized
INFO - 2017-09-08 08:26:26 --> Email Class Initialized
INFO - 2017-09-08 08:26:26 --> Controller Class Initialized
DEBUG - 2017-09-08 08:26:26 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 08:26:26 --> Helper loaded: inflector_helper
INFO - 2017-09-08 08:26:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 08:26:26 --> Helper loaded: log_helper
INFO - 2017-09-08 08:26:26 --> Model Class Initialized
ERROR - 2017-09-08 08:26:26 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\wamp64\www\franknco\application\models\api_model.php 343
INFO - 2017-09-08 08:26:30 --> Config Class Initialized
INFO - 2017-09-08 08:26:30 --> Hooks Class Initialized
DEBUG - 2017-09-08 08:26:30 --> UTF-8 Support Enabled
INFO - 2017-09-08 08:26:30 --> Utf8 Class Initialized
INFO - 2017-09-08 08:26:30 --> URI Class Initialized
INFO - 2017-09-08 08:26:30 --> Router Class Initialized
INFO - 2017-09-08 08:26:30 --> Output Class Initialized
INFO - 2017-09-08 08:26:30 --> Security Class Initialized
DEBUG - 2017-09-08 08:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 08:26:30 --> Input Class Initialized
INFO - 2017-09-08 08:26:30 --> Language Class Initialized
INFO - 2017-09-08 08:26:30 --> Loader Class Initialized
INFO - 2017-09-08 08:26:30 --> Helper loaded: url_helper
INFO - 2017-09-08 08:26:30 --> Database Driver Class Initialized
INFO - 2017-09-08 08:26:30 --> Email Class Initialized
INFO - 2017-09-08 08:26:30 --> Controller Class Initialized
DEBUG - 2017-09-08 08:26:30 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 08:26:30 --> Helper loaded: inflector_helper
INFO - 2017-09-08 08:26:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 08:26:30 --> Helper loaded: log_helper
INFO - 2017-09-08 08:26:30 --> Model Class Initialized
ERROR - 2017-09-08 08:26:30 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\wamp64\www\franknco\application\models\api_model.php 343
INFO - 2017-09-08 08:26:34 --> Config Class Initialized
INFO - 2017-09-08 08:26:34 --> Hooks Class Initialized
DEBUG - 2017-09-08 08:26:34 --> UTF-8 Support Enabled
INFO - 2017-09-08 08:26:34 --> Utf8 Class Initialized
INFO - 2017-09-08 08:26:34 --> URI Class Initialized
INFO - 2017-09-08 08:26:34 --> Router Class Initialized
INFO - 2017-09-08 08:26:34 --> Output Class Initialized
INFO - 2017-09-08 08:26:34 --> Security Class Initialized
DEBUG - 2017-09-08 08:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 08:26:34 --> Input Class Initialized
INFO - 2017-09-08 08:26:34 --> Language Class Initialized
INFO - 2017-09-08 08:26:34 --> Loader Class Initialized
INFO - 2017-09-08 08:26:34 --> Helper loaded: url_helper
INFO - 2017-09-08 08:26:34 --> Database Driver Class Initialized
INFO - 2017-09-08 08:26:34 --> Email Class Initialized
INFO - 2017-09-08 08:26:34 --> Controller Class Initialized
DEBUG - 2017-09-08 08:26:34 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 08:26:34 --> Helper loaded: inflector_helper
INFO - 2017-09-08 08:26:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 08:26:34 --> Helper loaded: log_helper
INFO - 2017-09-08 08:26:34 --> Model Class Initialized
ERROR - 2017-09-08 08:26:34 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\wamp64\www\franknco\application\models\api_model.php 343
INFO - 2017-09-08 08:26:36 --> Config Class Initialized
INFO - 2017-09-08 08:26:36 --> Hooks Class Initialized
DEBUG - 2017-09-08 08:26:36 --> UTF-8 Support Enabled
INFO - 2017-09-08 08:26:36 --> Utf8 Class Initialized
INFO - 2017-09-08 08:26:36 --> URI Class Initialized
INFO - 2017-09-08 08:26:36 --> Router Class Initialized
INFO - 2017-09-08 08:26:36 --> Output Class Initialized
INFO - 2017-09-08 08:26:36 --> Security Class Initialized
DEBUG - 2017-09-08 08:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 08:26:36 --> Input Class Initialized
INFO - 2017-09-08 08:26:36 --> Language Class Initialized
INFO - 2017-09-08 08:26:36 --> Loader Class Initialized
INFO - 2017-09-08 08:26:36 --> Helper loaded: url_helper
INFO - 2017-09-08 08:26:36 --> Database Driver Class Initialized
INFO - 2017-09-08 08:26:36 --> Email Class Initialized
INFO - 2017-09-08 08:26:36 --> Controller Class Initialized
DEBUG - 2017-09-08 08:26:36 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 08:26:36 --> Helper loaded: inflector_helper
INFO - 2017-09-08 08:26:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 08:26:36 --> Helper loaded: log_helper
INFO - 2017-09-08 08:26:36 --> Model Class Initialized
ERROR - 2017-09-08 08:26:36 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\wamp64\www\franknco\application\models\api_model.php 343
INFO - 2017-09-08 08:26:38 --> Config Class Initialized
INFO - 2017-09-08 08:26:38 --> Hooks Class Initialized
DEBUG - 2017-09-08 08:26:38 --> UTF-8 Support Enabled
INFO - 2017-09-08 08:26:38 --> Utf8 Class Initialized
INFO - 2017-09-08 08:26:38 --> URI Class Initialized
INFO - 2017-09-08 08:26:38 --> Router Class Initialized
INFO - 2017-09-08 08:26:38 --> Output Class Initialized
INFO - 2017-09-08 08:26:38 --> Security Class Initialized
DEBUG - 2017-09-08 08:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 08:26:38 --> Input Class Initialized
INFO - 2017-09-08 08:26:38 --> Language Class Initialized
INFO - 2017-09-08 08:26:38 --> Loader Class Initialized
INFO - 2017-09-08 08:26:38 --> Helper loaded: url_helper
INFO - 2017-09-08 08:26:38 --> Database Driver Class Initialized
INFO - 2017-09-08 08:26:38 --> Email Class Initialized
INFO - 2017-09-08 08:26:38 --> Controller Class Initialized
DEBUG - 2017-09-08 08:26:38 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 08:26:38 --> Helper loaded: inflector_helper
INFO - 2017-09-08 08:26:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 08:26:38 --> Helper loaded: log_helper
INFO - 2017-09-08 08:26:38 --> Model Class Initialized
ERROR - 2017-09-08 08:26:38 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\wamp64\www\franknco\application\models\api_model.php 343
INFO - 2017-09-08 08:26:40 --> Config Class Initialized
INFO - 2017-09-08 08:26:40 --> Hooks Class Initialized
DEBUG - 2017-09-08 08:26:40 --> UTF-8 Support Enabled
INFO - 2017-09-08 08:26:40 --> Utf8 Class Initialized
INFO - 2017-09-08 08:26:40 --> URI Class Initialized
INFO - 2017-09-08 08:26:40 --> Router Class Initialized
INFO - 2017-09-08 08:26:40 --> Output Class Initialized
INFO - 2017-09-08 08:26:40 --> Security Class Initialized
DEBUG - 2017-09-08 08:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 08:26:40 --> Input Class Initialized
INFO - 2017-09-08 08:26:40 --> Language Class Initialized
INFO - 2017-09-08 08:26:40 --> Loader Class Initialized
INFO - 2017-09-08 08:26:40 --> Helper loaded: url_helper
INFO - 2017-09-08 08:26:40 --> Database Driver Class Initialized
INFO - 2017-09-08 08:26:40 --> Email Class Initialized
INFO - 2017-09-08 08:26:40 --> Controller Class Initialized
DEBUG - 2017-09-08 08:26:40 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 08:26:40 --> Helper loaded: inflector_helper
INFO - 2017-09-08 08:26:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 08:26:40 --> Helper loaded: log_helper
INFO - 2017-09-08 08:26:40 --> Model Class Initialized
ERROR - 2017-09-08 08:26:40 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\wamp64\www\franknco\application\models\api_model.php 343
INFO - 2017-09-08 08:26:44 --> Config Class Initialized
INFO - 2017-09-08 08:26:44 --> Hooks Class Initialized
DEBUG - 2017-09-08 08:26:44 --> UTF-8 Support Enabled
INFO - 2017-09-08 08:26:44 --> Utf8 Class Initialized
INFO - 2017-09-08 08:26:44 --> URI Class Initialized
INFO - 2017-09-08 08:26:44 --> Router Class Initialized
INFO - 2017-09-08 08:26:44 --> Output Class Initialized
INFO - 2017-09-08 08:26:44 --> Security Class Initialized
DEBUG - 2017-09-08 08:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 08:26:44 --> Input Class Initialized
INFO - 2017-09-08 08:26:44 --> Language Class Initialized
INFO - 2017-09-08 08:26:44 --> Loader Class Initialized
INFO - 2017-09-08 08:26:44 --> Helper loaded: url_helper
INFO - 2017-09-08 08:26:44 --> Database Driver Class Initialized
INFO - 2017-09-08 08:26:44 --> Email Class Initialized
INFO - 2017-09-08 08:26:44 --> Controller Class Initialized
DEBUG - 2017-09-08 08:26:44 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 08:26:44 --> Helper loaded: inflector_helper
INFO - 2017-09-08 08:26:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 08:26:44 --> Helper loaded: log_helper
INFO - 2017-09-08 08:26:44 --> Model Class Initialized
ERROR - 2017-09-08 08:26:44 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\wamp64\www\franknco\application\models\api_model.php 343
INFO - 2017-09-08 08:26:46 --> Config Class Initialized
INFO - 2017-09-08 08:26:46 --> Hooks Class Initialized
DEBUG - 2017-09-08 08:26:46 --> UTF-8 Support Enabled
INFO - 2017-09-08 08:26:46 --> Utf8 Class Initialized
INFO - 2017-09-08 08:26:46 --> URI Class Initialized
INFO - 2017-09-08 08:26:46 --> Router Class Initialized
INFO - 2017-09-08 08:26:46 --> Output Class Initialized
INFO - 2017-09-08 08:26:46 --> Security Class Initialized
DEBUG - 2017-09-08 08:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 08:26:46 --> Input Class Initialized
INFO - 2017-09-08 08:26:46 --> Language Class Initialized
INFO - 2017-09-08 08:26:46 --> Loader Class Initialized
INFO - 2017-09-08 08:26:46 --> Helper loaded: url_helper
INFO - 2017-09-08 08:26:46 --> Database Driver Class Initialized
INFO - 2017-09-08 08:26:46 --> Email Class Initialized
INFO - 2017-09-08 08:26:46 --> Controller Class Initialized
DEBUG - 2017-09-08 08:26:46 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 08:26:46 --> Helper loaded: inflector_helper
INFO - 2017-09-08 08:26:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 08:26:46 --> Helper loaded: log_helper
INFO - 2017-09-08 08:26:46 --> Model Class Initialized
ERROR - 2017-09-08 08:26:46 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\wamp64\www\franknco\application\models\api_model.php 343
INFO - 2017-09-08 08:26:49 --> Config Class Initialized
INFO - 2017-09-08 08:26:49 --> Hooks Class Initialized
DEBUG - 2017-09-08 08:26:49 --> UTF-8 Support Enabled
INFO - 2017-09-08 08:26:49 --> Utf8 Class Initialized
INFO - 2017-09-08 08:26:49 --> URI Class Initialized
INFO - 2017-09-08 08:26:49 --> Router Class Initialized
INFO - 2017-09-08 08:26:49 --> Output Class Initialized
INFO - 2017-09-08 08:26:49 --> Security Class Initialized
DEBUG - 2017-09-08 08:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 08:26:49 --> Input Class Initialized
INFO - 2017-09-08 08:26:49 --> Language Class Initialized
INFO - 2017-09-08 08:26:49 --> Loader Class Initialized
INFO - 2017-09-08 08:26:49 --> Helper loaded: url_helper
INFO - 2017-09-08 08:26:49 --> Database Driver Class Initialized
INFO - 2017-09-08 08:26:49 --> Email Class Initialized
INFO - 2017-09-08 08:26:49 --> Controller Class Initialized
DEBUG - 2017-09-08 08:26:49 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 08:26:49 --> Helper loaded: inflector_helper
INFO - 2017-09-08 08:26:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 08:26:49 --> Helper loaded: log_helper
INFO - 2017-09-08 08:26:49 --> Model Class Initialized
ERROR - 2017-09-08 08:26:49 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\wamp64\www\franknco\application\models\api_model.php 343
INFO - 2017-09-08 08:26:53 --> Config Class Initialized
INFO - 2017-09-08 08:26:53 --> Hooks Class Initialized
DEBUG - 2017-09-08 08:26:53 --> UTF-8 Support Enabled
INFO - 2017-09-08 08:26:53 --> Utf8 Class Initialized
INFO - 2017-09-08 08:26:53 --> URI Class Initialized
INFO - 2017-09-08 08:26:53 --> Router Class Initialized
INFO - 2017-09-08 08:26:53 --> Output Class Initialized
INFO - 2017-09-08 08:26:53 --> Security Class Initialized
DEBUG - 2017-09-08 08:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 08:26:53 --> Input Class Initialized
INFO - 2017-09-08 08:26:53 --> Language Class Initialized
INFO - 2017-09-08 08:26:53 --> Loader Class Initialized
INFO - 2017-09-08 08:26:53 --> Helper loaded: url_helper
INFO - 2017-09-08 08:26:53 --> Database Driver Class Initialized
INFO - 2017-09-08 08:26:53 --> Email Class Initialized
INFO - 2017-09-08 08:26:53 --> Controller Class Initialized
DEBUG - 2017-09-08 08:26:53 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 08:26:53 --> Helper loaded: inflector_helper
INFO - 2017-09-08 08:26:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 08:26:53 --> Helper loaded: log_helper
INFO - 2017-09-08 08:26:53 --> Model Class Initialized
ERROR - 2017-09-08 08:26:53 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\wamp64\www\franknco\application\models\api_model.php 343
INFO - 2017-09-08 08:27:23 --> Config Class Initialized
INFO - 2017-09-08 08:27:23 --> Hooks Class Initialized
DEBUG - 2017-09-08 08:27:23 --> UTF-8 Support Enabled
INFO - 2017-09-08 08:27:23 --> Utf8 Class Initialized
INFO - 2017-09-08 08:27:23 --> URI Class Initialized
INFO - 2017-09-08 08:27:23 --> Router Class Initialized
INFO - 2017-09-08 08:27:23 --> Output Class Initialized
INFO - 2017-09-08 08:27:23 --> Security Class Initialized
DEBUG - 2017-09-08 08:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 08:27:23 --> Input Class Initialized
INFO - 2017-09-08 08:27:23 --> Language Class Initialized
INFO - 2017-09-08 08:27:23 --> Loader Class Initialized
INFO - 2017-09-08 08:27:23 --> Helper loaded: url_helper
INFO - 2017-09-08 08:27:23 --> Database Driver Class Initialized
INFO - 2017-09-08 08:27:23 --> Email Class Initialized
INFO - 2017-09-08 08:27:23 --> Controller Class Initialized
DEBUG - 2017-09-08 08:27:23 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 08:27:23 --> Helper loaded: inflector_helper
INFO - 2017-09-08 08:27:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 08:27:23 --> Helper loaded: log_helper
INFO - 2017-09-08 08:27:23 --> Model Class Initialized
ERROR - 2017-09-08 08:27:23 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\wamp64\www\franknco\application\models\api_model.php 343
INFO - 2017-09-08 08:27:27 --> Config Class Initialized
INFO - 2017-09-08 08:27:27 --> Hooks Class Initialized
DEBUG - 2017-09-08 08:27:27 --> UTF-8 Support Enabled
INFO - 2017-09-08 08:27:27 --> Utf8 Class Initialized
INFO - 2017-09-08 08:27:27 --> URI Class Initialized
INFO - 2017-09-08 08:27:27 --> Router Class Initialized
INFO - 2017-09-08 08:27:27 --> Output Class Initialized
INFO - 2017-09-08 08:27:27 --> Security Class Initialized
DEBUG - 2017-09-08 08:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 08:27:27 --> Input Class Initialized
INFO - 2017-09-08 08:27:27 --> Language Class Initialized
INFO - 2017-09-08 08:27:27 --> Loader Class Initialized
INFO - 2017-09-08 08:27:27 --> Helper loaded: url_helper
INFO - 2017-09-08 08:27:27 --> Database Driver Class Initialized
INFO - 2017-09-08 08:27:27 --> Email Class Initialized
INFO - 2017-09-08 08:27:27 --> Controller Class Initialized
DEBUG - 2017-09-08 08:27:27 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 08:27:27 --> Helper loaded: inflector_helper
INFO - 2017-09-08 08:27:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 08:27:27 --> Helper loaded: log_helper
INFO - 2017-09-08 08:27:27 --> Model Class Initialized
ERROR - 2017-09-08 08:27:27 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\wamp64\www\franknco\application\models\api_model.php 343
INFO - 2017-09-08 08:28:04 --> Config Class Initialized
INFO - 2017-09-08 08:28:04 --> Hooks Class Initialized
DEBUG - 2017-09-08 08:28:04 --> UTF-8 Support Enabled
INFO - 2017-09-08 08:28:04 --> Utf8 Class Initialized
INFO - 2017-09-08 08:28:04 --> URI Class Initialized
INFO - 2017-09-08 08:28:04 --> Router Class Initialized
INFO - 2017-09-08 08:28:04 --> Output Class Initialized
INFO - 2017-09-08 08:28:04 --> Security Class Initialized
DEBUG - 2017-09-08 08:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 08:28:04 --> Input Class Initialized
INFO - 2017-09-08 08:28:04 --> Language Class Initialized
INFO - 2017-09-08 08:28:04 --> Loader Class Initialized
INFO - 2017-09-08 08:28:04 --> Helper loaded: url_helper
INFO - 2017-09-08 08:28:04 --> Database Driver Class Initialized
INFO - 2017-09-08 08:28:04 --> Email Class Initialized
INFO - 2017-09-08 08:28:04 --> Controller Class Initialized
DEBUG - 2017-09-08 08:28:04 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 08:28:04 --> Helper loaded: inflector_helper
INFO - 2017-09-08 08:28:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 08:28:04 --> Helper loaded: log_helper
INFO - 2017-09-08 08:28:04 --> Model Class Initialized
ERROR - 2017-09-08 08:28:04 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\wamp64\www\franknco\application\models\api_model.php 343
INFO - 2017-09-08 08:28:06 --> Config Class Initialized
INFO - 2017-09-08 08:28:06 --> Hooks Class Initialized
DEBUG - 2017-09-08 08:28:06 --> UTF-8 Support Enabled
INFO - 2017-09-08 08:28:06 --> Utf8 Class Initialized
INFO - 2017-09-08 08:28:06 --> URI Class Initialized
INFO - 2017-09-08 08:28:06 --> Router Class Initialized
INFO - 2017-09-08 08:28:06 --> Output Class Initialized
INFO - 2017-09-08 08:28:06 --> Security Class Initialized
DEBUG - 2017-09-08 08:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 08:28:06 --> Input Class Initialized
INFO - 2017-09-08 08:28:06 --> Language Class Initialized
INFO - 2017-09-08 08:28:06 --> Loader Class Initialized
INFO - 2017-09-08 08:28:06 --> Helper loaded: url_helper
INFO - 2017-09-08 08:28:06 --> Database Driver Class Initialized
INFO - 2017-09-08 08:28:06 --> Email Class Initialized
INFO - 2017-09-08 08:28:06 --> Controller Class Initialized
DEBUG - 2017-09-08 08:28:06 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 08:28:06 --> Helper loaded: inflector_helper
INFO - 2017-09-08 08:28:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 08:28:06 --> Helper loaded: log_helper
INFO - 2017-09-08 08:28:06 --> Model Class Initialized
ERROR - 2017-09-08 08:28:06 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\wamp64\www\franknco\application\models\api_model.php 343
INFO - 2017-09-08 08:28:08 --> Config Class Initialized
INFO - 2017-09-08 08:28:08 --> Hooks Class Initialized
DEBUG - 2017-09-08 08:28:08 --> UTF-8 Support Enabled
INFO - 2017-09-08 08:28:08 --> Utf8 Class Initialized
INFO - 2017-09-08 08:28:08 --> URI Class Initialized
INFO - 2017-09-08 08:28:08 --> Router Class Initialized
INFO - 2017-09-08 08:28:08 --> Output Class Initialized
INFO - 2017-09-08 08:28:08 --> Security Class Initialized
DEBUG - 2017-09-08 08:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 08:28:08 --> Input Class Initialized
INFO - 2017-09-08 08:28:08 --> Language Class Initialized
INFO - 2017-09-08 08:28:08 --> Loader Class Initialized
INFO - 2017-09-08 08:28:08 --> Helper loaded: url_helper
INFO - 2017-09-08 08:28:08 --> Database Driver Class Initialized
INFO - 2017-09-08 08:28:08 --> Email Class Initialized
INFO - 2017-09-08 08:28:08 --> Controller Class Initialized
DEBUG - 2017-09-08 08:28:08 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 08:28:08 --> Helper loaded: inflector_helper
INFO - 2017-09-08 08:28:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 08:28:08 --> Helper loaded: log_helper
INFO - 2017-09-08 08:28:08 --> Model Class Initialized
ERROR - 2017-09-08 08:28:08 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\wamp64\www\franknco\application\models\api_model.php 343
INFO - 2017-09-08 08:28:10 --> Config Class Initialized
INFO - 2017-09-08 08:28:10 --> Hooks Class Initialized
DEBUG - 2017-09-08 08:28:10 --> UTF-8 Support Enabled
INFO - 2017-09-08 08:28:10 --> Utf8 Class Initialized
INFO - 2017-09-08 08:28:10 --> URI Class Initialized
INFO - 2017-09-08 08:28:10 --> Router Class Initialized
INFO - 2017-09-08 08:28:10 --> Output Class Initialized
INFO - 2017-09-08 08:28:10 --> Security Class Initialized
DEBUG - 2017-09-08 08:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 08:28:10 --> Input Class Initialized
INFO - 2017-09-08 08:28:10 --> Language Class Initialized
INFO - 2017-09-08 08:28:10 --> Loader Class Initialized
INFO - 2017-09-08 08:28:10 --> Helper loaded: url_helper
INFO - 2017-09-08 08:28:10 --> Database Driver Class Initialized
INFO - 2017-09-08 08:28:10 --> Email Class Initialized
INFO - 2017-09-08 08:28:10 --> Controller Class Initialized
DEBUG - 2017-09-08 08:28:10 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 08:28:10 --> Helper loaded: inflector_helper
INFO - 2017-09-08 08:28:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 08:28:10 --> Helper loaded: log_helper
INFO - 2017-09-08 08:28:10 --> Model Class Initialized
ERROR - 2017-09-08 08:28:10 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\wamp64\www\franknco\application\models\api_model.php 343
INFO - 2017-09-08 08:28:12 --> Config Class Initialized
INFO - 2017-09-08 08:28:12 --> Hooks Class Initialized
DEBUG - 2017-09-08 08:28:12 --> UTF-8 Support Enabled
INFO - 2017-09-08 08:28:12 --> Utf8 Class Initialized
INFO - 2017-09-08 08:28:12 --> URI Class Initialized
INFO - 2017-09-08 08:28:12 --> Router Class Initialized
INFO - 2017-09-08 08:28:12 --> Output Class Initialized
INFO - 2017-09-08 08:28:12 --> Security Class Initialized
DEBUG - 2017-09-08 08:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 08:28:12 --> Input Class Initialized
INFO - 2017-09-08 08:28:12 --> Language Class Initialized
INFO - 2017-09-08 08:28:12 --> Loader Class Initialized
INFO - 2017-09-08 08:28:12 --> Helper loaded: url_helper
INFO - 2017-09-08 08:28:12 --> Database Driver Class Initialized
INFO - 2017-09-08 08:28:12 --> Email Class Initialized
INFO - 2017-09-08 08:28:12 --> Controller Class Initialized
DEBUG - 2017-09-08 08:28:12 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 08:28:12 --> Helper loaded: inflector_helper
INFO - 2017-09-08 08:28:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 08:28:13 --> Helper loaded: log_helper
INFO - 2017-09-08 08:28:13 --> Model Class Initialized
ERROR - 2017-09-08 08:28:13 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\wamp64\www\franknco\application\models\api_model.php 343
INFO - 2017-09-08 08:29:32 --> Config Class Initialized
INFO - 2017-09-08 08:29:32 --> Hooks Class Initialized
DEBUG - 2017-09-08 08:29:32 --> UTF-8 Support Enabled
INFO - 2017-09-08 08:29:32 --> Utf8 Class Initialized
INFO - 2017-09-08 08:29:32 --> URI Class Initialized
INFO - 2017-09-08 08:29:32 --> Router Class Initialized
INFO - 2017-09-08 08:29:32 --> Output Class Initialized
INFO - 2017-09-08 08:29:32 --> Security Class Initialized
DEBUG - 2017-09-08 08:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 08:29:32 --> Input Class Initialized
INFO - 2017-09-08 08:29:32 --> Language Class Initialized
INFO - 2017-09-08 08:29:32 --> Loader Class Initialized
INFO - 2017-09-08 08:29:32 --> Helper loaded: url_helper
INFO - 2017-09-08 08:29:32 --> Database Driver Class Initialized
INFO - 2017-09-08 08:29:32 --> Email Class Initialized
INFO - 2017-09-08 08:29:32 --> Controller Class Initialized
DEBUG - 2017-09-08 08:29:32 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 08:29:32 --> Helper loaded: inflector_helper
INFO - 2017-09-08 08:29:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 08:29:32 --> Helper loaded: log_helper
INFO - 2017-09-08 08:29:32 --> Model Class Initialized
ERROR - 2017-09-08 08:29:32 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\wamp64\www\franknco\application\models\api_model.php 343
INFO - 2017-09-08 08:29:38 --> Config Class Initialized
INFO - 2017-09-08 08:29:38 --> Hooks Class Initialized
DEBUG - 2017-09-08 08:29:38 --> UTF-8 Support Enabled
INFO - 2017-09-08 08:29:38 --> Utf8 Class Initialized
INFO - 2017-09-08 08:29:38 --> URI Class Initialized
INFO - 2017-09-08 08:29:38 --> Router Class Initialized
INFO - 2017-09-08 08:29:38 --> Output Class Initialized
INFO - 2017-09-08 08:29:38 --> Security Class Initialized
DEBUG - 2017-09-08 08:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 08:29:38 --> Input Class Initialized
INFO - 2017-09-08 08:29:38 --> Language Class Initialized
INFO - 2017-09-08 08:29:38 --> Loader Class Initialized
INFO - 2017-09-08 08:29:38 --> Helper loaded: url_helper
INFO - 2017-09-08 08:29:38 --> Database Driver Class Initialized
INFO - 2017-09-08 08:29:38 --> Email Class Initialized
INFO - 2017-09-08 08:29:38 --> Controller Class Initialized
DEBUG - 2017-09-08 08:29:38 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 08:29:38 --> Helper loaded: inflector_helper
INFO - 2017-09-08 08:29:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 08:29:38 --> Helper loaded: log_helper
INFO - 2017-09-08 08:29:38 --> Model Class Initialized
ERROR - 2017-09-08 08:29:38 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\wamp64\www\franknco\application\models\api_model.php 343
INFO - 2017-09-08 08:30:46 --> Config Class Initialized
INFO - 2017-09-08 08:30:46 --> Hooks Class Initialized
DEBUG - 2017-09-08 08:30:46 --> UTF-8 Support Enabled
INFO - 2017-09-08 08:30:46 --> Utf8 Class Initialized
INFO - 2017-09-08 08:30:46 --> URI Class Initialized
INFO - 2017-09-08 08:30:46 --> Router Class Initialized
INFO - 2017-09-08 08:30:46 --> Output Class Initialized
INFO - 2017-09-08 08:30:46 --> Security Class Initialized
DEBUG - 2017-09-08 08:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 08:30:46 --> Input Class Initialized
INFO - 2017-09-08 08:30:46 --> Language Class Initialized
INFO - 2017-09-08 08:30:46 --> Loader Class Initialized
INFO - 2017-09-08 08:30:46 --> Helper loaded: url_helper
INFO - 2017-09-08 08:30:46 --> Database Driver Class Initialized
INFO - 2017-09-08 08:30:46 --> Email Class Initialized
INFO - 2017-09-08 08:30:46 --> Controller Class Initialized
DEBUG - 2017-09-08 08:30:46 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 08:30:46 --> Helper loaded: inflector_helper
INFO - 2017-09-08 08:30:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 08:30:46 --> Helper loaded: log_helper
INFO - 2017-09-08 08:30:46 --> Model Class Initialized
ERROR - 2017-09-08 08:30:46 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\wamp64\www\franknco\application\models\api_model.php 343
INFO - 2017-09-08 08:31:04 --> Config Class Initialized
INFO - 2017-09-08 08:31:04 --> Hooks Class Initialized
DEBUG - 2017-09-08 08:31:04 --> UTF-8 Support Enabled
INFO - 2017-09-08 08:31:04 --> Utf8 Class Initialized
INFO - 2017-09-08 08:31:04 --> URI Class Initialized
INFO - 2017-09-08 08:31:04 --> Router Class Initialized
INFO - 2017-09-08 08:31:04 --> Output Class Initialized
INFO - 2017-09-08 08:31:04 --> Security Class Initialized
DEBUG - 2017-09-08 08:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 08:31:04 --> Input Class Initialized
INFO - 2017-09-08 08:31:04 --> Language Class Initialized
INFO - 2017-09-08 08:31:04 --> Loader Class Initialized
INFO - 2017-09-08 08:31:04 --> Helper loaded: url_helper
INFO - 2017-09-08 08:31:04 --> Database Driver Class Initialized
INFO - 2017-09-08 08:31:04 --> Email Class Initialized
INFO - 2017-09-08 08:31:04 --> Controller Class Initialized
DEBUG - 2017-09-08 08:31:04 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 08:31:04 --> Helper loaded: inflector_helper
INFO - 2017-09-08 08:31:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 08:31:04 --> Helper loaded: log_helper
INFO - 2017-09-08 08:31:04 --> Model Class Initialized
INFO - 2017-09-08 15:31:04 --> Final output sent to browser
DEBUG - 2017-09-08 15:31:04 --> Total execution time: 0.0851
INFO - 2017-09-08 08:31:15 --> Config Class Initialized
INFO - 2017-09-08 08:31:15 --> Hooks Class Initialized
DEBUG - 2017-09-08 08:31:15 --> UTF-8 Support Enabled
INFO - 2017-09-08 08:31:15 --> Utf8 Class Initialized
INFO - 2017-09-08 08:31:15 --> URI Class Initialized
INFO - 2017-09-08 08:31:15 --> Router Class Initialized
INFO - 2017-09-08 08:31:15 --> Output Class Initialized
INFO - 2017-09-08 08:31:15 --> Security Class Initialized
DEBUG - 2017-09-08 08:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 08:31:15 --> Input Class Initialized
INFO - 2017-09-08 08:31:15 --> Language Class Initialized
INFO - 2017-09-08 08:31:15 --> Loader Class Initialized
INFO - 2017-09-08 08:31:15 --> Helper loaded: url_helper
INFO - 2017-09-08 08:31:15 --> Database Driver Class Initialized
INFO - 2017-09-08 08:31:15 --> Email Class Initialized
INFO - 2017-09-08 08:31:15 --> Controller Class Initialized
DEBUG - 2017-09-08 08:31:15 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 08:31:15 --> Helper loaded: inflector_helper
INFO - 2017-09-08 08:31:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 08:31:15 --> Helper loaded: log_helper
INFO - 2017-09-08 08:31:15 --> Model Class Initialized
INFO - 2017-09-08 15:31:15 --> Final output sent to browser
DEBUG - 2017-09-08 15:31:15 --> Total execution time: 0.1024
INFO - 2017-09-08 08:31:33 --> Config Class Initialized
INFO - 2017-09-08 08:31:33 --> Hooks Class Initialized
DEBUG - 2017-09-08 08:31:33 --> UTF-8 Support Enabled
INFO - 2017-09-08 08:31:33 --> Utf8 Class Initialized
INFO - 2017-09-08 08:31:33 --> URI Class Initialized
INFO - 2017-09-08 08:31:33 --> Router Class Initialized
INFO - 2017-09-08 08:31:33 --> Output Class Initialized
INFO - 2017-09-08 08:31:33 --> Security Class Initialized
DEBUG - 2017-09-08 08:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 08:31:33 --> Input Class Initialized
INFO - 2017-09-08 08:31:33 --> Language Class Initialized
INFO - 2017-09-08 08:31:33 --> Loader Class Initialized
INFO - 2017-09-08 08:31:33 --> Helper loaded: url_helper
INFO - 2017-09-08 08:31:33 --> Database Driver Class Initialized
INFO - 2017-09-08 08:31:33 --> Email Class Initialized
INFO - 2017-09-08 08:31:33 --> Controller Class Initialized
DEBUG - 2017-09-08 08:31:33 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 08:31:33 --> Helper loaded: inflector_helper
INFO - 2017-09-08 08:31:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 08:31:33 --> Helper loaded: log_helper
INFO - 2017-09-08 08:31:33 --> Model Class Initialized
INFO - 2017-09-08 15:31:33 --> Final output sent to browser
DEBUG - 2017-09-08 15:31:33 --> Total execution time: 0.0634
INFO - 2017-09-08 08:31:33 --> Config Class Initialized
INFO - 2017-09-08 08:31:33 --> Hooks Class Initialized
DEBUG - 2017-09-08 08:31:33 --> UTF-8 Support Enabled
INFO - 2017-09-08 08:31:33 --> Utf8 Class Initialized
INFO - 2017-09-08 08:31:33 --> URI Class Initialized
INFO - 2017-09-08 08:31:33 --> Router Class Initialized
INFO - 2017-09-08 08:31:33 --> Output Class Initialized
INFO - 2017-09-08 08:31:33 --> Security Class Initialized
DEBUG - 2017-09-08 08:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 08:31:33 --> Input Class Initialized
INFO - 2017-09-08 08:31:33 --> Language Class Initialized
INFO - 2017-09-08 08:31:33 --> Loader Class Initialized
INFO - 2017-09-08 08:31:33 --> Helper loaded: url_helper
INFO - 2017-09-08 08:31:33 --> Database Driver Class Initialized
INFO - 2017-09-08 08:31:33 --> Email Class Initialized
INFO - 2017-09-08 08:31:33 --> Controller Class Initialized
DEBUG - 2017-09-08 08:31:33 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 08:31:33 --> Helper loaded: inflector_helper
INFO - 2017-09-08 08:31:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 08:31:33 --> Helper loaded: log_helper
INFO - 2017-09-08 08:31:33 --> Model Class Initialized
INFO - 2017-09-08 15:31:33 --> Final output sent to browser
DEBUG - 2017-09-08 15:31:33 --> Total execution time: 0.1055
INFO - 2017-09-08 08:31:36 --> Config Class Initialized
INFO - 2017-09-08 08:31:36 --> Hooks Class Initialized
DEBUG - 2017-09-08 08:31:36 --> UTF-8 Support Enabled
INFO - 2017-09-08 08:31:36 --> Utf8 Class Initialized
INFO - 2017-09-08 08:31:36 --> URI Class Initialized
INFO - 2017-09-08 08:31:36 --> Router Class Initialized
INFO - 2017-09-08 08:31:36 --> Output Class Initialized
INFO - 2017-09-08 08:31:36 --> Security Class Initialized
DEBUG - 2017-09-08 08:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-08 08:31:36 --> Input Class Initialized
INFO - 2017-09-08 08:31:36 --> Language Class Initialized
INFO - 2017-09-08 08:31:36 --> Loader Class Initialized
INFO - 2017-09-08 08:31:36 --> Helper loaded: url_helper
INFO - 2017-09-08 08:31:37 --> Database Driver Class Initialized
INFO - 2017-09-08 08:31:37 --> Email Class Initialized
INFO - 2017-09-08 08:31:37 --> Controller Class Initialized
DEBUG - 2017-09-08 08:31:37 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-08 08:31:37 --> Helper loaded: inflector_helper
INFO - 2017-09-08 08:31:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-08 08:31:37 --> Helper loaded: log_helper
INFO - 2017-09-08 08:31:37 --> Model Class Initialized
INFO - 2017-09-08 15:31:37 --> Final output sent to browser
DEBUG - 2017-09-08 15:31:37 --> Total execution time: 0.0562
