<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-09-07 06:21:49 --> Config Class Initialized
INFO - 2017-09-07 06:21:49 --> Hooks Class Initialized
DEBUG - 2017-09-07 06:21:49 --> UTF-8 Support Enabled
INFO - 2017-09-07 06:21:49 --> Utf8 Class Initialized
INFO - 2017-09-07 06:21:49 --> URI Class Initialized
INFO - 2017-09-07 06:21:49 --> Router Class Initialized
INFO - 2017-09-07 06:21:49 --> Output Class Initialized
INFO - 2017-09-07 06:21:49 --> Security Class Initialized
DEBUG - 2017-09-07 06:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 06:21:49 --> Input Class Initialized
INFO - 2017-09-07 06:21:49 --> Language Class Initialized
INFO - 2017-09-07 06:21:49 --> Loader Class Initialized
INFO - 2017-09-07 06:21:50 --> Helper loaded: url_helper
INFO - 2017-09-07 06:21:50 --> Database Driver Class Initialized
INFO - 2017-09-07 06:21:50 --> Email Class Initialized
INFO - 2017-09-07 06:21:50 --> Controller Class Initialized
DEBUG - 2017-09-07 06:21:50 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 06:21:50 --> Helper loaded: inflector_helper
INFO - 2017-09-07 06:21:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 06:21:50 --> Helper loaded: log_helper
INFO - 2017-09-07 06:21:50 --> Model Class Initialized
INFO - 2017-09-07 13:21:50 --> Final output sent to browser
DEBUG - 2017-09-07 13:21:50 --> Total execution time: 0.4600
INFO - 2017-09-07 06:22:11 --> Config Class Initialized
INFO - 2017-09-07 06:22:11 --> Hooks Class Initialized
DEBUG - 2017-09-07 06:22:11 --> UTF-8 Support Enabled
INFO - 2017-09-07 06:22:11 --> Utf8 Class Initialized
INFO - 2017-09-07 06:22:11 --> URI Class Initialized
INFO - 2017-09-07 06:22:11 --> Router Class Initialized
INFO - 2017-09-07 06:22:11 --> Output Class Initialized
INFO - 2017-09-07 06:22:11 --> Security Class Initialized
DEBUG - 2017-09-07 06:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 06:22:11 --> Input Class Initialized
INFO - 2017-09-07 06:22:11 --> Language Class Initialized
INFO - 2017-09-07 06:22:11 --> Loader Class Initialized
INFO - 2017-09-07 06:22:11 --> Helper loaded: url_helper
INFO - 2017-09-07 06:22:11 --> Database Driver Class Initialized
INFO - 2017-09-07 06:22:11 --> Email Class Initialized
INFO - 2017-09-07 06:22:11 --> Controller Class Initialized
DEBUG - 2017-09-07 06:22:11 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 06:22:11 --> Helper loaded: inflector_helper
INFO - 2017-09-07 06:22:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 06:22:11 --> Helper loaded: log_helper
INFO - 2017-09-07 06:22:11 --> Model Class Initialized
INFO - 2017-09-07 13:22:11 --> Final output sent to browser
DEBUG - 2017-09-07 13:22:11 --> Total execution time: 0.2536
INFO - 2017-09-07 06:22:13 --> Config Class Initialized
INFO - 2017-09-07 06:22:13 --> Hooks Class Initialized
DEBUG - 2017-09-07 06:22:13 --> UTF-8 Support Enabled
INFO - 2017-09-07 06:22:13 --> Utf8 Class Initialized
INFO - 2017-09-07 06:22:13 --> URI Class Initialized
INFO - 2017-09-07 06:22:13 --> Router Class Initialized
INFO - 2017-09-07 06:22:13 --> Output Class Initialized
INFO - 2017-09-07 06:22:13 --> Security Class Initialized
DEBUG - 2017-09-07 06:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 06:22:13 --> Input Class Initialized
INFO - 2017-09-07 06:22:13 --> Language Class Initialized
INFO - 2017-09-07 06:22:13 --> Loader Class Initialized
INFO - 2017-09-07 06:22:13 --> Helper loaded: url_helper
INFO - 2017-09-07 06:22:13 --> Database Driver Class Initialized
INFO - 2017-09-07 06:22:13 --> Email Class Initialized
INFO - 2017-09-07 06:22:13 --> Controller Class Initialized
DEBUG - 2017-09-07 06:22:13 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 06:22:13 --> Helper loaded: inflector_helper
INFO - 2017-09-07 06:22:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 06:22:13 --> Helper loaded: log_helper
INFO - 2017-09-07 06:22:13 --> Model Class Initialized
INFO - 2017-09-07 13:22:14 --> Final output sent to browser
DEBUG - 2017-09-07 13:22:14 --> Total execution time: 0.0755
INFO - 2017-09-07 06:22:16 --> Config Class Initialized
INFO - 2017-09-07 06:22:16 --> Hooks Class Initialized
DEBUG - 2017-09-07 06:22:16 --> UTF-8 Support Enabled
INFO - 2017-09-07 06:22:16 --> Utf8 Class Initialized
INFO - 2017-09-07 06:22:16 --> URI Class Initialized
INFO - 2017-09-07 06:22:16 --> Router Class Initialized
INFO - 2017-09-07 06:22:16 --> Output Class Initialized
INFO - 2017-09-07 06:22:16 --> Security Class Initialized
DEBUG - 2017-09-07 06:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 06:22:16 --> Input Class Initialized
INFO - 2017-09-07 06:22:16 --> Language Class Initialized
INFO - 2017-09-07 06:22:16 --> Loader Class Initialized
INFO - 2017-09-07 06:22:16 --> Helper loaded: url_helper
INFO - 2017-09-07 06:22:16 --> Database Driver Class Initialized
INFO - 2017-09-07 06:22:16 --> Email Class Initialized
INFO - 2017-09-07 06:22:16 --> Controller Class Initialized
DEBUG - 2017-09-07 06:22:16 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 06:22:16 --> Helper loaded: inflector_helper
INFO - 2017-09-07 06:22:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 06:22:16 --> Helper loaded: log_helper
INFO - 2017-09-07 06:22:16 --> Model Class Initialized
INFO - 2017-09-07 13:22:16 --> Final output sent to browser
DEBUG - 2017-09-07 13:22:16 --> Total execution time: 0.0835
INFO - 2017-09-07 06:38:09 --> Config Class Initialized
INFO - 2017-09-07 06:38:09 --> Hooks Class Initialized
DEBUG - 2017-09-07 06:38:09 --> UTF-8 Support Enabled
INFO - 2017-09-07 06:38:09 --> Utf8 Class Initialized
INFO - 2017-09-07 06:38:09 --> URI Class Initialized
INFO - 2017-09-07 06:38:09 --> Router Class Initialized
INFO - 2017-09-07 06:38:09 --> Output Class Initialized
INFO - 2017-09-07 06:38:09 --> Security Class Initialized
DEBUG - 2017-09-07 06:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 06:38:09 --> Input Class Initialized
INFO - 2017-09-07 06:38:09 --> Language Class Initialized
INFO - 2017-09-07 06:38:09 --> Loader Class Initialized
INFO - 2017-09-07 06:38:09 --> Helper loaded: url_helper
INFO - 2017-09-07 06:38:09 --> Database Driver Class Initialized
INFO - 2017-09-07 06:38:09 --> Email Class Initialized
INFO - 2017-09-07 06:38:09 --> Controller Class Initialized
DEBUG - 2017-09-07 06:38:09 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 06:38:09 --> Helper loaded: inflector_helper
INFO - 2017-09-07 06:38:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 06:38:09 --> Helper loaded: log_helper
INFO - 2017-09-07 06:38:09 --> Model Class Initialized
ERROR - 2017-09-07 06:38:09 --> Severity: Parsing Error --> syntax error, unexpected ')', expecting variable (T_VARIABLE) C:\wamp64\www\franknco\application\models\api_model.php 731
INFO - 2017-09-07 06:38:38 --> Config Class Initialized
INFO - 2017-09-07 06:38:38 --> Hooks Class Initialized
DEBUG - 2017-09-07 06:38:38 --> UTF-8 Support Enabled
INFO - 2017-09-07 06:38:38 --> Utf8 Class Initialized
INFO - 2017-09-07 06:38:38 --> URI Class Initialized
INFO - 2017-09-07 06:38:38 --> Router Class Initialized
INFO - 2017-09-07 06:38:38 --> Output Class Initialized
INFO - 2017-09-07 06:38:38 --> Security Class Initialized
DEBUG - 2017-09-07 06:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 06:38:38 --> Input Class Initialized
INFO - 2017-09-07 06:38:38 --> Language Class Initialized
INFO - 2017-09-07 06:38:38 --> Loader Class Initialized
INFO - 2017-09-07 06:38:38 --> Helper loaded: url_helper
INFO - 2017-09-07 06:38:38 --> Database Driver Class Initialized
INFO - 2017-09-07 06:38:38 --> Email Class Initialized
INFO - 2017-09-07 06:38:38 --> Controller Class Initialized
DEBUG - 2017-09-07 06:38:38 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 06:38:38 --> Helper loaded: inflector_helper
INFO - 2017-09-07 06:38:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 06:38:38 --> Helper loaded: log_helper
INFO - 2017-09-07 06:38:38 --> Model Class Initialized
INFO - 2017-09-07 13:38:38 --> Final output sent to browser
DEBUG - 2017-09-07 13:38:38 --> Total execution time: 0.0613
INFO - 2017-09-07 06:38:43 --> Config Class Initialized
INFO - 2017-09-07 06:38:43 --> Hooks Class Initialized
DEBUG - 2017-09-07 06:38:43 --> UTF-8 Support Enabled
INFO - 2017-09-07 06:38:43 --> Utf8 Class Initialized
INFO - 2017-09-07 06:38:43 --> URI Class Initialized
INFO - 2017-09-07 06:38:43 --> Router Class Initialized
INFO - 2017-09-07 06:38:43 --> Output Class Initialized
INFO - 2017-09-07 06:38:43 --> Security Class Initialized
DEBUG - 2017-09-07 06:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 06:38:43 --> Input Class Initialized
INFO - 2017-09-07 06:38:43 --> Language Class Initialized
INFO - 2017-09-07 06:38:43 --> Loader Class Initialized
INFO - 2017-09-07 06:38:43 --> Helper loaded: url_helper
INFO - 2017-09-07 06:38:43 --> Database Driver Class Initialized
INFO - 2017-09-07 06:38:43 --> Email Class Initialized
INFO - 2017-09-07 06:38:43 --> Controller Class Initialized
DEBUG - 2017-09-07 06:38:43 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 06:38:43 --> Helper loaded: inflector_helper
INFO - 2017-09-07 06:38:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 06:38:43 --> Helper loaded: log_helper
INFO - 2017-09-07 06:38:43 --> Model Class Initialized
INFO - 2017-09-07 13:38:43 --> Final output sent to browser
DEBUG - 2017-09-07 13:38:43 --> Total execution time: 0.0588
INFO - 2017-09-07 06:39:56 --> Config Class Initialized
INFO - 2017-09-07 06:39:56 --> Hooks Class Initialized
DEBUG - 2017-09-07 06:39:56 --> UTF-8 Support Enabled
INFO - 2017-09-07 06:39:56 --> Utf8 Class Initialized
INFO - 2017-09-07 06:39:56 --> URI Class Initialized
INFO - 2017-09-07 06:39:56 --> Router Class Initialized
INFO - 2017-09-07 06:39:56 --> Output Class Initialized
INFO - 2017-09-07 06:39:56 --> Security Class Initialized
DEBUG - 2017-09-07 06:39:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 06:39:56 --> Input Class Initialized
INFO - 2017-09-07 06:39:56 --> Language Class Initialized
INFO - 2017-09-07 06:39:56 --> Loader Class Initialized
INFO - 2017-09-07 06:39:56 --> Helper loaded: url_helper
INFO - 2017-09-07 06:39:56 --> Database Driver Class Initialized
INFO - 2017-09-07 06:39:56 --> Email Class Initialized
INFO - 2017-09-07 06:39:56 --> Controller Class Initialized
DEBUG - 2017-09-07 06:39:56 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 06:39:56 --> Helper loaded: inflector_helper
INFO - 2017-09-07 06:39:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 06:39:56 --> Helper loaded: log_helper
INFO - 2017-09-07 06:39:56 --> Model Class Initialized
INFO - 2017-09-07 13:39:56 --> Final output sent to browser
DEBUG - 2017-09-07 13:39:56 --> Total execution time: 0.0584
INFO - 2017-09-07 06:46:58 --> Config Class Initialized
INFO - 2017-09-07 06:46:58 --> Hooks Class Initialized
DEBUG - 2017-09-07 06:46:58 --> UTF-8 Support Enabled
INFO - 2017-09-07 06:46:58 --> Utf8 Class Initialized
INFO - 2017-09-07 06:46:58 --> URI Class Initialized
INFO - 2017-09-07 06:46:58 --> Router Class Initialized
INFO - 2017-09-07 06:46:58 --> Output Class Initialized
INFO - 2017-09-07 06:46:58 --> Security Class Initialized
DEBUG - 2017-09-07 06:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 06:46:58 --> Input Class Initialized
INFO - 2017-09-07 06:46:58 --> Language Class Initialized
INFO - 2017-09-07 06:46:58 --> Loader Class Initialized
INFO - 2017-09-07 06:46:58 --> Helper loaded: url_helper
INFO - 2017-09-07 06:46:58 --> Database Driver Class Initialized
INFO - 2017-09-07 06:46:58 --> Email Class Initialized
INFO - 2017-09-07 06:46:58 --> Controller Class Initialized
DEBUG - 2017-09-07 06:46:58 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 06:46:58 --> Helper loaded: inflector_helper
INFO - 2017-09-07 06:46:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 06:46:58 --> Helper loaded: log_helper
INFO - 2017-09-07 06:46:58 --> Model Class Initialized
INFO - 2017-09-07 13:46:58 --> Final output sent to browser
DEBUG - 2017-09-07 13:46:58 --> Total execution time: 0.0761
INFO - 2017-09-07 06:47:14 --> Config Class Initialized
INFO - 2017-09-07 06:47:14 --> Hooks Class Initialized
DEBUG - 2017-09-07 06:47:14 --> UTF-8 Support Enabled
INFO - 2017-09-07 06:47:14 --> Utf8 Class Initialized
INFO - 2017-09-07 06:47:14 --> URI Class Initialized
INFO - 2017-09-07 06:47:14 --> Router Class Initialized
INFO - 2017-09-07 06:47:14 --> Output Class Initialized
INFO - 2017-09-07 06:47:14 --> Security Class Initialized
DEBUG - 2017-09-07 06:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 06:47:14 --> Input Class Initialized
INFO - 2017-09-07 06:47:14 --> Language Class Initialized
INFO - 2017-09-07 06:47:14 --> Loader Class Initialized
INFO - 2017-09-07 06:47:14 --> Helper loaded: url_helper
INFO - 2017-09-07 06:47:14 --> Database Driver Class Initialized
INFO - 2017-09-07 06:47:14 --> Email Class Initialized
INFO - 2017-09-07 06:47:14 --> Controller Class Initialized
DEBUG - 2017-09-07 06:47:14 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 06:47:14 --> Helper loaded: inflector_helper
INFO - 2017-09-07 06:47:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 06:47:14 --> Helper loaded: log_helper
INFO - 2017-09-07 06:47:14 --> Model Class Initialized
INFO - 2017-09-07 13:47:14 --> Final output sent to browser
DEBUG - 2017-09-07 13:47:14 --> Total execution time: 0.0854
INFO - 2017-09-07 06:47:17 --> Config Class Initialized
INFO - 2017-09-07 06:47:17 --> Hooks Class Initialized
DEBUG - 2017-09-07 06:47:17 --> UTF-8 Support Enabled
INFO - 2017-09-07 06:47:17 --> Utf8 Class Initialized
INFO - 2017-09-07 06:47:17 --> URI Class Initialized
INFO - 2017-09-07 06:47:17 --> Router Class Initialized
INFO - 2017-09-07 06:47:17 --> Output Class Initialized
INFO - 2017-09-07 06:47:17 --> Security Class Initialized
DEBUG - 2017-09-07 06:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 06:47:17 --> Input Class Initialized
INFO - 2017-09-07 06:47:17 --> Language Class Initialized
INFO - 2017-09-07 06:47:17 --> Loader Class Initialized
INFO - 2017-09-07 06:47:17 --> Helper loaded: url_helper
INFO - 2017-09-07 06:47:17 --> Database Driver Class Initialized
INFO - 2017-09-07 06:47:17 --> Email Class Initialized
INFO - 2017-09-07 06:47:17 --> Controller Class Initialized
DEBUG - 2017-09-07 06:47:17 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 06:47:17 --> Helper loaded: inflector_helper
INFO - 2017-09-07 06:47:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 06:47:17 --> Helper loaded: log_helper
INFO - 2017-09-07 06:47:17 --> Model Class Initialized
INFO - 2017-09-07 13:47:17 --> Final output sent to browser
DEBUG - 2017-09-07 13:47:17 --> Total execution time: 0.0715
INFO - 2017-09-07 06:47:21 --> Config Class Initialized
INFO - 2017-09-07 06:47:21 --> Hooks Class Initialized
DEBUG - 2017-09-07 06:47:21 --> UTF-8 Support Enabled
INFO - 2017-09-07 06:47:21 --> Utf8 Class Initialized
INFO - 2017-09-07 06:47:21 --> URI Class Initialized
INFO - 2017-09-07 06:47:21 --> Router Class Initialized
INFO - 2017-09-07 06:47:21 --> Output Class Initialized
INFO - 2017-09-07 06:47:21 --> Security Class Initialized
DEBUG - 2017-09-07 06:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 06:47:21 --> Input Class Initialized
INFO - 2017-09-07 06:47:21 --> Language Class Initialized
INFO - 2017-09-07 06:47:21 --> Loader Class Initialized
INFO - 2017-09-07 06:47:21 --> Helper loaded: url_helper
INFO - 2017-09-07 06:47:21 --> Database Driver Class Initialized
INFO - 2017-09-07 06:47:21 --> Email Class Initialized
INFO - 2017-09-07 06:47:21 --> Controller Class Initialized
DEBUG - 2017-09-07 06:47:21 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 06:47:21 --> Helper loaded: inflector_helper
INFO - 2017-09-07 06:47:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 06:47:21 --> Helper loaded: log_helper
INFO - 2017-09-07 06:47:21 --> Model Class Initialized
INFO - 2017-09-07 13:47:21 --> Final output sent to browser
DEBUG - 2017-09-07 13:47:21 --> Total execution time: 0.0911
INFO - 2017-09-07 06:47:23 --> Config Class Initialized
INFO - 2017-09-07 06:47:23 --> Hooks Class Initialized
DEBUG - 2017-09-07 06:47:23 --> UTF-8 Support Enabled
INFO - 2017-09-07 06:47:23 --> Utf8 Class Initialized
INFO - 2017-09-07 06:47:23 --> URI Class Initialized
INFO - 2017-09-07 06:47:23 --> Router Class Initialized
INFO - 2017-09-07 06:47:23 --> Output Class Initialized
INFO - 2017-09-07 06:47:23 --> Security Class Initialized
DEBUG - 2017-09-07 06:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 06:47:23 --> Input Class Initialized
INFO - 2017-09-07 06:47:23 --> Language Class Initialized
INFO - 2017-09-07 06:47:23 --> Loader Class Initialized
INFO - 2017-09-07 06:47:23 --> Helper loaded: url_helper
INFO - 2017-09-07 06:47:23 --> Database Driver Class Initialized
INFO - 2017-09-07 06:47:23 --> Email Class Initialized
INFO - 2017-09-07 06:47:23 --> Controller Class Initialized
DEBUG - 2017-09-07 06:47:23 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 06:47:23 --> Helper loaded: inflector_helper
INFO - 2017-09-07 06:47:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 06:47:23 --> Helper loaded: log_helper
INFO - 2017-09-07 06:47:23 --> Model Class Initialized
ERROR - 2017-09-07 13:47:23 --> Severity: Notice --> Undefined offset: 1 C:\wamp64\www\franknco\application\controllers\api\franknco_api.php 111
ERROR - 2017-09-07 13:47:23 --> Severity: Warning --> mdecrypt_generic(): An empty string was passed C:\wamp64\www\franknco\application\models\api_model.php 726
INFO - 2017-09-07 13:47:24 --> Final output sent to browser
DEBUG - 2017-09-07 13:47:24 --> Total execution time: 0.0724
INFO - 2017-09-07 06:48:15 --> Config Class Initialized
INFO - 2017-09-07 06:48:15 --> Hooks Class Initialized
DEBUG - 2017-09-07 06:48:15 --> UTF-8 Support Enabled
INFO - 2017-09-07 06:48:15 --> Utf8 Class Initialized
INFO - 2017-09-07 06:48:15 --> URI Class Initialized
INFO - 2017-09-07 06:48:15 --> Router Class Initialized
INFO - 2017-09-07 06:48:15 --> Output Class Initialized
INFO - 2017-09-07 06:48:15 --> Security Class Initialized
DEBUG - 2017-09-07 06:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 06:48:15 --> Input Class Initialized
INFO - 2017-09-07 06:48:15 --> Language Class Initialized
INFO - 2017-09-07 06:48:15 --> Loader Class Initialized
INFO - 2017-09-07 06:48:15 --> Helper loaded: url_helper
INFO - 2017-09-07 06:48:15 --> Database Driver Class Initialized
INFO - 2017-09-07 06:48:15 --> Email Class Initialized
INFO - 2017-09-07 06:48:15 --> Controller Class Initialized
DEBUG - 2017-09-07 06:48:15 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 06:48:15 --> Helper loaded: inflector_helper
INFO - 2017-09-07 06:48:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 06:48:15 --> Helper loaded: log_helper
INFO - 2017-09-07 06:48:15 --> Model Class Initialized
INFO - 2017-09-07 13:48:15 --> Final output sent to browser
DEBUG - 2017-09-07 13:48:15 --> Total execution time: 0.2089
INFO - 2017-09-07 06:48:42 --> Config Class Initialized
INFO - 2017-09-07 06:48:42 --> Hooks Class Initialized
DEBUG - 2017-09-07 06:48:42 --> UTF-8 Support Enabled
INFO - 2017-09-07 06:48:42 --> Utf8 Class Initialized
INFO - 2017-09-07 06:48:42 --> URI Class Initialized
INFO - 2017-09-07 06:48:42 --> Router Class Initialized
INFO - 2017-09-07 06:48:42 --> Output Class Initialized
INFO - 2017-09-07 06:48:42 --> Security Class Initialized
DEBUG - 2017-09-07 06:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 06:48:42 --> Input Class Initialized
INFO - 2017-09-07 06:48:42 --> Language Class Initialized
INFO - 2017-09-07 06:48:42 --> Loader Class Initialized
INFO - 2017-09-07 06:48:42 --> Helper loaded: url_helper
INFO - 2017-09-07 06:48:42 --> Database Driver Class Initialized
INFO - 2017-09-07 06:48:42 --> Email Class Initialized
INFO - 2017-09-07 06:48:42 --> Controller Class Initialized
DEBUG - 2017-09-07 06:48:42 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 06:48:42 --> Helper loaded: inflector_helper
INFO - 2017-09-07 06:48:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 06:48:42 --> Helper loaded: log_helper
INFO - 2017-09-07 06:48:42 --> Model Class Initialized
INFO - 2017-09-07 13:48:42 --> Final output sent to browser
DEBUG - 2017-09-07 13:48:42 --> Total execution time: 0.0994
INFO - 2017-09-07 06:49:51 --> Config Class Initialized
INFO - 2017-09-07 06:49:51 --> Hooks Class Initialized
DEBUG - 2017-09-07 06:49:51 --> UTF-8 Support Enabled
INFO - 2017-09-07 06:49:51 --> Utf8 Class Initialized
INFO - 2017-09-07 06:49:51 --> URI Class Initialized
INFO - 2017-09-07 06:49:51 --> Router Class Initialized
INFO - 2017-09-07 06:49:51 --> Output Class Initialized
INFO - 2017-09-07 06:49:51 --> Security Class Initialized
DEBUG - 2017-09-07 06:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 06:49:51 --> Input Class Initialized
INFO - 2017-09-07 06:49:51 --> Language Class Initialized
INFO - 2017-09-07 06:49:51 --> Loader Class Initialized
INFO - 2017-09-07 06:49:51 --> Helper loaded: url_helper
INFO - 2017-09-07 06:49:51 --> Database Driver Class Initialized
INFO - 2017-09-07 06:49:51 --> Email Class Initialized
INFO - 2017-09-07 06:49:51 --> Controller Class Initialized
DEBUG - 2017-09-07 06:49:51 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 06:49:51 --> Helper loaded: inflector_helper
INFO - 2017-09-07 06:49:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 06:49:51 --> Helper loaded: log_helper
INFO - 2017-09-07 06:49:51 --> Model Class Initialized
INFO - 2017-09-07 13:49:51 --> Final output sent to browser
DEBUG - 2017-09-07 13:49:51 --> Total execution time: 0.0893
INFO - 2017-09-07 06:49:56 --> Config Class Initialized
INFO - 2017-09-07 06:49:56 --> Hooks Class Initialized
DEBUG - 2017-09-07 06:49:56 --> UTF-8 Support Enabled
INFO - 2017-09-07 06:49:56 --> Utf8 Class Initialized
INFO - 2017-09-07 06:49:56 --> URI Class Initialized
INFO - 2017-09-07 06:49:56 --> Router Class Initialized
INFO - 2017-09-07 06:49:56 --> Output Class Initialized
INFO - 2017-09-07 06:49:56 --> Security Class Initialized
DEBUG - 2017-09-07 06:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 06:49:56 --> Input Class Initialized
INFO - 2017-09-07 06:49:56 --> Language Class Initialized
INFO - 2017-09-07 06:49:56 --> Loader Class Initialized
INFO - 2017-09-07 06:49:56 --> Helper loaded: url_helper
INFO - 2017-09-07 06:49:56 --> Database Driver Class Initialized
INFO - 2017-09-07 06:49:56 --> Email Class Initialized
INFO - 2017-09-07 06:49:56 --> Controller Class Initialized
DEBUG - 2017-09-07 06:49:56 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 06:49:56 --> Helper loaded: inflector_helper
INFO - 2017-09-07 06:49:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 06:49:56 --> Helper loaded: log_helper
INFO - 2017-09-07 06:49:56 --> Model Class Initialized
INFO - 2017-09-07 13:49:56 --> Final output sent to browser
DEBUG - 2017-09-07 13:49:56 --> Total execution time: 0.0953
INFO - 2017-09-07 06:50:09 --> Config Class Initialized
INFO - 2017-09-07 06:50:09 --> Hooks Class Initialized
DEBUG - 2017-09-07 06:50:09 --> UTF-8 Support Enabled
INFO - 2017-09-07 06:50:09 --> Utf8 Class Initialized
INFO - 2017-09-07 06:50:09 --> URI Class Initialized
INFO - 2017-09-07 06:50:09 --> Router Class Initialized
INFO - 2017-09-07 06:50:09 --> Output Class Initialized
INFO - 2017-09-07 06:50:09 --> Security Class Initialized
DEBUG - 2017-09-07 06:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 06:50:09 --> Input Class Initialized
INFO - 2017-09-07 06:50:09 --> Language Class Initialized
INFO - 2017-09-07 06:50:09 --> Loader Class Initialized
INFO - 2017-09-07 06:50:09 --> Helper loaded: url_helper
INFO - 2017-09-07 06:50:09 --> Database Driver Class Initialized
INFO - 2017-09-07 06:50:09 --> Email Class Initialized
INFO - 2017-09-07 06:50:09 --> Controller Class Initialized
DEBUG - 2017-09-07 06:50:09 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 06:50:09 --> Helper loaded: inflector_helper
INFO - 2017-09-07 06:50:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 06:50:09 --> Helper loaded: log_helper
INFO - 2017-09-07 06:50:09 --> Model Class Initialized
INFO - 2017-09-07 13:50:09 --> Final output sent to browser
DEBUG - 2017-09-07 13:50:09 --> Total execution time: 0.0584
INFO - 2017-09-07 06:50:34 --> Config Class Initialized
INFO - 2017-09-07 06:50:34 --> Hooks Class Initialized
DEBUG - 2017-09-07 06:50:34 --> UTF-8 Support Enabled
INFO - 2017-09-07 06:50:34 --> Utf8 Class Initialized
INFO - 2017-09-07 06:50:34 --> URI Class Initialized
INFO - 2017-09-07 06:50:34 --> Router Class Initialized
INFO - 2017-09-07 06:50:34 --> Output Class Initialized
INFO - 2017-09-07 06:50:34 --> Security Class Initialized
DEBUG - 2017-09-07 06:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 06:50:34 --> Input Class Initialized
INFO - 2017-09-07 06:50:34 --> Language Class Initialized
INFO - 2017-09-07 06:50:34 --> Loader Class Initialized
INFO - 2017-09-07 06:50:34 --> Helper loaded: url_helper
INFO - 2017-09-07 06:50:34 --> Database Driver Class Initialized
INFO - 2017-09-07 06:50:34 --> Email Class Initialized
INFO - 2017-09-07 06:50:34 --> Controller Class Initialized
DEBUG - 2017-09-07 06:50:34 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 06:50:34 --> Helper loaded: inflector_helper
INFO - 2017-09-07 06:50:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 06:50:34 --> Helper loaded: log_helper
INFO - 2017-09-07 06:50:34 --> Model Class Initialized
INFO - 2017-09-07 13:50:34 --> Final output sent to browser
DEBUG - 2017-09-07 13:50:34 --> Total execution time: 0.0574
INFO - 2017-09-07 06:50:41 --> Config Class Initialized
INFO - 2017-09-07 06:50:41 --> Hooks Class Initialized
DEBUG - 2017-09-07 06:50:41 --> UTF-8 Support Enabled
INFO - 2017-09-07 06:50:41 --> Utf8 Class Initialized
INFO - 2017-09-07 06:50:41 --> URI Class Initialized
INFO - 2017-09-07 06:50:41 --> Router Class Initialized
INFO - 2017-09-07 06:50:41 --> Output Class Initialized
INFO - 2017-09-07 06:50:41 --> Security Class Initialized
DEBUG - 2017-09-07 06:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 06:50:41 --> Input Class Initialized
INFO - 2017-09-07 06:50:41 --> Language Class Initialized
INFO - 2017-09-07 06:50:41 --> Loader Class Initialized
INFO - 2017-09-07 06:50:41 --> Helper loaded: url_helper
INFO - 2017-09-07 06:50:41 --> Database Driver Class Initialized
INFO - 2017-09-07 06:50:41 --> Email Class Initialized
INFO - 2017-09-07 06:50:41 --> Controller Class Initialized
DEBUG - 2017-09-07 06:50:41 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 06:50:41 --> Helper loaded: inflector_helper
INFO - 2017-09-07 06:50:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 06:50:41 --> Helper loaded: log_helper
INFO - 2017-09-07 06:50:41 --> Model Class Initialized
INFO - 2017-09-07 13:50:41 --> Final output sent to browser
DEBUG - 2017-09-07 13:50:41 --> Total execution time: 0.0850
INFO - 2017-09-07 06:52:12 --> Config Class Initialized
INFO - 2017-09-07 06:52:12 --> Hooks Class Initialized
DEBUG - 2017-09-07 06:52:12 --> UTF-8 Support Enabled
INFO - 2017-09-07 06:52:12 --> Utf8 Class Initialized
INFO - 2017-09-07 06:52:12 --> URI Class Initialized
INFO - 2017-09-07 06:52:12 --> Router Class Initialized
INFO - 2017-09-07 06:52:12 --> Output Class Initialized
INFO - 2017-09-07 06:52:12 --> Security Class Initialized
DEBUG - 2017-09-07 06:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 06:52:12 --> Input Class Initialized
INFO - 2017-09-07 06:52:12 --> Language Class Initialized
INFO - 2017-09-07 06:52:12 --> Loader Class Initialized
INFO - 2017-09-07 06:52:12 --> Helper loaded: url_helper
INFO - 2017-09-07 06:52:12 --> Database Driver Class Initialized
INFO - 2017-09-07 06:52:12 --> Email Class Initialized
INFO - 2017-09-07 06:52:12 --> Controller Class Initialized
DEBUG - 2017-09-07 06:52:12 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 06:52:12 --> Helper loaded: inflector_helper
INFO - 2017-09-07 06:52:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 06:52:12 --> Helper loaded: log_helper
INFO - 2017-09-07 06:52:12 --> Model Class Initialized
INFO - 2017-09-07 13:52:12 --> Final output sent to browser
DEBUG - 2017-09-07 13:52:12 --> Total execution time: 0.0743
INFO - 2017-09-07 06:52:20 --> Config Class Initialized
INFO - 2017-09-07 06:52:20 --> Hooks Class Initialized
DEBUG - 2017-09-07 06:52:20 --> UTF-8 Support Enabled
INFO - 2017-09-07 06:52:20 --> Utf8 Class Initialized
INFO - 2017-09-07 06:52:20 --> URI Class Initialized
INFO - 2017-09-07 06:52:20 --> Router Class Initialized
INFO - 2017-09-07 06:52:20 --> Output Class Initialized
INFO - 2017-09-07 06:52:20 --> Security Class Initialized
DEBUG - 2017-09-07 06:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 06:52:20 --> Input Class Initialized
INFO - 2017-09-07 06:52:20 --> Language Class Initialized
INFO - 2017-09-07 06:52:20 --> Loader Class Initialized
INFO - 2017-09-07 06:52:20 --> Helper loaded: url_helper
INFO - 2017-09-07 06:52:20 --> Database Driver Class Initialized
INFO - 2017-09-07 06:52:20 --> Email Class Initialized
INFO - 2017-09-07 06:52:20 --> Controller Class Initialized
DEBUG - 2017-09-07 06:52:20 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 06:52:20 --> Helper loaded: inflector_helper
INFO - 2017-09-07 06:52:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 06:52:20 --> Helper loaded: log_helper
INFO - 2017-09-07 06:52:20 --> Model Class Initialized
INFO - 2017-09-07 13:52:21 --> Final output sent to browser
DEBUG - 2017-09-07 13:52:21 --> Total execution time: 0.0846
INFO - 2017-09-07 06:54:32 --> Config Class Initialized
INFO - 2017-09-07 06:54:32 --> Hooks Class Initialized
DEBUG - 2017-09-07 06:54:32 --> UTF-8 Support Enabled
INFO - 2017-09-07 06:54:32 --> Utf8 Class Initialized
INFO - 2017-09-07 06:54:32 --> URI Class Initialized
INFO - 2017-09-07 06:54:32 --> Router Class Initialized
INFO - 2017-09-07 06:54:32 --> Output Class Initialized
INFO - 2017-09-07 06:54:32 --> Security Class Initialized
DEBUG - 2017-09-07 06:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 06:54:32 --> Input Class Initialized
INFO - 2017-09-07 06:54:32 --> Language Class Initialized
INFO - 2017-09-07 06:54:32 --> Loader Class Initialized
INFO - 2017-09-07 06:54:32 --> Helper loaded: url_helper
INFO - 2017-09-07 06:54:32 --> Database Driver Class Initialized
INFO - 2017-09-07 06:54:32 --> Email Class Initialized
INFO - 2017-09-07 06:54:32 --> Controller Class Initialized
DEBUG - 2017-09-07 06:54:32 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 06:54:32 --> Helper loaded: inflector_helper
INFO - 2017-09-07 06:54:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 06:54:32 --> Helper loaded: log_helper
INFO - 2017-09-07 06:54:32 --> Model Class Initialized
ERROR - 2017-09-07 06:54:32 --> Severity: Parsing Error --> syntax error, unexpected 'serialize' (T_STRING) C:\wamp64\www\franknco\application\models\api_model.php 353
INFO - 2017-09-07 06:54:36 --> Config Class Initialized
INFO - 2017-09-07 06:54:36 --> Hooks Class Initialized
DEBUG - 2017-09-07 06:54:36 --> UTF-8 Support Enabled
INFO - 2017-09-07 06:54:36 --> Utf8 Class Initialized
INFO - 2017-09-07 06:54:36 --> URI Class Initialized
INFO - 2017-09-07 06:54:36 --> Router Class Initialized
INFO - 2017-09-07 06:54:36 --> Output Class Initialized
INFO - 2017-09-07 06:54:36 --> Security Class Initialized
DEBUG - 2017-09-07 06:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 06:54:36 --> Input Class Initialized
INFO - 2017-09-07 06:54:36 --> Language Class Initialized
INFO - 2017-09-07 06:54:36 --> Loader Class Initialized
INFO - 2017-09-07 06:54:36 --> Helper loaded: url_helper
INFO - 2017-09-07 06:54:36 --> Database Driver Class Initialized
INFO - 2017-09-07 06:54:36 --> Email Class Initialized
INFO - 2017-09-07 06:54:36 --> Controller Class Initialized
DEBUG - 2017-09-07 06:54:36 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 06:54:36 --> Helper loaded: inflector_helper
INFO - 2017-09-07 06:54:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 06:54:36 --> Helper loaded: log_helper
INFO - 2017-09-07 06:54:36 --> Model Class Initialized
ERROR - 2017-09-07 06:54:36 --> Severity: Parsing Error --> syntax error, unexpected 'serialize' (T_STRING) C:\wamp64\www\franknco\application\models\api_model.php 353
INFO - 2017-09-07 06:54:53 --> Config Class Initialized
INFO - 2017-09-07 06:54:53 --> Hooks Class Initialized
DEBUG - 2017-09-07 06:54:53 --> UTF-8 Support Enabled
INFO - 2017-09-07 06:54:53 --> Utf8 Class Initialized
INFO - 2017-09-07 06:54:53 --> URI Class Initialized
INFO - 2017-09-07 06:54:53 --> Router Class Initialized
INFO - 2017-09-07 06:54:53 --> Output Class Initialized
INFO - 2017-09-07 06:54:53 --> Security Class Initialized
DEBUG - 2017-09-07 06:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 06:54:53 --> Input Class Initialized
INFO - 2017-09-07 06:54:53 --> Language Class Initialized
INFO - 2017-09-07 06:54:53 --> Loader Class Initialized
INFO - 2017-09-07 06:54:53 --> Helper loaded: url_helper
INFO - 2017-09-07 06:54:53 --> Database Driver Class Initialized
INFO - 2017-09-07 06:54:53 --> Email Class Initialized
INFO - 2017-09-07 06:54:53 --> Controller Class Initialized
DEBUG - 2017-09-07 06:54:53 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 06:54:53 --> Helper loaded: inflector_helper
INFO - 2017-09-07 06:54:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 06:54:53 --> Helper loaded: log_helper
INFO - 2017-09-07 06:54:53 --> Model Class Initialized
ERROR - 2017-09-07 06:54:54 --> Severity: Parsing Error --> syntax error, unexpected 'serialize' (T_STRING) C:\wamp64\www\franknco\application\models\api_model.php 353
INFO - 2017-09-07 06:55:17 --> Config Class Initialized
INFO - 2017-09-07 06:55:17 --> Hooks Class Initialized
DEBUG - 2017-09-07 06:55:17 --> UTF-8 Support Enabled
INFO - 2017-09-07 06:55:17 --> Utf8 Class Initialized
INFO - 2017-09-07 06:55:17 --> URI Class Initialized
INFO - 2017-09-07 06:55:17 --> Router Class Initialized
INFO - 2017-09-07 06:55:17 --> Output Class Initialized
INFO - 2017-09-07 06:55:17 --> Security Class Initialized
DEBUG - 2017-09-07 06:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 06:55:17 --> Input Class Initialized
INFO - 2017-09-07 06:55:17 --> Language Class Initialized
INFO - 2017-09-07 06:55:17 --> Loader Class Initialized
INFO - 2017-09-07 06:55:17 --> Helper loaded: url_helper
INFO - 2017-09-07 06:55:17 --> Database Driver Class Initialized
INFO - 2017-09-07 06:55:17 --> Email Class Initialized
INFO - 2017-09-07 06:55:17 --> Controller Class Initialized
DEBUG - 2017-09-07 06:55:17 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 06:55:17 --> Helper loaded: inflector_helper
INFO - 2017-09-07 06:55:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 06:55:17 --> Helper loaded: log_helper
INFO - 2017-09-07 06:55:17 --> Model Class Initialized
INFO - 2017-09-07 13:55:17 --> Final output sent to browser
DEBUG - 2017-09-07 13:55:17 --> Total execution time: 0.0612
INFO - 2017-09-07 06:55:20 --> Config Class Initialized
INFO - 2017-09-07 06:55:20 --> Hooks Class Initialized
DEBUG - 2017-09-07 06:55:20 --> UTF-8 Support Enabled
INFO - 2017-09-07 06:55:20 --> Utf8 Class Initialized
INFO - 2017-09-07 06:55:20 --> URI Class Initialized
INFO - 2017-09-07 06:55:20 --> Router Class Initialized
INFO - 2017-09-07 06:55:20 --> Output Class Initialized
INFO - 2017-09-07 06:55:20 --> Security Class Initialized
DEBUG - 2017-09-07 06:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 06:55:20 --> Input Class Initialized
INFO - 2017-09-07 06:55:20 --> Language Class Initialized
INFO - 2017-09-07 06:55:20 --> Loader Class Initialized
INFO - 2017-09-07 06:55:20 --> Helper loaded: url_helper
INFO - 2017-09-07 06:55:20 --> Database Driver Class Initialized
INFO - 2017-09-07 06:55:20 --> Email Class Initialized
INFO - 2017-09-07 06:55:20 --> Controller Class Initialized
DEBUG - 2017-09-07 06:55:20 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 06:55:20 --> Helper loaded: inflector_helper
INFO - 2017-09-07 06:55:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 06:55:20 --> Helper loaded: log_helper
INFO - 2017-09-07 06:55:20 --> Model Class Initialized
INFO - 2017-09-07 13:55:20 --> Final output sent to browser
DEBUG - 2017-09-07 13:55:20 --> Total execution time: 0.0573
INFO - 2017-09-07 06:55:37 --> Config Class Initialized
INFO - 2017-09-07 06:55:37 --> Hooks Class Initialized
DEBUG - 2017-09-07 06:55:37 --> UTF-8 Support Enabled
INFO - 2017-09-07 06:55:37 --> Utf8 Class Initialized
INFO - 2017-09-07 06:55:37 --> URI Class Initialized
INFO - 2017-09-07 06:55:37 --> Router Class Initialized
INFO - 2017-09-07 06:55:37 --> Output Class Initialized
INFO - 2017-09-07 06:55:37 --> Security Class Initialized
DEBUG - 2017-09-07 06:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 06:55:37 --> Input Class Initialized
INFO - 2017-09-07 06:55:37 --> Language Class Initialized
INFO - 2017-09-07 06:55:37 --> Loader Class Initialized
INFO - 2017-09-07 06:55:37 --> Helper loaded: url_helper
INFO - 2017-09-07 06:55:37 --> Database Driver Class Initialized
INFO - 2017-09-07 06:55:37 --> Email Class Initialized
INFO - 2017-09-07 06:55:37 --> Controller Class Initialized
DEBUG - 2017-09-07 06:55:37 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 06:55:37 --> Helper loaded: inflector_helper
INFO - 2017-09-07 06:55:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 06:55:37 --> Helper loaded: log_helper
INFO - 2017-09-07 06:55:37 --> Model Class Initialized
ERROR - 2017-09-07 13:55:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''1'' at line 5 - Invalid query: select b.name,a.x761,a.trans_date from transaction a
      inner join transaction_type b on a.ttid=b.ttid
      where card_id=(select card_id from card where card_number='764665453644414450694D5464776830686C763138413D3D')
      order by a.trans_date desc
      limit '1'
INFO - 2017-09-07 13:55:38 --> Language file loaded: language/english/db_lang.php
INFO - 2017-09-07 06:55:58 --> Config Class Initialized
INFO - 2017-09-07 06:55:58 --> Hooks Class Initialized
DEBUG - 2017-09-07 06:55:58 --> UTF-8 Support Enabled
INFO - 2017-09-07 06:55:58 --> Utf8 Class Initialized
INFO - 2017-09-07 06:55:58 --> URI Class Initialized
INFO - 2017-09-07 06:55:58 --> Router Class Initialized
INFO - 2017-09-07 06:55:58 --> Output Class Initialized
INFO - 2017-09-07 06:55:58 --> Security Class Initialized
DEBUG - 2017-09-07 06:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 06:55:58 --> Input Class Initialized
INFO - 2017-09-07 06:55:58 --> Language Class Initialized
INFO - 2017-09-07 06:55:58 --> Loader Class Initialized
INFO - 2017-09-07 06:55:58 --> Helper loaded: url_helper
INFO - 2017-09-07 06:55:58 --> Database Driver Class Initialized
INFO - 2017-09-07 06:55:58 --> Email Class Initialized
INFO - 2017-09-07 06:55:58 --> Controller Class Initialized
DEBUG - 2017-09-07 06:55:58 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 06:55:58 --> Helper loaded: inflector_helper
INFO - 2017-09-07 06:55:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 06:55:58 --> Helper loaded: log_helper
INFO - 2017-09-07 06:55:58 --> Model Class Initialized
ERROR - 2017-09-07 06:55:58 --> Severity: Parsing Error --> syntax error, unexpected ']', expecting identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) C:\wamp64\www\franknco\application\models\api_model.php 629
INFO - 2017-09-07 06:56:21 --> Config Class Initialized
INFO - 2017-09-07 06:56:21 --> Hooks Class Initialized
DEBUG - 2017-09-07 06:56:21 --> UTF-8 Support Enabled
INFO - 2017-09-07 06:56:21 --> Utf8 Class Initialized
INFO - 2017-09-07 06:56:21 --> URI Class Initialized
INFO - 2017-09-07 06:56:21 --> Router Class Initialized
INFO - 2017-09-07 06:56:21 --> Output Class Initialized
INFO - 2017-09-07 06:56:21 --> Security Class Initialized
DEBUG - 2017-09-07 06:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 06:56:21 --> Input Class Initialized
INFO - 2017-09-07 06:56:21 --> Language Class Initialized
INFO - 2017-09-07 06:56:21 --> Loader Class Initialized
INFO - 2017-09-07 06:56:21 --> Helper loaded: url_helper
INFO - 2017-09-07 06:56:21 --> Database Driver Class Initialized
INFO - 2017-09-07 06:56:21 --> Email Class Initialized
INFO - 2017-09-07 06:56:21 --> Controller Class Initialized
DEBUG - 2017-09-07 06:56:21 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 06:56:21 --> Helper loaded: inflector_helper
INFO - 2017-09-07 06:56:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 06:56:21 --> Helper loaded: log_helper
INFO - 2017-09-07 06:56:21 --> Model Class Initialized
ERROR - 2017-09-07 13:56:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1.' at line 5 - Invalid query: select b.name,a.x761,a.trans_date from transaction a
      inner join transaction_type b on a.ttid=b.ttid
      where card_id=(select card_id from card where card_number='764665453644414450694D5464776830686C763138413D3D')
      order by a.trans_date desc
      limit 1.
INFO - 2017-09-07 13:56:21 --> Language file loaded: language/english/db_lang.php
INFO - 2017-09-07 06:56:27 --> Config Class Initialized
INFO - 2017-09-07 06:56:27 --> Hooks Class Initialized
DEBUG - 2017-09-07 06:56:27 --> UTF-8 Support Enabled
INFO - 2017-09-07 06:56:27 --> Utf8 Class Initialized
INFO - 2017-09-07 06:56:27 --> URI Class Initialized
INFO - 2017-09-07 06:56:27 --> Router Class Initialized
INFO - 2017-09-07 06:56:27 --> Output Class Initialized
INFO - 2017-09-07 06:56:27 --> Security Class Initialized
DEBUG - 2017-09-07 06:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 06:56:27 --> Input Class Initialized
INFO - 2017-09-07 06:56:27 --> Language Class Initialized
INFO - 2017-09-07 06:56:27 --> Loader Class Initialized
INFO - 2017-09-07 06:56:27 --> Helper loaded: url_helper
INFO - 2017-09-07 06:56:27 --> Database Driver Class Initialized
INFO - 2017-09-07 06:56:27 --> Email Class Initialized
INFO - 2017-09-07 06:56:27 --> Controller Class Initialized
DEBUG - 2017-09-07 06:56:27 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 06:56:27 --> Helper loaded: inflector_helper
INFO - 2017-09-07 06:56:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 06:56:27 --> Helper loaded: log_helper
INFO - 2017-09-07 06:56:27 --> Model Class Initialized
INFO - 2017-09-07 13:56:27 --> Final output sent to browser
DEBUG - 2017-09-07 13:56:27 --> Total execution time: 0.0715
INFO - 2017-09-07 06:56:33 --> Config Class Initialized
INFO - 2017-09-07 06:56:33 --> Hooks Class Initialized
DEBUG - 2017-09-07 06:56:33 --> UTF-8 Support Enabled
INFO - 2017-09-07 06:56:33 --> Utf8 Class Initialized
INFO - 2017-09-07 06:56:33 --> URI Class Initialized
INFO - 2017-09-07 06:56:33 --> Router Class Initialized
INFO - 2017-09-07 06:56:33 --> Output Class Initialized
INFO - 2017-09-07 06:56:33 --> Security Class Initialized
DEBUG - 2017-09-07 06:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 06:56:33 --> Input Class Initialized
INFO - 2017-09-07 06:56:33 --> Language Class Initialized
INFO - 2017-09-07 06:56:33 --> Loader Class Initialized
INFO - 2017-09-07 06:56:33 --> Helper loaded: url_helper
INFO - 2017-09-07 06:56:33 --> Database Driver Class Initialized
INFO - 2017-09-07 06:56:33 --> Email Class Initialized
INFO - 2017-09-07 06:56:33 --> Controller Class Initialized
DEBUG - 2017-09-07 06:56:33 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 06:56:33 --> Helper loaded: inflector_helper
INFO - 2017-09-07 06:56:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 06:56:33 --> Helper loaded: log_helper
INFO - 2017-09-07 06:56:33 --> Model Class Initialized
INFO - 2017-09-07 13:56:33 --> Final output sent to browser
DEBUG - 2017-09-07 13:56:33 --> Total execution time: 0.0559
INFO - 2017-09-07 06:56:47 --> Config Class Initialized
INFO - 2017-09-07 06:56:47 --> Hooks Class Initialized
DEBUG - 2017-09-07 06:56:47 --> UTF-8 Support Enabled
INFO - 2017-09-07 06:56:47 --> Utf8 Class Initialized
INFO - 2017-09-07 06:56:47 --> URI Class Initialized
INFO - 2017-09-07 06:56:47 --> Router Class Initialized
INFO - 2017-09-07 06:56:47 --> Output Class Initialized
INFO - 2017-09-07 06:56:47 --> Security Class Initialized
DEBUG - 2017-09-07 06:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 06:56:47 --> Input Class Initialized
INFO - 2017-09-07 06:56:47 --> Language Class Initialized
INFO - 2017-09-07 06:56:47 --> Loader Class Initialized
INFO - 2017-09-07 06:56:47 --> Helper loaded: url_helper
INFO - 2017-09-07 06:56:47 --> Database Driver Class Initialized
INFO - 2017-09-07 06:56:47 --> Email Class Initialized
INFO - 2017-09-07 06:56:47 --> Controller Class Initialized
DEBUG - 2017-09-07 06:56:47 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 06:56:47 --> Helper loaded: inflector_helper
INFO - 2017-09-07 06:56:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 06:56:47 --> Helper loaded: log_helper
INFO - 2017-09-07 06:56:47 --> Model Class Initialized
INFO - 2017-09-07 13:56:47 --> Final output sent to browser
DEBUG - 2017-09-07 13:56:47 --> Total execution time: 0.0997
INFO - 2017-09-07 06:56:59 --> Config Class Initialized
INFO - 2017-09-07 06:56:59 --> Hooks Class Initialized
DEBUG - 2017-09-07 06:56:59 --> UTF-8 Support Enabled
INFO - 2017-09-07 06:56:59 --> Utf8 Class Initialized
INFO - 2017-09-07 06:56:59 --> URI Class Initialized
INFO - 2017-09-07 06:56:59 --> Router Class Initialized
INFO - 2017-09-07 06:56:59 --> Output Class Initialized
INFO - 2017-09-07 06:56:59 --> Security Class Initialized
DEBUG - 2017-09-07 06:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 06:56:59 --> Input Class Initialized
INFO - 2017-09-07 06:56:59 --> Language Class Initialized
INFO - 2017-09-07 06:56:59 --> Loader Class Initialized
INFO - 2017-09-07 06:56:59 --> Helper loaded: url_helper
INFO - 2017-09-07 06:56:59 --> Database Driver Class Initialized
INFO - 2017-09-07 06:56:59 --> Email Class Initialized
INFO - 2017-09-07 06:56:59 --> Controller Class Initialized
DEBUG - 2017-09-07 06:56:59 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 06:56:59 --> Helper loaded: inflector_helper
INFO - 2017-09-07 06:56:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 06:56:59 --> Helper loaded: log_helper
INFO - 2017-09-07 06:56:59 --> Model Class Initialized
INFO - 2017-09-07 13:56:59 --> Final output sent to browser
DEBUG - 2017-09-07 13:56:59 --> Total execution time: 0.0602
INFO - 2017-09-07 08:00:23 --> Config Class Initialized
INFO - 2017-09-07 08:00:23 --> Hooks Class Initialized
DEBUG - 2017-09-07 08:00:23 --> UTF-8 Support Enabled
INFO - 2017-09-07 08:00:23 --> Utf8 Class Initialized
INFO - 2017-09-07 08:00:23 --> URI Class Initialized
INFO - 2017-09-07 08:00:23 --> Router Class Initialized
INFO - 2017-09-07 08:00:23 --> Output Class Initialized
INFO - 2017-09-07 08:00:23 --> Security Class Initialized
DEBUG - 2017-09-07 08:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 08:00:23 --> Input Class Initialized
INFO - 2017-09-07 08:00:23 --> Language Class Initialized
INFO - 2017-09-07 08:00:23 --> Loader Class Initialized
INFO - 2017-09-07 08:00:23 --> Helper loaded: url_helper
INFO - 2017-09-07 08:00:23 --> Database Driver Class Initialized
INFO - 2017-09-07 08:00:23 --> Email Class Initialized
INFO - 2017-09-07 08:00:23 --> Controller Class Initialized
DEBUG - 2017-09-07 08:00:23 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 08:00:23 --> Helper loaded: inflector_helper
INFO - 2017-09-07 08:00:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 08:00:23 --> Helper loaded: log_helper
INFO - 2017-09-07 08:00:23 --> Model Class Initialized
INFO - 2017-09-07 15:00:23 --> Final output sent to browser
DEBUG - 2017-09-07 15:00:23 --> Total execution time: 0.3593
INFO - 2017-09-07 08:00:26 --> Config Class Initialized
INFO - 2017-09-07 08:00:26 --> Hooks Class Initialized
DEBUG - 2017-09-07 08:00:26 --> UTF-8 Support Enabled
INFO - 2017-09-07 08:00:26 --> Utf8 Class Initialized
INFO - 2017-09-07 08:00:26 --> URI Class Initialized
INFO - 2017-09-07 08:00:26 --> Router Class Initialized
INFO - 2017-09-07 08:00:26 --> Output Class Initialized
INFO - 2017-09-07 08:00:26 --> Security Class Initialized
DEBUG - 2017-09-07 08:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 08:00:26 --> Input Class Initialized
INFO - 2017-09-07 08:00:26 --> Language Class Initialized
INFO - 2017-09-07 08:00:26 --> Loader Class Initialized
INFO - 2017-09-07 08:00:26 --> Helper loaded: url_helper
INFO - 2017-09-07 08:00:26 --> Database Driver Class Initialized
INFO - 2017-09-07 08:00:26 --> Email Class Initialized
INFO - 2017-09-07 08:00:26 --> Controller Class Initialized
DEBUG - 2017-09-07 08:00:26 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 08:00:26 --> Helper loaded: inflector_helper
INFO - 2017-09-07 08:00:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 08:00:26 --> Helper loaded: log_helper
INFO - 2017-09-07 08:00:26 --> Model Class Initialized
INFO - 2017-09-07 15:00:26 --> Final output sent to browser
DEBUG - 2017-09-07 15:00:26 --> Total execution time: 0.0935
INFO - 2017-09-07 08:00:32 --> Config Class Initialized
INFO - 2017-09-07 08:00:32 --> Hooks Class Initialized
DEBUG - 2017-09-07 08:00:32 --> UTF-8 Support Enabled
INFO - 2017-09-07 08:00:32 --> Utf8 Class Initialized
INFO - 2017-09-07 08:00:32 --> URI Class Initialized
INFO - 2017-09-07 08:00:32 --> Router Class Initialized
INFO - 2017-09-07 08:00:32 --> Output Class Initialized
INFO - 2017-09-07 08:00:32 --> Security Class Initialized
DEBUG - 2017-09-07 08:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 08:00:32 --> Input Class Initialized
INFO - 2017-09-07 08:00:32 --> Language Class Initialized
INFO - 2017-09-07 08:00:32 --> Loader Class Initialized
INFO - 2017-09-07 08:00:32 --> Helper loaded: url_helper
INFO - 2017-09-07 08:00:32 --> Database Driver Class Initialized
INFO - 2017-09-07 08:00:32 --> Email Class Initialized
INFO - 2017-09-07 08:00:32 --> Controller Class Initialized
DEBUG - 2017-09-07 08:00:32 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 08:00:32 --> Helper loaded: inflector_helper
INFO - 2017-09-07 08:00:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 08:00:32 --> Helper loaded: log_helper
INFO - 2017-09-07 08:00:32 --> Model Class Initialized
INFO - 2017-09-07 15:00:32 --> Final output sent to browser
DEBUG - 2017-09-07 15:00:32 --> Total execution time: 0.0945
INFO - 2017-09-07 08:00:49 --> Config Class Initialized
INFO - 2017-09-07 08:00:49 --> Hooks Class Initialized
DEBUG - 2017-09-07 08:00:49 --> UTF-8 Support Enabled
INFO - 2017-09-07 08:00:49 --> Utf8 Class Initialized
INFO - 2017-09-07 08:00:49 --> URI Class Initialized
INFO - 2017-09-07 08:00:49 --> Router Class Initialized
INFO - 2017-09-07 08:00:49 --> Output Class Initialized
INFO - 2017-09-07 08:00:49 --> Security Class Initialized
DEBUG - 2017-09-07 08:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 08:00:49 --> Input Class Initialized
INFO - 2017-09-07 08:00:49 --> Language Class Initialized
INFO - 2017-09-07 08:00:49 --> Loader Class Initialized
INFO - 2017-09-07 08:00:49 --> Helper loaded: url_helper
INFO - 2017-09-07 08:00:49 --> Database Driver Class Initialized
INFO - 2017-09-07 08:00:49 --> Email Class Initialized
INFO - 2017-09-07 08:00:49 --> Controller Class Initialized
DEBUG - 2017-09-07 08:00:49 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 08:00:49 --> Helper loaded: inflector_helper
INFO - 2017-09-07 08:00:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 08:00:49 --> Helper loaded: log_helper
INFO - 2017-09-07 08:00:49 --> Model Class Initialized
INFO - 2017-09-07 15:00:49 --> Final output sent to browser
DEBUG - 2017-09-07 15:00:49 --> Total execution time: 0.0873
INFO - 2017-09-07 08:00:52 --> Config Class Initialized
INFO - 2017-09-07 08:00:52 --> Hooks Class Initialized
DEBUG - 2017-09-07 08:00:52 --> UTF-8 Support Enabled
INFO - 2017-09-07 08:00:52 --> Utf8 Class Initialized
INFO - 2017-09-07 08:00:52 --> URI Class Initialized
INFO - 2017-09-07 08:00:52 --> Router Class Initialized
INFO - 2017-09-07 08:00:52 --> Output Class Initialized
INFO - 2017-09-07 08:00:52 --> Security Class Initialized
DEBUG - 2017-09-07 08:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 08:00:52 --> Input Class Initialized
INFO - 2017-09-07 08:00:52 --> Language Class Initialized
INFO - 2017-09-07 08:00:52 --> Loader Class Initialized
INFO - 2017-09-07 08:00:52 --> Helper loaded: url_helper
INFO - 2017-09-07 08:00:52 --> Database Driver Class Initialized
INFO - 2017-09-07 08:00:52 --> Email Class Initialized
INFO - 2017-09-07 08:00:52 --> Controller Class Initialized
DEBUG - 2017-09-07 08:00:52 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 08:00:52 --> Helper loaded: inflector_helper
INFO - 2017-09-07 08:00:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 08:00:52 --> Helper loaded: log_helper
INFO - 2017-09-07 08:00:52 --> Model Class Initialized
INFO - 2017-09-07 15:00:52 --> Final output sent to browser
DEBUG - 2017-09-07 15:00:52 --> Total execution time: 0.1587
INFO - 2017-09-07 08:01:07 --> Config Class Initialized
INFO - 2017-09-07 08:01:07 --> Hooks Class Initialized
DEBUG - 2017-09-07 08:01:07 --> UTF-8 Support Enabled
INFO - 2017-09-07 08:01:07 --> Utf8 Class Initialized
INFO - 2017-09-07 08:01:07 --> URI Class Initialized
INFO - 2017-09-07 08:01:07 --> Router Class Initialized
INFO - 2017-09-07 08:01:07 --> Output Class Initialized
INFO - 2017-09-07 08:01:07 --> Security Class Initialized
DEBUG - 2017-09-07 08:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 08:01:07 --> Input Class Initialized
INFO - 2017-09-07 08:01:07 --> Language Class Initialized
INFO - 2017-09-07 08:01:07 --> Loader Class Initialized
INFO - 2017-09-07 08:01:07 --> Helper loaded: url_helper
INFO - 2017-09-07 08:01:07 --> Database Driver Class Initialized
INFO - 2017-09-07 08:01:07 --> Email Class Initialized
INFO - 2017-09-07 08:01:07 --> Controller Class Initialized
DEBUG - 2017-09-07 08:01:07 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 08:01:07 --> Helper loaded: inflector_helper
INFO - 2017-09-07 08:01:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 08:01:07 --> Helper loaded: log_helper
INFO - 2017-09-07 08:01:07 --> Model Class Initialized
INFO - 2017-09-07 15:01:07 --> Final output sent to browser
DEBUG - 2017-09-07 15:01:07 --> Total execution time: 0.0704
INFO - 2017-09-07 08:01:12 --> Config Class Initialized
INFO - 2017-09-07 08:01:12 --> Hooks Class Initialized
DEBUG - 2017-09-07 08:01:12 --> UTF-8 Support Enabled
INFO - 2017-09-07 08:01:12 --> Utf8 Class Initialized
INFO - 2017-09-07 08:01:12 --> URI Class Initialized
INFO - 2017-09-07 08:01:12 --> Router Class Initialized
INFO - 2017-09-07 08:01:12 --> Output Class Initialized
INFO - 2017-09-07 08:01:12 --> Security Class Initialized
DEBUG - 2017-09-07 08:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 08:01:12 --> Input Class Initialized
INFO - 2017-09-07 08:01:12 --> Language Class Initialized
INFO - 2017-09-07 08:01:12 --> Loader Class Initialized
INFO - 2017-09-07 08:01:12 --> Helper loaded: url_helper
INFO - 2017-09-07 08:01:12 --> Database Driver Class Initialized
INFO - 2017-09-07 08:01:12 --> Email Class Initialized
INFO - 2017-09-07 08:01:12 --> Controller Class Initialized
DEBUG - 2017-09-07 08:01:12 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 08:01:12 --> Helper loaded: inflector_helper
INFO - 2017-09-07 08:01:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 08:01:12 --> Helper loaded: log_helper
INFO - 2017-09-07 08:01:12 --> Model Class Initialized
INFO - 2017-09-07 15:01:12 --> Final output sent to browser
DEBUG - 2017-09-07 15:01:12 --> Total execution time: 0.2307
INFO - 2017-09-07 08:01:16 --> Config Class Initialized
INFO - 2017-09-07 08:01:16 --> Hooks Class Initialized
DEBUG - 2017-09-07 08:01:16 --> UTF-8 Support Enabled
INFO - 2017-09-07 08:01:16 --> Utf8 Class Initialized
INFO - 2017-09-07 08:01:16 --> URI Class Initialized
INFO - 2017-09-07 08:01:16 --> Router Class Initialized
INFO - 2017-09-07 08:01:16 --> Output Class Initialized
INFO - 2017-09-07 08:01:16 --> Security Class Initialized
DEBUG - 2017-09-07 08:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 08:01:16 --> Input Class Initialized
INFO - 2017-09-07 08:01:16 --> Language Class Initialized
INFO - 2017-09-07 08:01:17 --> Loader Class Initialized
INFO - 2017-09-07 08:01:17 --> Helper loaded: url_helper
INFO - 2017-09-07 08:01:17 --> Database Driver Class Initialized
INFO - 2017-09-07 08:01:17 --> Email Class Initialized
INFO - 2017-09-07 08:01:17 --> Controller Class Initialized
DEBUG - 2017-09-07 08:01:17 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 08:01:17 --> Helper loaded: inflector_helper
INFO - 2017-09-07 08:01:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 08:01:17 --> Helper loaded: log_helper
INFO - 2017-09-07 08:01:17 --> Model Class Initialized
INFO - 2017-09-07 15:01:17 --> Final output sent to browser
DEBUG - 2017-09-07 15:01:17 --> Total execution time: 0.0770
INFO - 2017-09-07 08:17:09 --> Config Class Initialized
INFO - 2017-09-07 08:17:09 --> Hooks Class Initialized
DEBUG - 2017-09-07 08:17:09 --> UTF-8 Support Enabled
INFO - 2017-09-07 08:17:09 --> Utf8 Class Initialized
INFO - 2017-09-07 08:17:09 --> URI Class Initialized
INFO - 2017-09-07 08:17:09 --> Router Class Initialized
INFO - 2017-09-07 08:17:09 --> Output Class Initialized
INFO - 2017-09-07 08:17:09 --> Security Class Initialized
DEBUG - 2017-09-07 08:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 08:17:09 --> Input Class Initialized
INFO - 2017-09-07 08:17:09 --> Language Class Initialized
INFO - 2017-09-07 08:17:09 --> Loader Class Initialized
INFO - 2017-09-07 08:17:09 --> Helper loaded: url_helper
INFO - 2017-09-07 08:17:09 --> Database Driver Class Initialized
INFO - 2017-09-07 08:17:09 --> Email Class Initialized
INFO - 2017-09-07 08:17:09 --> Controller Class Initialized
DEBUG - 2017-09-07 08:17:09 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 08:17:09 --> Helper loaded: inflector_helper
INFO - 2017-09-07 08:17:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 08:17:09 --> Helper loaded: log_helper
INFO - 2017-09-07 08:17:09 --> Model Class Initialized
INFO - 2017-09-07 15:17:09 --> Final output sent to browser
DEBUG - 2017-09-07 15:17:09 --> Total execution time: 0.1056
INFO - 2017-09-07 08:17:12 --> Config Class Initialized
INFO - 2017-09-07 08:17:12 --> Hooks Class Initialized
DEBUG - 2017-09-07 08:17:12 --> UTF-8 Support Enabled
INFO - 2017-09-07 08:17:12 --> Utf8 Class Initialized
INFO - 2017-09-07 08:17:12 --> URI Class Initialized
INFO - 2017-09-07 08:17:12 --> Router Class Initialized
INFO - 2017-09-07 08:17:12 --> Output Class Initialized
INFO - 2017-09-07 08:17:12 --> Security Class Initialized
DEBUG - 2017-09-07 08:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 08:17:12 --> Input Class Initialized
INFO - 2017-09-07 08:17:12 --> Language Class Initialized
INFO - 2017-09-07 08:17:12 --> Loader Class Initialized
INFO - 2017-09-07 08:17:12 --> Helper loaded: url_helper
INFO - 2017-09-07 08:17:12 --> Database Driver Class Initialized
INFO - 2017-09-07 08:17:12 --> Email Class Initialized
INFO - 2017-09-07 08:17:12 --> Controller Class Initialized
DEBUG - 2017-09-07 08:17:12 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 08:17:12 --> Helper loaded: inflector_helper
INFO - 2017-09-07 08:17:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 08:17:12 --> Helper loaded: log_helper
INFO - 2017-09-07 08:17:12 --> Model Class Initialized
INFO - 2017-09-07 15:17:12 --> Final output sent to browser
DEBUG - 2017-09-07 15:17:12 --> Total execution time: 0.0810
INFO - 2017-09-07 08:23:19 --> Config Class Initialized
INFO - 2017-09-07 08:23:19 --> Hooks Class Initialized
DEBUG - 2017-09-07 08:23:19 --> UTF-8 Support Enabled
INFO - 2017-09-07 08:23:19 --> Utf8 Class Initialized
INFO - 2017-09-07 08:23:19 --> URI Class Initialized
INFO - 2017-09-07 08:23:19 --> Router Class Initialized
INFO - 2017-09-07 08:23:19 --> Output Class Initialized
INFO - 2017-09-07 08:23:19 --> Security Class Initialized
DEBUG - 2017-09-07 08:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 08:23:19 --> Input Class Initialized
INFO - 2017-09-07 08:23:19 --> Language Class Initialized
INFO - 2017-09-07 08:23:19 --> Loader Class Initialized
INFO - 2017-09-07 08:23:19 --> Helper loaded: url_helper
INFO - 2017-09-07 08:23:19 --> Database Driver Class Initialized
INFO - 2017-09-07 08:23:19 --> Email Class Initialized
INFO - 2017-09-07 08:23:19 --> Controller Class Initialized
DEBUG - 2017-09-07 08:23:19 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 08:23:19 --> Helper loaded: inflector_helper
INFO - 2017-09-07 08:23:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 08:23:19 --> Helper loaded: log_helper
INFO - 2017-09-07 08:23:19 --> Model Class Initialized
ERROR - 2017-09-07 15:23:19 --> Severity: Notice --> Undefined index: msg C:\wamp64\www\franknco\application\controllers\api\franknco_api.php 38
INFO - 2017-09-07 15:23:19 --> Final output sent to browser
DEBUG - 2017-09-07 15:23:19 --> Total execution time: 0.0859
INFO - 2017-09-07 08:26:20 --> Config Class Initialized
INFO - 2017-09-07 08:26:20 --> Hooks Class Initialized
DEBUG - 2017-09-07 08:26:20 --> UTF-8 Support Enabled
INFO - 2017-09-07 08:26:20 --> Utf8 Class Initialized
INFO - 2017-09-07 08:26:20 --> URI Class Initialized
INFO - 2017-09-07 08:26:20 --> Router Class Initialized
INFO - 2017-09-07 08:26:20 --> Output Class Initialized
INFO - 2017-09-07 08:26:20 --> Security Class Initialized
DEBUG - 2017-09-07 08:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 08:26:20 --> Input Class Initialized
INFO - 2017-09-07 08:26:20 --> Language Class Initialized
INFO - 2017-09-07 08:26:20 --> Loader Class Initialized
INFO - 2017-09-07 08:26:20 --> Helper loaded: url_helper
INFO - 2017-09-07 08:26:20 --> Database Driver Class Initialized
INFO - 2017-09-07 08:26:20 --> Email Class Initialized
INFO - 2017-09-07 08:26:20 --> Controller Class Initialized
DEBUG - 2017-09-07 08:26:20 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 08:26:20 --> Helper loaded: inflector_helper
INFO - 2017-09-07 08:26:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 08:26:20 --> Helper loaded: log_helper
INFO - 2017-09-07 08:26:20 --> Model Class Initialized
ERROR - 2017-09-07 15:26:20 --> Severity: Notice --> Undefined index: msg C:\wamp64\www\franknco\application\controllers\api\franknco_api.php 38
INFO - 2017-09-07 15:26:20 --> Final output sent to browser
DEBUG - 2017-09-07 15:26:20 --> Total execution time: 0.0721
INFO - 2017-09-07 08:27:39 --> Config Class Initialized
INFO - 2017-09-07 08:27:39 --> Hooks Class Initialized
DEBUG - 2017-09-07 08:27:39 --> UTF-8 Support Enabled
INFO - 2017-09-07 08:27:39 --> Utf8 Class Initialized
INFO - 2017-09-07 08:27:39 --> URI Class Initialized
INFO - 2017-09-07 08:27:39 --> Router Class Initialized
INFO - 2017-09-07 08:27:39 --> Output Class Initialized
INFO - 2017-09-07 08:27:39 --> Security Class Initialized
DEBUG - 2017-09-07 08:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 08:27:39 --> Input Class Initialized
INFO - 2017-09-07 08:27:39 --> Language Class Initialized
INFO - 2017-09-07 08:27:39 --> Loader Class Initialized
INFO - 2017-09-07 08:27:39 --> Helper loaded: url_helper
INFO - 2017-09-07 08:27:39 --> Database Driver Class Initialized
INFO - 2017-09-07 08:27:39 --> Email Class Initialized
INFO - 2017-09-07 08:27:39 --> Controller Class Initialized
DEBUG - 2017-09-07 08:27:39 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 08:27:39 --> Helper loaded: inflector_helper
INFO - 2017-09-07 08:27:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 08:27:39 --> Helper loaded: log_helper
INFO - 2017-09-07 08:27:39 --> Model Class Initialized
INFO - 2017-09-07 15:27:39 --> Final output sent to browser
DEBUG - 2017-09-07 15:27:39 --> Total execution time: 0.0642
INFO - 2017-09-07 08:35:42 --> Config Class Initialized
INFO - 2017-09-07 08:35:42 --> Hooks Class Initialized
DEBUG - 2017-09-07 08:35:42 --> UTF-8 Support Enabled
INFO - 2017-09-07 08:35:42 --> Utf8 Class Initialized
INFO - 2017-09-07 08:35:42 --> URI Class Initialized
INFO - 2017-09-07 08:35:42 --> Router Class Initialized
INFO - 2017-09-07 08:35:42 --> Output Class Initialized
INFO - 2017-09-07 08:35:42 --> Security Class Initialized
DEBUG - 2017-09-07 08:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 08:35:42 --> Input Class Initialized
INFO - 2017-09-07 08:35:42 --> Language Class Initialized
INFO - 2017-09-07 08:35:42 --> Loader Class Initialized
INFO - 2017-09-07 08:35:42 --> Helper loaded: url_helper
INFO - 2017-09-07 08:35:42 --> Database Driver Class Initialized
INFO - 2017-09-07 08:35:42 --> Email Class Initialized
INFO - 2017-09-07 08:35:42 --> Controller Class Initialized
DEBUG - 2017-09-07 08:35:42 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 08:35:42 --> Helper loaded: inflector_helper
INFO - 2017-09-07 08:35:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 08:35:42 --> Helper loaded: log_helper
INFO - 2017-09-07 08:35:42 --> Model Class Initialized
ERROR - 2017-09-07 15:35:43 --> Severity: Notice --> Undefined index: msg C:\wamp64\www\franknco\application\controllers\api\franknco_api.php 38
INFO - 2017-09-07 15:35:43 --> Final output sent to browser
DEBUG - 2017-09-07 15:35:43 --> Total execution time: 0.0713
INFO - 2017-09-07 08:35:46 --> Config Class Initialized
INFO - 2017-09-07 08:35:46 --> Hooks Class Initialized
DEBUG - 2017-09-07 08:35:46 --> UTF-8 Support Enabled
INFO - 2017-09-07 08:35:46 --> Utf8 Class Initialized
INFO - 2017-09-07 08:35:46 --> URI Class Initialized
INFO - 2017-09-07 08:35:46 --> Router Class Initialized
INFO - 2017-09-07 08:35:46 --> Output Class Initialized
INFO - 2017-09-07 08:35:46 --> Security Class Initialized
DEBUG - 2017-09-07 08:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 08:35:46 --> Input Class Initialized
INFO - 2017-09-07 08:35:46 --> Language Class Initialized
INFO - 2017-09-07 08:35:46 --> Loader Class Initialized
INFO - 2017-09-07 08:35:46 --> Helper loaded: url_helper
INFO - 2017-09-07 08:35:46 --> Database Driver Class Initialized
INFO - 2017-09-07 08:35:46 --> Email Class Initialized
INFO - 2017-09-07 08:35:46 --> Controller Class Initialized
DEBUG - 2017-09-07 08:35:46 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 08:35:46 --> Helper loaded: inflector_helper
INFO - 2017-09-07 08:35:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 08:35:46 --> Helper loaded: log_helper
INFO - 2017-09-07 08:35:46 --> Model Class Initialized
ERROR - 2017-09-07 15:35:46 --> Severity: Notice --> Undefined index: msg C:\wamp64\www\franknco\application\controllers\api\franknco_api.php 38
INFO - 2017-09-07 15:35:46 --> Final output sent to browser
DEBUG - 2017-09-07 15:35:46 --> Total execution time: 0.0562
INFO - 2017-09-07 08:37:24 --> Config Class Initialized
INFO - 2017-09-07 08:37:24 --> Hooks Class Initialized
DEBUG - 2017-09-07 08:37:24 --> UTF-8 Support Enabled
INFO - 2017-09-07 08:37:24 --> Utf8 Class Initialized
INFO - 2017-09-07 08:37:24 --> URI Class Initialized
INFO - 2017-09-07 08:37:24 --> Router Class Initialized
INFO - 2017-09-07 08:37:24 --> Output Class Initialized
INFO - 2017-09-07 08:37:24 --> Security Class Initialized
DEBUG - 2017-09-07 08:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 08:37:24 --> Input Class Initialized
INFO - 2017-09-07 08:37:24 --> Language Class Initialized
INFO - 2017-09-07 08:37:24 --> Loader Class Initialized
INFO - 2017-09-07 08:37:24 --> Helper loaded: url_helper
INFO - 2017-09-07 08:37:24 --> Database Driver Class Initialized
INFO - 2017-09-07 08:37:24 --> Email Class Initialized
INFO - 2017-09-07 08:37:24 --> Controller Class Initialized
DEBUG - 2017-09-07 08:37:24 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 08:37:24 --> Helper loaded: inflector_helper
INFO - 2017-09-07 08:37:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 08:37:24 --> Helper loaded: log_helper
INFO - 2017-09-07 08:37:24 --> Model Class Initialized
ERROR - 2017-09-07 15:37:24 --> Severity: Notice --> Undefined index: user C:\wamp64\www\franknco\application\controllers\api\franknco_api.php 44
ERROR - 2017-09-07 15:37:24 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\franknco\application\models\api_model.php 379
INFO - 2017-09-07 15:37:24 --> Final output sent to browser
DEBUG - 2017-09-07 15:37:24 --> Total execution time: 0.0622
INFO - 2017-09-07 08:38:54 --> Config Class Initialized
INFO - 2017-09-07 08:38:54 --> Hooks Class Initialized
DEBUG - 2017-09-07 08:38:54 --> UTF-8 Support Enabled
INFO - 2017-09-07 08:38:54 --> Utf8 Class Initialized
INFO - 2017-09-07 08:38:54 --> URI Class Initialized
INFO - 2017-09-07 08:38:54 --> Router Class Initialized
INFO - 2017-09-07 08:38:54 --> Output Class Initialized
INFO - 2017-09-07 08:38:54 --> Security Class Initialized
DEBUG - 2017-09-07 08:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 08:38:54 --> Input Class Initialized
INFO - 2017-09-07 08:38:54 --> Language Class Initialized
INFO - 2017-09-07 08:38:54 --> Loader Class Initialized
INFO - 2017-09-07 08:38:54 --> Helper loaded: url_helper
INFO - 2017-09-07 08:38:54 --> Database Driver Class Initialized
INFO - 2017-09-07 08:38:54 --> Email Class Initialized
INFO - 2017-09-07 08:38:54 --> Controller Class Initialized
DEBUG - 2017-09-07 08:38:54 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 08:38:54 --> Helper loaded: inflector_helper
INFO - 2017-09-07 08:38:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 08:38:54 --> Helper loaded: log_helper
INFO - 2017-09-07 08:38:54 --> Model Class Initialized
ERROR - 2017-09-07 15:38:54 --> Severity: Notice --> Undefined index: user C:\wamp64\www\franknco\application\controllers\api\franknco_api.php 44
ERROR - 2017-09-07 15:38:54 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\franknco\application\models\api_model.php 379
INFO - 2017-09-07 15:38:54 --> Final output sent to browser
DEBUG - 2017-09-07 15:38:54 --> Total execution time: 0.0806
INFO - 2017-09-07 08:39:34 --> Config Class Initialized
INFO - 2017-09-07 08:39:34 --> Hooks Class Initialized
DEBUG - 2017-09-07 08:39:34 --> UTF-8 Support Enabled
INFO - 2017-09-07 08:39:34 --> Utf8 Class Initialized
INFO - 2017-09-07 08:39:34 --> URI Class Initialized
INFO - 2017-09-07 08:39:34 --> Router Class Initialized
INFO - 2017-09-07 08:39:34 --> Output Class Initialized
INFO - 2017-09-07 08:39:34 --> Security Class Initialized
DEBUG - 2017-09-07 08:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 08:39:34 --> Input Class Initialized
INFO - 2017-09-07 08:39:34 --> Language Class Initialized
INFO - 2017-09-07 08:39:34 --> Loader Class Initialized
INFO - 2017-09-07 08:39:34 --> Helper loaded: url_helper
INFO - 2017-09-07 08:39:34 --> Database Driver Class Initialized
INFO - 2017-09-07 08:39:34 --> Email Class Initialized
INFO - 2017-09-07 08:39:34 --> Controller Class Initialized
DEBUG - 2017-09-07 08:39:34 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 08:39:34 --> Helper loaded: inflector_helper
INFO - 2017-09-07 08:39:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 08:39:34 --> Helper loaded: log_helper
INFO - 2017-09-07 08:39:34 --> Model Class Initialized
INFO - 2017-09-07 15:39:34 --> Final output sent to browser
DEBUG - 2017-09-07 15:39:34 --> Total execution time: 0.0657
INFO - 2017-09-07 08:39:37 --> Config Class Initialized
INFO - 2017-09-07 08:39:37 --> Hooks Class Initialized
DEBUG - 2017-09-07 08:39:37 --> UTF-8 Support Enabled
INFO - 2017-09-07 08:39:37 --> Utf8 Class Initialized
INFO - 2017-09-07 08:39:37 --> URI Class Initialized
INFO - 2017-09-07 08:39:37 --> Router Class Initialized
INFO - 2017-09-07 08:39:37 --> Output Class Initialized
INFO - 2017-09-07 08:39:37 --> Security Class Initialized
DEBUG - 2017-09-07 08:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 08:39:37 --> Input Class Initialized
INFO - 2017-09-07 08:39:37 --> Language Class Initialized
INFO - 2017-09-07 08:39:37 --> Loader Class Initialized
INFO - 2017-09-07 08:39:37 --> Helper loaded: url_helper
INFO - 2017-09-07 08:39:37 --> Database Driver Class Initialized
INFO - 2017-09-07 08:39:37 --> Email Class Initialized
INFO - 2017-09-07 08:39:37 --> Controller Class Initialized
DEBUG - 2017-09-07 08:39:37 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 08:39:37 --> Helper loaded: inflector_helper
INFO - 2017-09-07 08:39:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 08:39:37 --> Helper loaded: log_helper
INFO - 2017-09-07 08:39:37 --> Model Class Initialized
INFO - 2017-09-07 15:39:37 --> Final output sent to browser
DEBUG - 2017-09-07 15:39:37 --> Total execution time: 0.1870
INFO - 2017-09-07 08:39:41 --> Config Class Initialized
INFO - 2017-09-07 08:39:41 --> Hooks Class Initialized
DEBUG - 2017-09-07 08:39:41 --> UTF-8 Support Enabled
INFO - 2017-09-07 08:39:41 --> Utf8 Class Initialized
INFO - 2017-09-07 08:39:41 --> URI Class Initialized
INFO - 2017-09-07 08:39:41 --> Router Class Initialized
INFO - 2017-09-07 08:39:41 --> Output Class Initialized
INFO - 2017-09-07 08:39:41 --> Security Class Initialized
DEBUG - 2017-09-07 08:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 08:39:41 --> Input Class Initialized
INFO - 2017-09-07 08:39:41 --> Language Class Initialized
INFO - 2017-09-07 08:39:41 --> Loader Class Initialized
INFO - 2017-09-07 08:39:41 --> Helper loaded: url_helper
INFO - 2017-09-07 08:39:41 --> Database Driver Class Initialized
INFO - 2017-09-07 08:39:41 --> Email Class Initialized
INFO - 2017-09-07 08:39:41 --> Controller Class Initialized
DEBUG - 2017-09-07 08:39:41 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 08:39:41 --> Helper loaded: inflector_helper
INFO - 2017-09-07 08:39:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 08:39:41 --> Helper loaded: log_helper
INFO - 2017-09-07 08:39:41 --> Model Class Initialized
INFO - 2017-09-07 15:39:41 --> Final output sent to browser
DEBUG - 2017-09-07 15:39:41 --> Total execution time: 0.0553
INFO - 2017-09-07 08:39:43 --> Config Class Initialized
INFO - 2017-09-07 08:39:43 --> Hooks Class Initialized
DEBUG - 2017-09-07 08:39:43 --> UTF-8 Support Enabled
INFO - 2017-09-07 08:39:43 --> Utf8 Class Initialized
INFO - 2017-09-07 08:39:43 --> URI Class Initialized
INFO - 2017-09-07 08:39:43 --> Router Class Initialized
INFO - 2017-09-07 08:39:43 --> Output Class Initialized
INFO - 2017-09-07 08:39:43 --> Security Class Initialized
DEBUG - 2017-09-07 08:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 08:39:43 --> Input Class Initialized
INFO - 2017-09-07 08:39:43 --> Language Class Initialized
INFO - 2017-09-07 08:39:43 --> Loader Class Initialized
INFO - 2017-09-07 08:39:43 --> Helper loaded: url_helper
INFO - 2017-09-07 08:39:43 --> Database Driver Class Initialized
INFO - 2017-09-07 08:39:43 --> Email Class Initialized
INFO - 2017-09-07 08:39:43 --> Controller Class Initialized
DEBUG - 2017-09-07 08:39:43 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 08:39:43 --> Helper loaded: inflector_helper
INFO - 2017-09-07 08:39:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 08:39:43 --> Helper loaded: log_helper
INFO - 2017-09-07 08:39:43 --> Model Class Initialized
INFO - 2017-09-07 15:39:43 --> Final output sent to browser
DEBUG - 2017-09-07 15:39:43 --> Total execution time: 0.0576
INFO - 2017-09-07 08:39:50 --> Config Class Initialized
INFO - 2017-09-07 08:39:50 --> Hooks Class Initialized
DEBUG - 2017-09-07 08:39:50 --> UTF-8 Support Enabled
INFO - 2017-09-07 08:39:50 --> Utf8 Class Initialized
INFO - 2017-09-07 08:39:50 --> URI Class Initialized
INFO - 2017-09-07 08:39:50 --> Router Class Initialized
INFO - 2017-09-07 08:39:50 --> Output Class Initialized
INFO - 2017-09-07 08:39:50 --> Security Class Initialized
DEBUG - 2017-09-07 08:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 08:39:50 --> Input Class Initialized
INFO - 2017-09-07 08:39:50 --> Language Class Initialized
INFO - 2017-09-07 08:39:50 --> Loader Class Initialized
INFO - 2017-09-07 08:39:50 --> Helper loaded: url_helper
INFO - 2017-09-07 08:39:50 --> Database Driver Class Initialized
INFO - 2017-09-07 08:39:50 --> Email Class Initialized
INFO - 2017-09-07 08:39:50 --> Controller Class Initialized
DEBUG - 2017-09-07 08:39:50 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 08:39:50 --> Helper loaded: inflector_helper
INFO - 2017-09-07 08:39:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 08:39:50 --> Helper loaded: log_helper
INFO - 2017-09-07 08:39:50 --> Model Class Initialized
INFO - 2017-09-07 15:39:50 --> Final output sent to browser
DEBUG - 2017-09-07 15:39:50 --> Total execution time: 0.0775
INFO - 2017-09-07 08:39:55 --> Config Class Initialized
INFO - 2017-09-07 08:39:55 --> Hooks Class Initialized
DEBUG - 2017-09-07 08:39:55 --> UTF-8 Support Enabled
INFO - 2017-09-07 08:39:55 --> Utf8 Class Initialized
INFO - 2017-09-07 08:39:55 --> URI Class Initialized
INFO - 2017-09-07 08:39:55 --> Router Class Initialized
INFO - 2017-09-07 08:39:55 --> Output Class Initialized
INFO - 2017-09-07 08:39:55 --> Security Class Initialized
DEBUG - 2017-09-07 08:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 08:39:55 --> Input Class Initialized
INFO - 2017-09-07 08:39:55 --> Language Class Initialized
INFO - 2017-09-07 08:39:55 --> Loader Class Initialized
INFO - 2017-09-07 08:39:55 --> Helper loaded: url_helper
INFO - 2017-09-07 08:39:55 --> Database Driver Class Initialized
INFO - 2017-09-07 08:39:55 --> Email Class Initialized
INFO - 2017-09-07 08:39:55 --> Controller Class Initialized
DEBUG - 2017-09-07 08:39:55 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 08:39:55 --> Helper loaded: inflector_helper
INFO - 2017-09-07 08:39:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 08:39:55 --> Helper loaded: log_helper
INFO - 2017-09-07 08:39:55 --> Model Class Initialized
INFO - 2017-09-07 15:39:55 --> Final output sent to browser
DEBUG - 2017-09-07 15:39:55 --> Total execution time: 0.0594
INFO - 2017-09-07 08:40:07 --> Config Class Initialized
INFO - 2017-09-07 08:40:07 --> Hooks Class Initialized
DEBUG - 2017-09-07 08:40:07 --> UTF-8 Support Enabled
INFO - 2017-09-07 08:40:07 --> Utf8 Class Initialized
INFO - 2017-09-07 08:40:07 --> URI Class Initialized
INFO - 2017-09-07 08:40:07 --> Router Class Initialized
INFO - 2017-09-07 08:40:07 --> Output Class Initialized
INFO - 2017-09-07 08:40:07 --> Security Class Initialized
DEBUG - 2017-09-07 08:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 08:40:07 --> Input Class Initialized
INFO - 2017-09-07 08:40:07 --> Language Class Initialized
INFO - 2017-09-07 08:40:07 --> Loader Class Initialized
INFO - 2017-09-07 08:40:07 --> Helper loaded: url_helper
INFO - 2017-09-07 08:40:07 --> Database Driver Class Initialized
INFO - 2017-09-07 08:40:07 --> Email Class Initialized
INFO - 2017-09-07 08:40:07 --> Controller Class Initialized
DEBUG - 2017-09-07 08:40:07 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 08:40:07 --> Helper loaded: inflector_helper
INFO - 2017-09-07 08:40:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 08:40:07 --> Helper loaded: log_helper
INFO - 2017-09-07 08:40:07 --> Model Class Initialized
INFO - 2017-09-07 15:40:07 --> Final output sent to browser
DEBUG - 2017-09-07 15:40:07 --> Total execution time: 0.0712
INFO - 2017-09-07 08:40:19 --> Config Class Initialized
INFO - 2017-09-07 08:40:19 --> Hooks Class Initialized
DEBUG - 2017-09-07 08:40:19 --> UTF-8 Support Enabled
INFO - 2017-09-07 08:40:19 --> Utf8 Class Initialized
INFO - 2017-09-07 08:40:19 --> URI Class Initialized
INFO - 2017-09-07 08:40:19 --> Router Class Initialized
INFO - 2017-09-07 08:40:19 --> Output Class Initialized
INFO - 2017-09-07 08:40:19 --> Security Class Initialized
DEBUG - 2017-09-07 08:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 08:40:19 --> Input Class Initialized
INFO - 2017-09-07 08:40:19 --> Language Class Initialized
INFO - 2017-09-07 08:40:19 --> Loader Class Initialized
INFO - 2017-09-07 08:40:19 --> Helper loaded: url_helper
INFO - 2017-09-07 08:40:19 --> Database Driver Class Initialized
INFO - 2017-09-07 08:40:19 --> Email Class Initialized
INFO - 2017-09-07 08:40:19 --> Controller Class Initialized
DEBUG - 2017-09-07 08:40:19 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 08:40:19 --> Helper loaded: inflector_helper
INFO - 2017-09-07 08:40:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 08:40:19 --> Helper loaded: log_helper
INFO - 2017-09-07 08:40:19 --> Model Class Initialized
INFO - 2017-09-07 15:40:19 --> Final output sent to browser
DEBUG - 2017-09-07 15:40:19 --> Total execution time: 0.1320
INFO - 2017-09-07 08:40:35 --> Config Class Initialized
INFO - 2017-09-07 08:40:35 --> Hooks Class Initialized
DEBUG - 2017-09-07 08:40:35 --> UTF-8 Support Enabled
INFO - 2017-09-07 08:40:35 --> Utf8 Class Initialized
INFO - 2017-09-07 08:40:35 --> URI Class Initialized
INFO - 2017-09-07 08:40:35 --> Router Class Initialized
INFO - 2017-09-07 08:40:35 --> Output Class Initialized
INFO - 2017-09-07 08:40:35 --> Security Class Initialized
DEBUG - 2017-09-07 08:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 08:40:35 --> Input Class Initialized
INFO - 2017-09-07 08:40:35 --> Language Class Initialized
INFO - 2017-09-07 08:40:35 --> Loader Class Initialized
INFO - 2017-09-07 08:40:35 --> Helper loaded: url_helper
INFO - 2017-09-07 08:40:35 --> Database Driver Class Initialized
INFO - 2017-09-07 08:40:35 --> Email Class Initialized
INFO - 2017-09-07 08:40:35 --> Controller Class Initialized
DEBUG - 2017-09-07 08:40:35 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 08:40:35 --> Helper loaded: inflector_helper
INFO - 2017-09-07 08:40:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 08:40:35 --> Helper loaded: log_helper
INFO - 2017-09-07 08:40:35 --> Model Class Initialized
ERROR - 2017-09-07 15:40:35 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\franknco\application\models\api_model.php 379
INFO - 2017-09-07 15:40:35 --> Final output sent to browser
DEBUG - 2017-09-07 15:40:35 --> Total execution time: 0.0611
INFO - 2017-09-07 08:40:39 --> Config Class Initialized
INFO - 2017-09-07 08:40:39 --> Hooks Class Initialized
DEBUG - 2017-09-07 08:40:39 --> UTF-8 Support Enabled
INFO - 2017-09-07 08:40:39 --> Utf8 Class Initialized
INFO - 2017-09-07 08:40:39 --> URI Class Initialized
INFO - 2017-09-07 08:40:39 --> Router Class Initialized
INFO - 2017-09-07 08:40:39 --> Output Class Initialized
INFO - 2017-09-07 08:40:39 --> Security Class Initialized
DEBUG - 2017-09-07 08:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 08:40:39 --> Input Class Initialized
INFO - 2017-09-07 08:40:39 --> Language Class Initialized
INFO - 2017-09-07 08:40:39 --> Loader Class Initialized
INFO - 2017-09-07 08:40:39 --> Helper loaded: url_helper
INFO - 2017-09-07 08:40:39 --> Database Driver Class Initialized
INFO - 2017-09-07 08:40:39 --> Email Class Initialized
INFO - 2017-09-07 08:40:39 --> Controller Class Initialized
DEBUG - 2017-09-07 08:40:39 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 08:40:39 --> Helper loaded: inflector_helper
INFO - 2017-09-07 08:40:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 08:40:39 --> Helper loaded: log_helper
INFO - 2017-09-07 08:40:39 --> Model Class Initialized
INFO - 2017-09-07 15:40:39 --> Final output sent to browser
DEBUG - 2017-09-07 15:40:39 --> Total execution time: 0.1627
INFO - 2017-09-07 08:40:43 --> Config Class Initialized
INFO - 2017-09-07 08:40:43 --> Hooks Class Initialized
DEBUG - 2017-09-07 08:40:43 --> UTF-8 Support Enabled
INFO - 2017-09-07 08:40:43 --> Utf8 Class Initialized
INFO - 2017-09-07 08:40:43 --> URI Class Initialized
INFO - 2017-09-07 08:40:43 --> Router Class Initialized
INFO - 2017-09-07 08:40:43 --> Output Class Initialized
INFO - 2017-09-07 08:40:43 --> Security Class Initialized
DEBUG - 2017-09-07 08:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 08:40:43 --> Input Class Initialized
INFO - 2017-09-07 08:40:43 --> Language Class Initialized
INFO - 2017-09-07 08:40:43 --> Loader Class Initialized
INFO - 2017-09-07 08:40:43 --> Helper loaded: url_helper
INFO - 2017-09-07 08:40:43 --> Database Driver Class Initialized
INFO - 2017-09-07 08:40:43 --> Email Class Initialized
INFO - 2017-09-07 08:40:43 --> Controller Class Initialized
DEBUG - 2017-09-07 08:40:43 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 08:40:43 --> Helper loaded: inflector_helper
INFO - 2017-09-07 08:40:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 08:40:43 --> Helper loaded: log_helper
INFO - 2017-09-07 08:40:43 --> Model Class Initialized
ERROR - 2017-09-07 15:40:43 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\franknco\application\models\api_model.php 379
INFO - 2017-09-07 15:40:43 --> Final output sent to browser
DEBUG - 2017-09-07 15:40:43 --> Total execution time: 0.0713
INFO - 2017-09-07 08:41:13 --> Config Class Initialized
INFO - 2017-09-07 08:41:13 --> Hooks Class Initialized
DEBUG - 2017-09-07 08:41:13 --> UTF-8 Support Enabled
INFO - 2017-09-07 08:41:13 --> Utf8 Class Initialized
INFO - 2017-09-07 08:41:13 --> URI Class Initialized
INFO - 2017-09-07 08:41:13 --> Router Class Initialized
INFO - 2017-09-07 08:41:13 --> Output Class Initialized
INFO - 2017-09-07 08:41:13 --> Security Class Initialized
DEBUG - 2017-09-07 08:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 08:41:13 --> Input Class Initialized
INFO - 2017-09-07 08:41:13 --> Language Class Initialized
INFO - 2017-09-07 08:41:13 --> Loader Class Initialized
INFO - 2017-09-07 08:41:13 --> Helper loaded: url_helper
INFO - 2017-09-07 08:41:13 --> Database Driver Class Initialized
INFO - 2017-09-07 08:41:13 --> Email Class Initialized
INFO - 2017-09-07 08:41:13 --> Controller Class Initialized
DEBUG - 2017-09-07 08:41:13 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 08:41:13 --> Helper loaded: inflector_helper
INFO - 2017-09-07 08:41:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 08:41:13 --> Helper loaded: log_helper
INFO - 2017-09-07 08:41:13 --> Model Class Initialized
INFO - 2017-09-07 08:41:48 --> Config Class Initialized
INFO - 2017-09-07 08:41:48 --> Hooks Class Initialized
DEBUG - 2017-09-07 08:41:48 --> UTF-8 Support Enabled
INFO - 2017-09-07 08:41:48 --> Utf8 Class Initialized
INFO - 2017-09-07 08:41:48 --> URI Class Initialized
INFO - 2017-09-07 08:41:48 --> Router Class Initialized
INFO - 2017-09-07 08:41:48 --> Output Class Initialized
INFO - 2017-09-07 08:41:48 --> Security Class Initialized
DEBUG - 2017-09-07 08:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 08:41:48 --> Input Class Initialized
INFO - 2017-09-07 08:41:48 --> Language Class Initialized
INFO - 2017-09-07 08:41:48 --> Loader Class Initialized
INFO - 2017-09-07 08:41:48 --> Helper loaded: url_helper
INFO - 2017-09-07 08:41:48 --> Database Driver Class Initialized
INFO - 2017-09-07 08:41:48 --> Email Class Initialized
INFO - 2017-09-07 08:41:48 --> Controller Class Initialized
DEBUG - 2017-09-07 08:41:48 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 08:41:48 --> Helper loaded: inflector_helper
INFO - 2017-09-07 08:41:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 08:41:48 --> Helper loaded: log_helper
INFO - 2017-09-07 08:41:48 --> Model Class Initialized
INFO - 2017-09-07 08:45:00 --> Config Class Initialized
INFO - 2017-09-07 08:45:00 --> Hooks Class Initialized
DEBUG - 2017-09-07 08:45:00 --> UTF-8 Support Enabled
INFO - 2017-09-07 08:45:00 --> Utf8 Class Initialized
INFO - 2017-09-07 08:45:00 --> URI Class Initialized
INFO - 2017-09-07 08:45:00 --> Router Class Initialized
INFO - 2017-09-07 08:45:00 --> Output Class Initialized
INFO - 2017-09-07 08:45:00 --> Security Class Initialized
DEBUG - 2017-09-07 08:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 08:45:00 --> Input Class Initialized
INFO - 2017-09-07 08:45:00 --> Language Class Initialized
INFO - 2017-09-07 08:45:00 --> Loader Class Initialized
INFO - 2017-09-07 08:45:00 --> Helper loaded: url_helper
INFO - 2017-09-07 08:45:00 --> Database Driver Class Initialized
INFO - 2017-09-07 08:45:00 --> Email Class Initialized
INFO - 2017-09-07 08:45:00 --> Controller Class Initialized
DEBUG - 2017-09-07 08:45:00 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 08:45:00 --> Helper loaded: inflector_helper
INFO - 2017-09-07 08:45:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 08:45:00 --> Helper loaded: log_helper
INFO - 2017-09-07 08:45:00 --> Model Class Initialized
INFO - 2017-09-07 08:45:43 --> Config Class Initialized
INFO - 2017-09-07 08:45:43 --> Hooks Class Initialized
DEBUG - 2017-09-07 08:45:43 --> UTF-8 Support Enabled
INFO - 2017-09-07 08:45:43 --> Utf8 Class Initialized
INFO - 2017-09-07 08:45:43 --> URI Class Initialized
INFO - 2017-09-07 08:45:43 --> Router Class Initialized
INFO - 2017-09-07 08:45:43 --> Output Class Initialized
INFO - 2017-09-07 08:45:43 --> Security Class Initialized
DEBUG - 2017-09-07 08:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 08:45:43 --> Input Class Initialized
INFO - 2017-09-07 08:45:43 --> Language Class Initialized
ERROR - 2017-09-07 08:45:43 --> Severity: Parsing Error --> syntax error, unexpected 'print_r' (T_STRING), expecting case (T_CASE) or default (T_DEFAULT) or '}' C:\wamp64\www\franknco\application\controllers\api\franknco_api.php 42
INFO - 2017-09-07 08:45:54 --> Config Class Initialized
INFO - 2017-09-07 08:45:54 --> Hooks Class Initialized
DEBUG - 2017-09-07 08:45:54 --> UTF-8 Support Enabled
INFO - 2017-09-07 08:45:54 --> Utf8 Class Initialized
INFO - 2017-09-07 08:45:54 --> URI Class Initialized
INFO - 2017-09-07 08:45:54 --> Router Class Initialized
INFO - 2017-09-07 08:45:54 --> Output Class Initialized
INFO - 2017-09-07 08:45:54 --> Security Class Initialized
DEBUG - 2017-09-07 08:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 08:45:54 --> Input Class Initialized
INFO - 2017-09-07 08:45:54 --> Language Class Initialized
INFO - 2017-09-07 08:45:54 --> Loader Class Initialized
INFO - 2017-09-07 08:45:54 --> Helper loaded: url_helper
INFO - 2017-09-07 08:45:54 --> Database Driver Class Initialized
INFO - 2017-09-07 08:45:54 --> Email Class Initialized
INFO - 2017-09-07 08:45:54 --> Controller Class Initialized
DEBUG - 2017-09-07 08:45:54 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 08:45:54 --> Helper loaded: inflector_helper
INFO - 2017-09-07 08:45:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 08:45:54 --> Helper loaded: log_helper
INFO - 2017-09-07 08:45:54 --> Model Class Initialized
INFO - 2017-09-07 08:46:18 --> Config Class Initialized
INFO - 2017-09-07 08:46:18 --> Hooks Class Initialized
DEBUG - 2017-09-07 08:46:18 --> UTF-8 Support Enabled
INFO - 2017-09-07 08:46:18 --> Utf8 Class Initialized
INFO - 2017-09-07 08:46:18 --> URI Class Initialized
INFO - 2017-09-07 08:46:18 --> Router Class Initialized
INFO - 2017-09-07 08:46:18 --> Output Class Initialized
INFO - 2017-09-07 08:46:18 --> Security Class Initialized
DEBUG - 2017-09-07 08:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 08:46:18 --> Input Class Initialized
INFO - 2017-09-07 08:46:18 --> Language Class Initialized
INFO - 2017-09-07 08:46:18 --> Loader Class Initialized
INFO - 2017-09-07 08:46:18 --> Helper loaded: url_helper
INFO - 2017-09-07 08:46:18 --> Database Driver Class Initialized
INFO - 2017-09-07 08:46:18 --> Email Class Initialized
INFO - 2017-09-07 08:46:18 --> Controller Class Initialized
DEBUG - 2017-09-07 08:46:18 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 08:46:18 --> Helper loaded: inflector_helper
INFO - 2017-09-07 08:46:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 08:46:18 --> Helper loaded: log_helper
INFO - 2017-09-07 08:46:18 --> Model Class Initialized
INFO - 2017-09-07 08:46:35 --> Config Class Initialized
INFO - 2017-09-07 08:46:35 --> Hooks Class Initialized
DEBUG - 2017-09-07 08:46:35 --> UTF-8 Support Enabled
INFO - 2017-09-07 08:46:35 --> Utf8 Class Initialized
INFO - 2017-09-07 08:46:35 --> URI Class Initialized
INFO - 2017-09-07 08:46:35 --> Router Class Initialized
INFO - 2017-09-07 08:46:35 --> Output Class Initialized
INFO - 2017-09-07 08:46:35 --> Security Class Initialized
DEBUG - 2017-09-07 08:46:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 08:46:35 --> Input Class Initialized
INFO - 2017-09-07 08:46:35 --> Language Class Initialized
INFO - 2017-09-07 08:46:35 --> Loader Class Initialized
INFO - 2017-09-07 08:46:35 --> Helper loaded: url_helper
INFO - 2017-09-07 08:46:35 --> Database Driver Class Initialized
INFO - 2017-09-07 08:46:35 --> Email Class Initialized
INFO - 2017-09-07 08:46:35 --> Controller Class Initialized
DEBUG - 2017-09-07 08:46:35 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 08:46:35 --> Helper loaded: inflector_helper
INFO - 2017-09-07 08:46:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 08:46:35 --> Helper loaded: log_helper
INFO - 2017-09-07 08:46:35 --> Model Class Initialized
INFO - 2017-09-07 08:46:37 --> Config Class Initialized
INFO - 2017-09-07 08:46:37 --> Hooks Class Initialized
DEBUG - 2017-09-07 08:46:37 --> UTF-8 Support Enabled
INFO - 2017-09-07 08:46:37 --> Utf8 Class Initialized
INFO - 2017-09-07 08:46:37 --> URI Class Initialized
INFO - 2017-09-07 08:46:37 --> Router Class Initialized
INFO - 2017-09-07 08:46:37 --> Output Class Initialized
INFO - 2017-09-07 08:46:37 --> Security Class Initialized
DEBUG - 2017-09-07 08:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 08:46:37 --> Input Class Initialized
INFO - 2017-09-07 08:46:37 --> Language Class Initialized
INFO - 2017-09-07 08:46:37 --> Loader Class Initialized
INFO - 2017-09-07 08:46:37 --> Helper loaded: url_helper
INFO - 2017-09-07 08:46:37 --> Database Driver Class Initialized
INFO - 2017-09-07 08:46:37 --> Email Class Initialized
INFO - 2017-09-07 08:46:37 --> Controller Class Initialized
DEBUG - 2017-09-07 08:46:37 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 08:46:37 --> Helper loaded: inflector_helper
INFO - 2017-09-07 08:46:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 08:46:37 --> Helper loaded: log_helper
INFO - 2017-09-07 08:46:37 --> Model Class Initialized
INFO - 2017-09-07 08:49:08 --> Config Class Initialized
INFO - 2017-09-07 08:49:08 --> Hooks Class Initialized
DEBUG - 2017-09-07 08:49:08 --> UTF-8 Support Enabled
INFO - 2017-09-07 08:49:08 --> Utf8 Class Initialized
INFO - 2017-09-07 08:49:08 --> URI Class Initialized
INFO - 2017-09-07 08:49:08 --> Router Class Initialized
INFO - 2017-09-07 08:49:08 --> Output Class Initialized
INFO - 2017-09-07 08:49:08 --> Security Class Initialized
DEBUG - 2017-09-07 08:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 08:49:08 --> Input Class Initialized
INFO - 2017-09-07 08:49:08 --> Language Class Initialized
INFO - 2017-09-07 08:49:08 --> Loader Class Initialized
INFO - 2017-09-07 08:49:08 --> Helper loaded: url_helper
INFO - 2017-09-07 08:49:08 --> Database Driver Class Initialized
INFO - 2017-09-07 08:49:08 --> Email Class Initialized
INFO - 2017-09-07 08:49:08 --> Controller Class Initialized
DEBUG - 2017-09-07 08:49:08 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 08:49:08 --> Helper loaded: inflector_helper
INFO - 2017-09-07 08:49:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 08:49:08 --> Helper loaded: log_helper
INFO - 2017-09-07 08:49:08 --> Model Class Initialized
INFO - 2017-09-07 15:49:08 --> Final output sent to browser
DEBUG - 2017-09-07 15:49:08 --> Total execution time: 0.0934
INFO - 2017-09-07 08:49:13 --> Config Class Initialized
INFO - 2017-09-07 08:49:13 --> Hooks Class Initialized
DEBUG - 2017-09-07 08:49:13 --> UTF-8 Support Enabled
INFO - 2017-09-07 08:49:13 --> Utf8 Class Initialized
INFO - 2017-09-07 08:49:13 --> URI Class Initialized
INFO - 2017-09-07 08:49:13 --> Router Class Initialized
INFO - 2017-09-07 08:49:13 --> Output Class Initialized
INFO - 2017-09-07 08:49:13 --> Security Class Initialized
DEBUG - 2017-09-07 08:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 08:49:13 --> Input Class Initialized
INFO - 2017-09-07 08:49:13 --> Language Class Initialized
INFO - 2017-09-07 08:49:13 --> Loader Class Initialized
INFO - 2017-09-07 08:49:13 --> Helper loaded: url_helper
INFO - 2017-09-07 08:49:13 --> Database Driver Class Initialized
INFO - 2017-09-07 08:49:13 --> Email Class Initialized
INFO - 2017-09-07 08:49:13 --> Controller Class Initialized
DEBUG - 2017-09-07 08:49:13 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 08:49:13 --> Helper loaded: inflector_helper
INFO - 2017-09-07 08:49:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 08:49:13 --> Helper loaded: log_helper
INFO - 2017-09-07 08:49:13 --> Model Class Initialized
INFO - 2017-09-07 15:49:13 --> Final output sent to browser
DEBUG - 2017-09-07 15:49:13 --> Total execution time: 0.0739
INFO - 2017-09-07 08:49:49 --> Config Class Initialized
INFO - 2017-09-07 08:49:49 --> Hooks Class Initialized
DEBUG - 2017-09-07 08:49:49 --> UTF-8 Support Enabled
INFO - 2017-09-07 08:49:49 --> Utf8 Class Initialized
INFO - 2017-09-07 08:49:49 --> URI Class Initialized
INFO - 2017-09-07 08:49:49 --> Router Class Initialized
INFO - 2017-09-07 08:49:49 --> Output Class Initialized
INFO - 2017-09-07 08:49:49 --> Security Class Initialized
DEBUG - 2017-09-07 08:49:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 08:49:49 --> Input Class Initialized
INFO - 2017-09-07 08:49:49 --> Language Class Initialized
INFO - 2017-09-07 08:49:49 --> Loader Class Initialized
INFO - 2017-09-07 08:49:49 --> Helper loaded: url_helper
INFO - 2017-09-07 08:49:49 --> Database Driver Class Initialized
INFO - 2017-09-07 08:49:49 --> Email Class Initialized
INFO - 2017-09-07 08:49:49 --> Controller Class Initialized
DEBUG - 2017-09-07 08:49:49 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 08:49:49 --> Helper loaded: inflector_helper
INFO - 2017-09-07 08:49:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 08:49:49 --> Helper loaded: log_helper
INFO - 2017-09-07 08:49:49 --> Model Class Initialized
INFO - 2017-09-07 15:49:49 --> Final output sent to browser
DEBUG - 2017-09-07 15:49:49 --> Total execution time: 0.0823
INFO - 2017-09-07 08:50:46 --> Config Class Initialized
INFO - 2017-09-07 08:50:46 --> Hooks Class Initialized
DEBUG - 2017-09-07 08:50:46 --> UTF-8 Support Enabled
INFO - 2017-09-07 08:50:46 --> Utf8 Class Initialized
INFO - 2017-09-07 08:50:46 --> URI Class Initialized
INFO - 2017-09-07 08:50:46 --> Router Class Initialized
INFO - 2017-09-07 08:50:46 --> Output Class Initialized
INFO - 2017-09-07 08:50:46 --> Security Class Initialized
DEBUG - 2017-09-07 08:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 08:50:46 --> Input Class Initialized
INFO - 2017-09-07 08:50:46 --> Language Class Initialized
INFO - 2017-09-07 08:50:46 --> Loader Class Initialized
INFO - 2017-09-07 08:50:46 --> Helper loaded: url_helper
INFO - 2017-09-07 08:50:46 --> Database Driver Class Initialized
INFO - 2017-09-07 08:50:46 --> Email Class Initialized
INFO - 2017-09-07 08:50:46 --> Controller Class Initialized
DEBUG - 2017-09-07 08:50:46 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 08:50:46 --> Helper loaded: inflector_helper
INFO - 2017-09-07 08:50:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 08:50:46 --> Helper loaded: log_helper
INFO - 2017-09-07 08:50:46 --> Model Class Initialized
INFO - 2017-09-07 15:50:46 --> Final output sent to browser
DEBUG - 2017-09-07 15:50:46 --> Total execution time: 0.1838
INFO - 2017-09-07 08:50:55 --> Config Class Initialized
INFO - 2017-09-07 08:50:55 --> Hooks Class Initialized
DEBUG - 2017-09-07 08:50:55 --> UTF-8 Support Enabled
INFO - 2017-09-07 08:50:55 --> Utf8 Class Initialized
INFO - 2017-09-07 08:50:55 --> URI Class Initialized
INFO - 2017-09-07 08:50:55 --> Router Class Initialized
INFO - 2017-09-07 08:50:55 --> Output Class Initialized
INFO - 2017-09-07 08:50:55 --> Security Class Initialized
DEBUG - 2017-09-07 08:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 08:50:55 --> Input Class Initialized
INFO - 2017-09-07 08:50:55 --> Language Class Initialized
INFO - 2017-09-07 08:50:55 --> Loader Class Initialized
INFO - 2017-09-07 08:50:55 --> Helper loaded: url_helper
INFO - 2017-09-07 08:50:55 --> Database Driver Class Initialized
INFO - 2017-09-07 08:50:55 --> Email Class Initialized
INFO - 2017-09-07 08:50:55 --> Controller Class Initialized
DEBUG - 2017-09-07 08:50:55 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 08:50:55 --> Helper loaded: inflector_helper
INFO - 2017-09-07 08:50:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 08:50:55 --> Helper loaded: log_helper
INFO - 2017-09-07 08:50:55 --> Model Class Initialized
INFO - 2017-09-07 15:50:55 --> Final output sent to browser
DEBUG - 2017-09-07 15:50:55 --> Total execution time: 0.0684
INFO - 2017-09-07 08:50:59 --> Config Class Initialized
INFO - 2017-09-07 08:50:59 --> Hooks Class Initialized
DEBUG - 2017-09-07 08:50:59 --> UTF-8 Support Enabled
INFO - 2017-09-07 08:50:59 --> Utf8 Class Initialized
INFO - 2017-09-07 08:50:59 --> URI Class Initialized
INFO - 2017-09-07 08:50:59 --> Router Class Initialized
INFO - 2017-09-07 08:50:59 --> Output Class Initialized
INFO - 2017-09-07 08:50:59 --> Security Class Initialized
DEBUG - 2017-09-07 08:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 08:50:59 --> Input Class Initialized
INFO - 2017-09-07 08:50:59 --> Language Class Initialized
INFO - 2017-09-07 08:50:59 --> Loader Class Initialized
INFO - 2017-09-07 08:50:59 --> Helper loaded: url_helper
INFO - 2017-09-07 08:50:59 --> Database Driver Class Initialized
INFO - 2017-09-07 08:50:59 --> Email Class Initialized
INFO - 2017-09-07 08:50:59 --> Controller Class Initialized
DEBUG - 2017-09-07 08:50:59 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 08:50:59 --> Helper loaded: inflector_helper
INFO - 2017-09-07 08:50:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 08:50:59 --> Helper loaded: log_helper
INFO - 2017-09-07 08:50:59 --> Model Class Initialized
INFO - 2017-09-07 15:50:59 --> Final output sent to browser
DEBUG - 2017-09-07 15:50:59 --> Total execution time: 0.0705
INFO - 2017-09-07 08:51:08 --> Config Class Initialized
INFO - 2017-09-07 08:51:08 --> Hooks Class Initialized
DEBUG - 2017-09-07 08:51:09 --> UTF-8 Support Enabled
INFO - 2017-09-07 08:51:09 --> Utf8 Class Initialized
INFO - 2017-09-07 08:51:09 --> URI Class Initialized
INFO - 2017-09-07 08:51:09 --> Router Class Initialized
INFO - 2017-09-07 08:51:09 --> Output Class Initialized
INFO - 2017-09-07 08:51:09 --> Security Class Initialized
DEBUG - 2017-09-07 08:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 08:51:09 --> Input Class Initialized
INFO - 2017-09-07 08:51:09 --> Language Class Initialized
INFO - 2017-09-07 08:51:09 --> Loader Class Initialized
INFO - 2017-09-07 08:51:09 --> Helper loaded: url_helper
INFO - 2017-09-07 08:51:09 --> Database Driver Class Initialized
INFO - 2017-09-07 08:51:09 --> Email Class Initialized
INFO - 2017-09-07 08:51:09 --> Controller Class Initialized
DEBUG - 2017-09-07 08:51:09 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 08:51:09 --> Helper loaded: inflector_helper
INFO - 2017-09-07 08:51:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 08:51:09 --> Helper loaded: log_helper
INFO - 2017-09-07 08:51:09 --> Model Class Initialized
INFO - 2017-09-07 15:51:09 --> Final output sent to browser
DEBUG - 2017-09-07 15:51:09 --> Total execution time: 0.0952
INFO - 2017-09-07 08:51:58 --> Config Class Initialized
INFO - 2017-09-07 08:51:58 --> Hooks Class Initialized
DEBUG - 2017-09-07 08:51:58 --> UTF-8 Support Enabled
INFO - 2017-09-07 08:51:58 --> Utf8 Class Initialized
INFO - 2017-09-07 08:51:58 --> URI Class Initialized
INFO - 2017-09-07 08:51:58 --> Router Class Initialized
INFO - 2017-09-07 08:51:58 --> Output Class Initialized
INFO - 2017-09-07 08:51:58 --> Security Class Initialized
DEBUG - 2017-09-07 08:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 08:51:58 --> Input Class Initialized
INFO - 2017-09-07 08:51:58 --> Language Class Initialized
INFO - 2017-09-07 08:51:58 --> Loader Class Initialized
INFO - 2017-09-07 08:51:58 --> Helper loaded: url_helper
INFO - 2017-09-07 08:51:58 --> Database Driver Class Initialized
INFO - 2017-09-07 08:51:58 --> Email Class Initialized
INFO - 2017-09-07 08:51:58 --> Controller Class Initialized
DEBUG - 2017-09-07 08:51:58 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 08:51:58 --> Helper loaded: inflector_helper
INFO - 2017-09-07 08:51:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 08:51:58 --> Helper loaded: log_helper
INFO - 2017-09-07 08:51:58 --> Model Class Initialized
INFO - 2017-09-07 15:51:58 --> Final output sent to browser
DEBUG - 2017-09-07 15:51:58 --> Total execution time: 0.0706
INFO - 2017-09-07 08:52:15 --> Config Class Initialized
INFO - 2017-09-07 08:52:15 --> Hooks Class Initialized
DEBUG - 2017-09-07 08:52:15 --> UTF-8 Support Enabled
INFO - 2017-09-07 08:52:15 --> Utf8 Class Initialized
INFO - 2017-09-07 08:52:15 --> URI Class Initialized
INFO - 2017-09-07 08:52:15 --> Router Class Initialized
INFO - 2017-09-07 08:52:15 --> Output Class Initialized
INFO - 2017-09-07 08:52:15 --> Security Class Initialized
DEBUG - 2017-09-07 08:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 08:52:15 --> Input Class Initialized
INFO - 2017-09-07 08:52:15 --> Language Class Initialized
INFO - 2017-09-07 08:52:15 --> Loader Class Initialized
INFO - 2017-09-07 08:52:15 --> Helper loaded: url_helper
INFO - 2017-09-07 08:52:15 --> Database Driver Class Initialized
INFO - 2017-09-07 08:52:15 --> Email Class Initialized
INFO - 2017-09-07 08:52:15 --> Controller Class Initialized
DEBUG - 2017-09-07 08:52:15 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 08:52:15 --> Helper loaded: inflector_helper
INFO - 2017-09-07 08:52:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 08:52:15 --> Helper loaded: log_helper
INFO - 2017-09-07 08:52:15 --> Model Class Initialized
INFO - 2017-09-07 15:52:15 --> Final output sent to browser
DEBUG - 2017-09-07 15:52:15 --> Total execution time: 0.0949
INFO - 2017-09-07 08:52:35 --> Config Class Initialized
INFO - 2017-09-07 08:52:35 --> Hooks Class Initialized
DEBUG - 2017-09-07 08:52:35 --> UTF-8 Support Enabled
INFO - 2017-09-07 08:52:35 --> Utf8 Class Initialized
INFO - 2017-09-07 08:52:35 --> URI Class Initialized
INFO - 2017-09-07 08:52:35 --> Router Class Initialized
INFO - 2017-09-07 08:52:35 --> Output Class Initialized
INFO - 2017-09-07 08:52:35 --> Security Class Initialized
DEBUG - 2017-09-07 08:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 08:52:35 --> Input Class Initialized
INFO - 2017-09-07 08:52:35 --> Language Class Initialized
INFO - 2017-09-07 08:52:35 --> Loader Class Initialized
INFO - 2017-09-07 08:52:35 --> Helper loaded: url_helper
INFO - 2017-09-07 08:52:35 --> Database Driver Class Initialized
INFO - 2017-09-07 08:52:35 --> Email Class Initialized
INFO - 2017-09-07 08:52:35 --> Controller Class Initialized
DEBUG - 2017-09-07 08:52:35 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 08:52:35 --> Helper loaded: inflector_helper
INFO - 2017-09-07 08:52:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 08:52:35 --> Helper loaded: log_helper
INFO - 2017-09-07 08:52:35 --> Model Class Initialized
INFO - 2017-09-07 08:53:03 --> Config Class Initialized
INFO - 2017-09-07 08:53:03 --> Hooks Class Initialized
DEBUG - 2017-09-07 08:53:03 --> UTF-8 Support Enabled
INFO - 2017-09-07 08:53:03 --> Utf8 Class Initialized
INFO - 2017-09-07 08:53:03 --> URI Class Initialized
INFO - 2017-09-07 08:53:03 --> Router Class Initialized
INFO - 2017-09-07 08:53:03 --> Output Class Initialized
INFO - 2017-09-07 08:53:03 --> Security Class Initialized
DEBUG - 2017-09-07 08:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 08:53:03 --> Input Class Initialized
INFO - 2017-09-07 08:53:03 --> Language Class Initialized
INFO - 2017-09-07 08:53:03 --> Loader Class Initialized
INFO - 2017-09-07 08:53:03 --> Helper loaded: url_helper
INFO - 2017-09-07 08:53:03 --> Database Driver Class Initialized
INFO - 2017-09-07 08:53:03 --> Email Class Initialized
INFO - 2017-09-07 08:53:03 --> Controller Class Initialized
DEBUG - 2017-09-07 08:53:03 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 08:53:03 --> Helper loaded: inflector_helper
INFO - 2017-09-07 08:53:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 08:53:03 --> Helper loaded: log_helper
INFO - 2017-09-07 08:53:03 --> Model Class Initialized
INFO - 2017-09-07 09:04:26 --> Config Class Initialized
INFO - 2017-09-07 09:04:26 --> Hooks Class Initialized
DEBUG - 2017-09-07 09:04:26 --> UTF-8 Support Enabled
INFO - 2017-09-07 09:04:26 --> Utf8 Class Initialized
INFO - 2017-09-07 09:04:26 --> URI Class Initialized
INFO - 2017-09-07 09:04:26 --> Router Class Initialized
INFO - 2017-09-07 09:04:26 --> Output Class Initialized
INFO - 2017-09-07 09:04:26 --> Security Class Initialized
DEBUG - 2017-09-07 09:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 09:04:26 --> Input Class Initialized
INFO - 2017-09-07 09:04:26 --> Language Class Initialized
INFO - 2017-09-07 09:04:26 --> Loader Class Initialized
INFO - 2017-09-07 09:04:26 --> Helper loaded: url_helper
INFO - 2017-09-07 09:04:26 --> Database Driver Class Initialized
INFO - 2017-09-07 09:04:26 --> Email Class Initialized
INFO - 2017-09-07 09:04:26 --> Controller Class Initialized
DEBUG - 2017-09-07 09:04:26 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 09:04:26 --> Helper loaded: inflector_helper
INFO - 2017-09-07 09:04:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 09:04:26 --> Helper loaded: log_helper
INFO - 2017-09-07 09:04:26 --> Model Class Initialized
INFO - 2017-09-07 09:05:08 --> Config Class Initialized
INFO - 2017-09-07 09:05:08 --> Hooks Class Initialized
DEBUG - 2017-09-07 09:05:08 --> UTF-8 Support Enabled
INFO - 2017-09-07 09:05:08 --> Utf8 Class Initialized
INFO - 2017-09-07 09:05:08 --> URI Class Initialized
INFO - 2017-09-07 09:05:08 --> Router Class Initialized
INFO - 2017-09-07 09:05:08 --> Output Class Initialized
INFO - 2017-09-07 09:05:08 --> Security Class Initialized
DEBUG - 2017-09-07 09:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 09:05:08 --> Input Class Initialized
INFO - 2017-09-07 09:05:08 --> Language Class Initialized
INFO - 2017-09-07 09:05:08 --> Loader Class Initialized
INFO - 2017-09-07 09:05:08 --> Helper loaded: url_helper
INFO - 2017-09-07 09:05:08 --> Database Driver Class Initialized
INFO - 2017-09-07 09:05:08 --> Email Class Initialized
INFO - 2017-09-07 09:05:08 --> Controller Class Initialized
DEBUG - 2017-09-07 09:05:08 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 09:05:08 --> Helper loaded: inflector_helper
INFO - 2017-09-07 09:05:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 09:05:08 --> Helper loaded: log_helper
INFO - 2017-09-07 09:05:08 --> Model Class Initialized
INFO - 2017-09-07 09:06:24 --> Config Class Initialized
INFO - 2017-09-07 09:06:24 --> Hooks Class Initialized
DEBUG - 2017-09-07 09:06:24 --> UTF-8 Support Enabled
INFO - 2017-09-07 09:06:24 --> Utf8 Class Initialized
INFO - 2017-09-07 09:06:24 --> URI Class Initialized
INFO - 2017-09-07 09:06:24 --> Router Class Initialized
INFO - 2017-09-07 09:06:24 --> Output Class Initialized
INFO - 2017-09-07 09:06:24 --> Security Class Initialized
DEBUG - 2017-09-07 09:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 09:06:24 --> Input Class Initialized
INFO - 2017-09-07 09:06:24 --> Language Class Initialized
INFO - 2017-09-07 09:06:24 --> Loader Class Initialized
INFO - 2017-09-07 09:06:24 --> Helper loaded: url_helper
INFO - 2017-09-07 09:06:24 --> Database Driver Class Initialized
INFO - 2017-09-07 09:06:24 --> Email Class Initialized
INFO - 2017-09-07 09:06:24 --> Controller Class Initialized
DEBUG - 2017-09-07 09:06:24 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 09:06:24 --> Helper loaded: inflector_helper
INFO - 2017-09-07 09:06:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 09:06:24 --> Helper loaded: log_helper
INFO - 2017-09-07 09:06:24 --> Model Class Initialized
INFO - 2017-09-07 09:06:31 --> Config Class Initialized
INFO - 2017-09-07 09:06:31 --> Hooks Class Initialized
DEBUG - 2017-09-07 09:06:31 --> UTF-8 Support Enabled
INFO - 2017-09-07 09:06:31 --> Utf8 Class Initialized
INFO - 2017-09-07 09:06:31 --> URI Class Initialized
INFO - 2017-09-07 09:06:31 --> Router Class Initialized
INFO - 2017-09-07 09:06:31 --> Output Class Initialized
INFO - 2017-09-07 09:06:31 --> Security Class Initialized
DEBUG - 2017-09-07 09:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 09:06:31 --> Input Class Initialized
INFO - 2017-09-07 09:06:31 --> Language Class Initialized
INFO - 2017-09-07 09:06:31 --> Loader Class Initialized
INFO - 2017-09-07 09:06:31 --> Helper loaded: url_helper
INFO - 2017-09-07 09:06:31 --> Database Driver Class Initialized
INFO - 2017-09-07 09:06:31 --> Email Class Initialized
INFO - 2017-09-07 09:06:31 --> Controller Class Initialized
DEBUG - 2017-09-07 09:06:31 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 09:06:31 --> Helper loaded: inflector_helper
INFO - 2017-09-07 09:06:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 09:06:31 --> Helper loaded: log_helper
INFO - 2017-09-07 09:06:31 --> Model Class Initialized
INFO - 2017-09-07 09:06:41 --> Config Class Initialized
INFO - 2017-09-07 09:06:41 --> Hooks Class Initialized
DEBUG - 2017-09-07 09:06:41 --> UTF-8 Support Enabled
INFO - 2017-09-07 09:06:41 --> Utf8 Class Initialized
INFO - 2017-09-07 09:06:41 --> URI Class Initialized
INFO - 2017-09-07 09:06:41 --> Router Class Initialized
INFO - 2017-09-07 09:06:41 --> Output Class Initialized
INFO - 2017-09-07 09:06:41 --> Security Class Initialized
DEBUG - 2017-09-07 09:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 09:06:41 --> Input Class Initialized
INFO - 2017-09-07 09:06:41 --> Language Class Initialized
INFO - 2017-09-07 09:06:41 --> Loader Class Initialized
INFO - 2017-09-07 09:06:41 --> Helper loaded: url_helper
INFO - 2017-09-07 09:06:41 --> Database Driver Class Initialized
INFO - 2017-09-07 09:06:41 --> Email Class Initialized
INFO - 2017-09-07 09:06:41 --> Controller Class Initialized
DEBUG - 2017-09-07 09:06:41 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 09:06:41 --> Helper loaded: inflector_helper
INFO - 2017-09-07 09:06:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 09:06:41 --> Helper loaded: log_helper
INFO - 2017-09-07 09:06:41 --> Model Class Initialized
INFO - 2017-09-07 09:09:02 --> Config Class Initialized
INFO - 2017-09-07 09:09:02 --> Hooks Class Initialized
DEBUG - 2017-09-07 09:09:02 --> UTF-8 Support Enabled
INFO - 2017-09-07 09:09:02 --> Utf8 Class Initialized
INFO - 2017-09-07 09:09:02 --> URI Class Initialized
INFO - 2017-09-07 09:09:02 --> Router Class Initialized
INFO - 2017-09-07 09:09:02 --> Output Class Initialized
INFO - 2017-09-07 09:09:02 --> Security Class Initialized
DEBUG - 2017-09-07 09:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 09:09:02 --> Input Class Initialized
INFO - 2017-09-07 09:09:02 --> Language Class Initialized
INFO - 2017-09-07 09:09:02 --> Loader Class Initialized
INFO - 2017-09-07 09:09:02 --> Helper loaded: url_helper
INFO - 2017-09-07 09:09:02 --> Database Driver Class Initialized
INFO - 2017-09-07 09:09:02 --> Email Class Initialized
INFO - 2017-09-07 09:09:02 --> Controller Class Initialized
DEBUG - 2017-09-07 09:09:02 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 09:09:02 --> Helper loaded: inflector_helper
INFO - 2017-09-07 09:09:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 09:09:02 --> Helper loaded: log_helper
INFO - 2017-09-07 09:09:02 --> Model Class Initialized
INFO - 2017-09-07 09:09:09 --> Config Class Initialized
INFO - 2017-09-07 09:09:09 --> Hooks Class Initialized
DEBUG - 2017-09-07 09:09:09 --> UTF-8 Support Enabled
INFO - 2017-09-07 09:09:09 --> Utf8 Class Initialized
INFO - 2017-09-07 09:09:09 --> URI Class Initialized
INFO - 2017-09-07 09:09:09 --> Router Class Initialized
INFO - 2017-09-07 09:09:09 --> Output Class Initialized
INFO - 2017-09-07 09:09:09 --> Security Class Initialized
DEBUG - 2017-09-07 09:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 09:09:09 --> Input Class Initialized
INFO - 2017-09-07 09:09:09 --> Language Class Initialized
INFO - 2017-09-07 09:09:09 --> Loader Class Initialized
INFO - 2017-09-07 09:09:09 --> Helper loaded: url_helper
INFO - 2017-09-07 09:09:09 --> Database Driver Class Initialized
INFO - 2017-09-07 09:09:09 --> Email Class Initialized
INFO - 2017-09-07 09:09:09 --> Controller Class Initialized
DEBUG - 2017-09-07 09:09:09 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 09:09:09 --> Helper loaded: inflector_helper
INFO - 2017-09-07 09:09:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 09:09:09 --> Helper loaded: log_helper
INFO - 2017-09-07 09:09:09 --> Model Class Initialized
INFO - 2017-09-07 16:09:09 --> Final output sent to browser
DEBUG - 2017-09-07 16:09:09 --> Total execution time: 0.0899
INFO - 2017-09-07 09:09:32 --> Config Class Initialized
INFO - 2017-09-07 09:09:32 --> Hooks Class Initialized
DEBUG - 2017-09-07 09:09:32 --> UTF-8 Support Enabled
INFO - 2017-09-07 09:09:32 --> Utf8 Class Initialized
INFO - 2017-09-07 09:09:32 --> URI Class Initialized
INFO - 2017-09-07 09:09:32 --> Router Class Initialized
INFO - 2017-09-07 09:09:32 --> Output Class Initialized
INFO - 2017-09-07 09:09:32 --> Security Class Initialized
DEBUG - 2017-09-07 09:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 09:09:32 --> Input Class Initialized
INFO - 2017-09-07 09:09:32 --> Language Class Initialized
INFO - 2017-09-07 09:09:32 --> Loader Class Initialized
INFO - 2017-09-07 09:09:32 --> Helper loaded: url_helper
INFO - 2017-09-07 09:09:32 --> Database Driver Class Initialized
INFO - 2017-09-07 09:09:32 --> Email Class Initialized
INFO - 2017-09-07 09:09:32 --> Controller Class Initialized
DEBUG - 2017-09-07 09:09:32 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 09:09:32 --> Helper loaded: inflector_helper
INFO - 2017-09-07 09:09:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 09:09:32 --> Helper loaded: log_helper
INFO - 2017-09-07 09:09:32 --> Model Class Initialized
INFO - 2017-09-07 09:09:44 --> Config Class Initialized
INFO - 2017-09-07 09:09:44 --> Hooks Class Initialized
DEBUG - 2017-09-07 09:09:44 --> UTF-8 Support Enabled
INFO - 2017-09-07 09:09:44 --> Utf8 Class Initialized
INFO - 2017-09-07 09:09:44 --> URI Class Initialized
INFO - 2017-09-07 09:09:44 --> Router Class Initialized
INFO - 2017-09-07 09:09:44 --> Output Class Initialized
INFO - 2017-09-07 09:09:44 --> Security Class Initialized
DEBUG - 2017-09-07 09:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 09:09:44 --> Input Class Initialized
INFO - 2017-09-07 09:09:44 --> Language Class Initialized
INFO - 2017-09-07 09:09:44 --> Loader Class Initialized
INFO - 2017-09-07 09:09:44 --> Helper loaded: url_helper
INFO - 2017-09-07 09:09:44 --> Database Driver Class Initialized
INFO - 2017-09-07 09:09:44 --> Email Class Initialized
INFO - 2017-09-07 09:09:44 --> Controller Class Initialized
DEBUG - 2017-09-07 09:09:44 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 09:09:44 --> Helper loaded: inflector_helper
INFO - 2017-09-07 09:09:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 09:09:44 --> Helper loaded: log_helper
INFO - 2017-09-07 09:09:44 --> Model Class Initialized
INFO - 2017-09-07 16:09:44 --> Final output sent to browser
DEBUG - 2017-09-07 16:09:44 --> Total execution time: 0.0580
INFO - 2017-09-07 09:10:09 --> Config Class Initialized
INFO - 2017-09-07 09:10:09 --> Hooks Class Initialized
DEBUG - 2017-09-07 09:10:09 --> UTF-8 Support Enabled
INFO - 2017-09-07 09:10:09 --> Utf8 Class Initialized
INFO - 2017-09-07 09:10:09 --> URI Class Initialized
INFO - 2017-09-07 09:10:09 --> Router Class Initialized
INFO - 2017-09-07 09:10:09 --> Output Class Initialized
INFO - 2017-09-07 09:10:09 --> Security Class Initialized
DEBUG - 2017-09-07 09:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 09:10:09 --> Input Class Initialized
INFO - 2017-09-07 09:10:09 --> Language Class Initialized
INFO - 2017-09-07 09:10:09 --> Loader Class Initialized
INFO - 2017-09-07 09:10:09 --> Helper loaded: url_helper
INFO - 2017-09-07 09:10:09 --> Database Driver Class Initialized
INFO - 2017-09-07 09:10:09 --> Email Class Initialized
INFO - 2017-09-07 09:10:09 --> Controller Class Initialized
DEBUG - 2017-09-07 09:10:09 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 09:10:09 --> Helper loaded: inflector_helper
INFO - 2017-09-07 09:10:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 09:10:09 --> Helper loaded: log_helper
INFO - 2017-09-07 09:10:09 --> Model Class Initialized
INFO - 2017-09-07 16:10:09 --> Final output sent to browser
DEBUG - 2017-09-07 16:10:09 --> Total execution time: 0.0560
INFO - 2017-09-07 09:10:40 --> Config Class Initialized
INFO - 2017-09-07 09:10:40 --> Hooks Class Initialized
DEBUG - 2017-09-07 09:10:40 --> UTF-8 Support Enabled
INFO - 2017-09-07 09:10:40 --> Utf8 Class Initialized
INFO - 2017-09-07 09:10:40 --> URI Class Initialized
INFO - 2017-09-07 09:10:40 --> Router Class Initialized
INFO - 2017-09-07 09:10:40 --> Output Class Initialized
INFO - 2017-09-07 09:10:40 --> Security Class Initialized
DEBUG - 2017-09-07 09:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 09:10:40 --> Input Class Initialized
INFO - 2017-09-07 09:10:40 --> Language Class Initialized
INFO - 2017-09-07 09:10:40 --> Loader Class Initialized
INFO - 2017-09-07 09:10:40 --> Helper loaded: url_helper
INFO - 2017-09-07 09:10:40 --> Database Driver Class Initialized
INFO - 2017-09-07 09:10:40 --> Email Class Initialized
INFO - 2017-09-07 09:10:40 --> Controller Class Initialized
DEBUG - 2017-09-07 09:10:40 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 09:10:40 --> Helper loaded: inflector_helper
INFO - 2017-09-07 09:10:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 09:10:40 --> Helper loaded: log_helper
INFO - 2017-09-07 09:10:40 --> Model Class Initialized
INFO - 2017-09-07 16:10:40 --> Final output sent to browser
DEBUG - 2017-09-07 16:10:40 --> Total execution time: 0.0703
INFO - 2017-09-07 09:11:06 --> Config Class Initialized
INFO - 2017-09-07 09:11:06 --> Hooks Class Initialized
DEBUG - 2017-09-07 09:11:06 --> UTF-8 Support Enabled
INFO - 2017-09-07 09:11:06 --> Utf8 Class Initialized
INFO - 2017-09-07 09:11:06 --> URI Class Initialized
INFO - 2017-09-07 09:11:06 --> Router Class Initialized
INFO - 2017-09-07 09:11:06 --> Output Class Initialized
INFO - 2017-09-07 09:11:06 --> Security Class Initialized
DEBUG - 2017-09-07 09:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 09:11:06 --> Input Class Initialized
INFO - 2017-09-07 09:11:06 --> Language Class Initialized
INFO - 2017-09-07 09:11:06 --> Loader Class Initialized
INFO - 2017-09-07 09:11:06 --> Helper loaded: url_helper
INFO - 2017-09-07 09:11:06 --> Database Driver Class Initialized
INFO - 2017-09-07 09:11:06 --> Email Class Initialized
INFO - 2017-09-07 09:11:06 --> Controller Class Initialized
DEBUG - 2017-09-07 09:11:06 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 09:11:06 --> Helper loaded: inflector_helper
INFO - 2017-09-07 09:11:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 09:11:06 --> Helper loaded: log_helper
INFO - 2017-09-07 09:11:06 --> Model Class Initialized
INFO - 2017-09-07 16:11:06 --> Final output sent to browser
DEBUG - 2017-09-07 16:11:06 --> Total execution time: 0.0719
INFO - 2017-09-07 09:11:23 --> Config Class Initialized
INFO - 2017-09-07 09:11:23 --> Hooks Class Initialized
DEBUG - 2017-09-07 09:11:23 --> UTF-8 Support Enabled
INFO - 2017-09-07 09:11:23 --> Utf8 Class Initialized
INFO - 2017-09-07 09:11:23 --> URI Class Initialized
INFO - 2017-09-07 09:11:23 --> Router Class Initialized
INFO - 2017-09-07 09:11:23 --> Output Class Initialized
INFO - 2017-09-07 09:11:23 --> Security Class Initialized
DEBUG - 2017-09-07 09:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 09:11:23 --> Input Class Initialized
INFO - 2017-09-07 09:11:23 --> Language Class Initialized
INFO - 2017-09-07 09:11:23 --> Loader Class Initialized
INFO - 2017-09-07 09:11:23 --> Helper loaded: url_helper
INFO - 2017-09-07 09:11:23 --> Database Driver Class Initialized
INFO - 2017-09-07 09:11:23 --> Email Class Initialized
INFO - 2017-09-07 09:11:23 --> Controller Class Initialized
DEBUG - 2017-09-07 09:11:23 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 09:11:23 --> Helper loaded: inflector_helper
INFO - 2017-09-07 09:11:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 09:11:23 --> Helper loaded: log_helper
INFO - 2017-09-07 09:11:23 --> Model Class Initialized
INFO - 2017-09-07 16:11:23 --> Final output sent to browser
DEBUG - 2017-09-07 16:11:23 --> Total execution time: 0.0531
INFO - 2017-09-07 09:11:43 --> Config Class Initialized
INFO - 2017-09-07 09:11:43 --> Hooks Class Initialized
DEBUG - 2017-09-07 09:11:43 --> UTF-8 Support Enabled
INFO - 2017-09-07 09:11:43 --> Utf8 Class Initialized
INFO - 2017-09-07 09:11:43 --> URI Class Initialized
INFO - 2017-09-07 09:11:43 --> Router Class Initialized
INFO - 2017-09-07 09:11:43 --> Output Class Initialized
INFO - 2017-09-07 09:11:43 --> Security Class Initialized
DEBUG - 2017-09-07 09:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 09:11:43 --> Input Class Initialized
INFO - 2017-09-07 09:11:43 --> Language Class Initialized
INFO - 2017-09-07 09:11:43 --> Loader Class Initialized
INFO - 2017-09-07 09:11:43 --> Helper loaded: url_helper
INFO - 2017-09-07 09:11:43 --> Database Driver Class Initialized
INFO - 2017-09-07 09:11:43 --> Email Class Initialized
INFO - 2017-09-07 09:11:43 --> Controller Class Initialized
DEBUG - 2017-09-07 09:11:43 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 09:11:43 --> Helper loaded: inflector_helper
INFO - 2017-09-07 09:11:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 09:11:43 --> Helper loaded: log_helper
INFO - 2017-09-07 09:11:43 --> Model Class Initialized
INFO - 2017-09-07 16:11:43 --> Final output sent to browser
DEBUG - 2017-09-07 16:11:43 --> Total execution time: 0.0729
INFO - 2017-09-07 09:11:54 --> Config Class Initialized
INFO - 2017-09-07 09:11:54 --> Hooks Class Initialized
DEBUG - 2017-09-07 09:11:54 --> UTF-8 Support Enabled
INFO - 2017-09-07 09:11:54 --> Utf8 Class Initialized
INFO - 2017-09-07 09:11:54 --> URI Class Initialized
INFO - 2017-09-07 09:11:54 --> Router Class Initialized
INFO - 2017-09-07 09:11:54 --> Output Class Initialized
INFO - 2017-09-07 09:11:54 --> Security Class Initialized
DEBUG - 2017-09-07 09:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 09:11:54 --> Input Class Initialized
INFO - 2017-09-07 09:11:54 --> Language Class Initialized
INFO - 2017-09-07 09:11:54 --> Loader Class Initialized
INFO - 2017-09-07 09:11:54 --> Helper loaded: url_helper
INFO - 2017-09-07 09:11:54 --> Database Driver Class Initialized
INFO - 2017-09-07 09:11:54 --> Email Class Initialized
INFO - 2017-09-07 09:11:54 --> Controller Class Initialized
DEBUG - 2017-09-07 09:11:54 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 09:11:54 --> Helper loaded: inflector_helper
INFO - 2017-09-07 09:11:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 09:11:54 --> Helper loaded: log_helper
INFO - 2017-09-07 09:11:54 --> Model Class Initialized
INFO - 2017-09-07 09:12:16 --> Config Class Initialized
INFO - 2017-09-07 09:12:16 --> Hooks Class Initialized
DEBUG - 2017-09-07 09:12:16 --> UTF-8 Support Enabled
INFO - 2017-09-07 09:12:16 --> Utf8 Class Initialized
INFO - 2017-09-07 09:12:16 --> URI Class Initialized
INFO - 2017-09-07 09:12:16 --> Router Class Initialized
INFO - 2017-09-07 09:12:16 --> Output Class Initialized
INFO - 2017-09-07 09:12:16 --> Security Class Initialized
DEBUG - 2017-09-07 09:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 09:12:16 --> Input Class Initialized
INFO - 2017-09-07 09:12:16 --> Language Class Initialized
INFO - 2017-09-07 09:12:16 --> Loader Class Initialized
INFO - 2017-09-07 09:12:16 --> Helper loaded: url_helper
INFO - 2017-09-07 09:12:16 --> Database Driver Class Initialized
INFO - 2017-09-07 09:12:16 --> Email Class Initialized
INFO - 2017-09-07 09:12:16 --> Controller Class Initialized
DEBUG - 2017-09-07 09:12:16 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 09:12:16 --> Helper loaded: inflector_helper
INFO - 2017-09-07 09:12:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 09:12:16 --> Helper loaded: log_helper
INFO - 2017-09-07 09:12:16 --> Model Class Initialized
INFO - 2017-09-07 16:12:16 --> Final output sent to browser
DEBUG - 2017-09-07 16:12:16 --> Total execution time: 0.0690
INFO - 2017-09-07 09:14:13 --> Config Class Initialized
INFO - 2017-09-07 09:14:13 --> Hooks Class Initialized
DEBUG - 2017-09-07 09:14:13 --> UTF-8 Support Enabled
INFO - 2017-09-07 09:14:13 --> Utf8 Class Initialized
INFO - 2017-09-07 09:14:13 --> URI Class Initialized
INFO - 2017-09-07 09:14:13 --> Router Class Initialized
INFO - 2017-09-07 09:14:13 --> Output Class Initialized
INFO - 2017-09-07 09:14:13 --> Security Class Initialized
DEBUG - 2017-09-07 09:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 09:14:13 --> Input Class Initialized
INFO - 2017-09-07 09:14:13 --> Language Class Initialized
INFO - 2017-09-07 09:14:13 --> Loader Class Initialized
INFO - 2017-09-07 09:14:13 --> Helper loaded: url_helper
INFO - 2017-09-07 09:14:13 --> Database Driver Class Initialized
INFO - 2017-09-07 09:14:13 --> Email Class Initialized
INFO - 2017-09-07 09:14:13 --> Controller Class Initialized
DEBUG - 2017-09-07 09:14:13 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 09:14:13 --> Helper loaded: inflector_helper
INFO - 2017-09-07 09:14:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 09:14:13 --> Helper loaded: log_helper
INFO - 2017-09-07 09:14:13 --> Model Class Initialized
INFO - 2017-09-07 16:14:13 --> Final output sent to browser
DEBUG - 2017-09-07 16:14:13 --> Total execution time: 0.0545
INFO - 2017-09-07 09:14:28 --> Config Class Initialized
INFO - 2017-09-07 09:14:28 --> Hooks Class Initialized
DEBUG - 2017-09-07 09:14:28 --> UTF-8 Support Enabled
INFO - 2017-09-07 09:14:28 --> Utf8 Class Initialized
INFO - 2017-09-07 09:14:28 --> URI Class Initialized
INFO - 2017-09-07 09:14:28 --> Router Class Initialized
INFO - 2017-09-07 09:14:28 --> Output Class Initialized
INFO - 2017-09-07 09:14:28 --> Security Class Initialized
DEBUG - 2017-09-07 09:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 09:14:28 --> Input Class Initialized
INFO - 2017-09-07 09:14:28 --> Language Class Initialized
INFO - 2017-09-07 09:14:28 --> Loader Class Initialized
INFO - 2017-09-07 09:14:28 --> Helper loaded: url_helper
INFO - 2017-09-07 09:14:28 --> Database Driver Class Initialized
INFO - 2017-09-07 09:14:28 --> Email Class Initialized
INFO - 2017-09-07 09:14:28 --> Controller Class Initialized
DEBUG - 2017-09-07 09:14:28 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 09:14:28 --> Helper loaded: inflector_helper
INFO - 2017-09-07 09:14:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 09:14:28 --> Helper loaded: log_helper
INFO - 2017-09-07 09:14:28 --> Model Class Initialized
ERROR - 2017-09-07 16:14:28 --> Query error: Unknown column 'password' in 'where clause' - Invalid query: update user_member set password='6434626A6F3457596D6A616A4D63434278532F34525471614430626E7951787366666B32727275484A6C6C446A7352504B527578486E69506657524C4A6D4569784A45795573464A473251517979582F4573327532673D3D' where hp='4D7871704E3658616737787059374C764945315A4B673D3D' and password='74782B7A4E6746556F79756D313557666E2F32387A683278396E48705341734B694F325330503779375368355972614363385738766F357551386A2B6D69706D706C6F72625649433032536265454B6762756A485A773D3D'
INFO - 2017-09-07 16:14:28 --> Language file loaded: language/english/db_lang.php
INFO - 2017-09-07 09:14:30 --> Config Class Initialized
INFO - 2017-09-07 09:14:30 --> Hooks Class Initialized
DEBUG - 2017-09-07 09:14:30 --> UTF-8 Support Enabled
INFO - 2017-09-07 09:14:30 --> Utf8 Class Initialized
INFO - 2017-09-07 09:14:30 --> URI Class Initialized
INFO - 2017-09-07 09:14:30 --> Router Class Initialized
INFO - 2017-09-07 09:14:30 --> Output Class Initialized
INFO - 2017-09-07 09:14:30 --> Security Class Initialized
DEBUG - 2017-09-07 09:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 09:14:30 --> Input Class Initialized
INFO - 2017-09-07 09:14:30 --> Language Class Initialized
INFO - 2017-09-07 09:14:30 --> Loader Class Initialized
INFO - 2017-09-07 09:14:30 --> Helper loaded: url_helper
INFO - 2017-09-07 09:14:30 --> Database Driver Class Initialized
INFO - 2017-09-07 09:14:30 --> Email Class Initialized
INFO - 2017-09-07 09:14:30 --> Controller Class Initialized
DEBUG - 2017-09-07 09:14:30 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 09:14:30 --> Helper loaded: inflector_helper
INFO - 2017-09-07 09:14:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 09:14:30 --> Helper loaded: log_helper
INFO - 2017-09-07 09:14:30 --> Model Class Initialized
INFO - 2017-09-07 16:14:30 --> Final output sent to browser
DEBUG - 2017-09-07 16:14:30 --> Total execution time: 0.0563
INFO - 2017-09-07 09:14:33 --> Config Class Initialized
INFO - 2017-09-07 09:14:33 --> Hooks Class Initialized
DEBUG - 2017-09-07 09:14:33 --> UTF-8 Support Enabled
INFO - 2017-09-07 09:14:33 --> Utf8 Class Initialized
INFO - 2017-09-07 09:14:33 --> URI Class Initialized
INFO - 2017-09-07 09:14:33 --> Router Class Initialized
INFO - 2017-09-07 09:14:33 --> Output Class Initialized
INFO - 2017-09-07 09:14:33 --> Security Class Initialized
DEBUG - 2017-09-07 09:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 09:14:33 --> Input Class Initialized
INFO - 2017-09-07 09:14:33 --> Language Class Initialized
INFO - 2017-09-07 09:14:33 --> Loader Class Initialized
INFO - 2017-09-07 09:14:33 --> Helper loaded: url_helper
INFO - 2017-09-07 09:14:33 --> Database Driver Class Initialized
INFO - 2017-09-07 09:14:33 --> Email Class Initialized
INFO - 2017-09-07 09:14:33 --> Controller Class Initialized
DEBUG - 2017-09-07 09:14:33 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 09:14:33 --> Helper loaded: inflector_helper
INFO - 2017-09-07 09:14:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 09:14:33 --> Helper loaded: log_helper
INFO - 2017-09-07 09:14:33 --> Model Class Initialized
ERROR - 2017-09-07 16:14:33 --> Query error: Unknown column 'password' in 'where clause' - Invalid query: update user_member set password='6434626A6F3457596D6A616A4D63434278532F34525471614430626E7951787366666B32727275484A6C6C446A7352504B527578486E69506657524C4A6D4569784A45795573464A473251517979582F4573327532673D3D' where hp='4D7871704E3658616737787059374C764945315A4B673D3D' and password='74782B7A4E6746556F79756D313557666E2F32387A683278396E48705341734B694F325330503779375368355972614363385738766F357551386A2B6D69706D706C6F72625649433032536265454B6762756A485A773D3D'
INFO - 2017-09-07 16:14:33 --> Language file loaded: language/english/db_lang.php
INFO - 2017-09-07 09:15:22 --> Config Class Initialized
INFO - 2017-09-07 09:15:22 --> Hooks Class Initialized
DEBUG - 2017-09-07 09:15:22 --> UTF-8 Support Enabled
INFO - 2017-09-07 09:15:22 --> Utf8 Class Initialized
INFO - 2017-09-07 09:15:22 --> URI Class Initialized
INFO - 2017-09-07 09:15:22 --> Router Class Initialized
INFO - 2017-09-07 09:15:22 --> Output Class Initialized
INFO - 2017-09-07 09:15:22 --> Security Class Initialized
DEBUG - 2017-09-07 09:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 09:15:22 --> Input Class Initialized
INFO - 2017-09-07 09:15:22 --> Language Class Initialized
INFO - 2017-09-07 09:15:22 --> Loader Class Initialized
INFO - 2017-09-07 09:15:22 --> Helper loaded: url_helper
INFO - 2017-09-07 09:15:22 --> Database Driver Class Initialized
INFO - 2017-09-07 09:15:22 --> Email Class Initialized
INFO - 2017-09-07 09:15:22 --> Controller Class Initialized
DEBUG - 2017-09-07 09:15:22 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 09:15:22 --> Helper loaded: inflector_helper
INFO - 2017-09-07 09:15:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 09:15:22 --> Helper loaded: log_helper
INFO - 2017-09-07 09:15:22 --> Model Class Initialized
INFO - 2017-09-07 16:15:22 --> Final output sent to browser
DEBUG - 2017-09-07 16:15:22 --> Total execution time: 0.0608
INFO - 2017-09-07 09:15:50 --> Config Class Initialized
INFO - 2017-09-07 09:15:50 --> Hooks Class Initialized
DEBUG - 2017-09-07 09:15:50 --> UTF-8 Support Enabled
INFO - 2017-09-07 09:15:50 --> Utf8 Class Initialized
INFO - 2017-09-07 09:15:50 --> URI Class Initialized
INFO - 2017-09-07 09:15:50 --> Router Class Initialized
INFO - 2017-09-07 09:15:50 --> Output Class Initialized
INFO - 2017-09-07 09:15:50 --> Security Class Initialized
DEBUG - 2017-09-07 09:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 09:15:50 --> Input Class Initialized
INFO - 2017-09-07 09:15:50 --> Language Class Initialized
INFO - 2017-09-07 09:15:50 --> Loader Class Initialized
INFO - 2017-09-07 09:15:50 --> Helper loaded: url_helper
INFO - 2017-09-07 09:15:50 --> Database Driver Class Initialized
INFO - 2017-09-07 09:15:50 --> Email Class Initialized
INFO - 2017-09-07 09:15:50 --> Controller Class Initialized
DEBUG - 2017-09-07 09:15:50 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 09:15:50 --> Helper loaded: inflector_helper
INFO - 2017-09-07 09:15:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 09:15:50 --> Helper loaded: log_helper
INFO - 2017-09-07 09:15:50 --> Model Class Initialized
INFO - 2017-09-07 16:15:50 --> Final output sent to browser
DEBUG - 2017-09-07 16:15:50 --> Total execution time: 0.0695
INFO - 2017-09-07 09:15:56 --> Config Class Initialized
INFO - 2017-09-07 09:15:56 --> Hooks Class Initialized
DEBUG - 2017-09-07 09:15:56 --> UTF-8 Support Enabled
INFO - 2017-09-07 09:15:56 --> Utf8 Class Initialized
INFO - 2017-09-07 09:15:56 --> URI Class Initialized
INFO - 2017-09-07 09:15:56 --> Router Class Initialized
INFO - 2017-09-07 09:15:56 --> Output Class Initialized
INFO - 2017-09-07 09:15:56 --> Security Class Initialized
DEBUG - 2017-09-07 09:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 09:15:56 --> Input Class Initialized
INFO - 2017-09-07 09:15:56 --> Language Class Initialized
INFO - 2017-09-07 09:15:56 --> Loader Class Initialized
INFO - 2017-09-07 09:15:56 --> Helper loaded: url_helper
INFO - 2017-09-07 09:15:56 --> Database Driver Class Initialized
INFO - 2017-09-07 09:15:56 --> Email Class Initialized
INFO - 2017-09-07 09:15:56 --> Controller Class Initialized
DEBUG - 2017-09-07 09:15:56 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 09:15:56 --> Helper loaded: inflector_helper
INFO - 2017-09-07 09:15:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 09:15:56 --> Helper loaded: log_helper
INFO - 2017-09-07 09:15:56 --> Model Class Initialized
INFO - 2017-09-07 16:15:56 --> Final output sent to browser
DEBUG - 2017-09-07 16:15:56 --> Total execution time: 0.0544
INFO - 2017-09-07 09:15:58 --> Config Class Initialized
INFO - 2017-09-07 09:15:58 --> Hooks Class Initialized
DEBUG - 2017-09-07 09:15:58 --> UTF-8 Support Enabled
INFO - 2017-09-07 09:15:58 --> Utf8 Class Initialized
INFO - 2017-09-07 09:15:58 --> URI Class Initialized
INFO - 2017-09-07 09:15:58 --> Router Class Initialized
INFO - 2017-09-07 09:15:58 --> Output Class Initialized
INFO - 2017-09-07 09:15:58 --> Security Class Initialized
DEBUG - 2017-09-07 09:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 09:15:58 --> Input Class Initialized
INFO - 2017-09-07 09:15:58 --> Language Class Initialized
INFO - 2017-09-07 09:15:58 --> Loader Class Initialized
INFO - 2017-09-07 09:15:58 --> Helper loaded: url_helper
INFO - 2017-09-07 09:15:58 --> Database Driver Class Initialized
INFO - 2017-09-07 09:15:58 --> Email Class Initialized
INFO - 2017-09-07 09:15:58 --> Controller Class Initialized
DEBUG - 2017-09-07 09:15:58 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 09:15:58 --> Helper loaded: inflector_helper
INFO - 2017-09-07 09:15:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 09:15:58 --> Helper loaded: log_helper
INFO - 2017-09-07 09:15:58 --> Model Class Initialized
INFO - 2017-09-07 16:15:58 --> Final output sent to browser
DEBUG - 2017-09-07 16:15:58 --> Total execution time: 0.0734
INFO - 2017-09-07 09:16:12 --> Config Class Initialized
INFO - 2017-09-07 09:16:12 --> Hooks Class Initialized
DEBUG - 2017-09-07 09:16:12 --> UTF-8 Support Enabled
INFO - 2017-09-07 09:16:12 --> Utf8 Class Initialized
INFO - 2017-09-07 09:16:12 --> URI Class Initialized
INFO - 2017-09-07 09:16:12 --> Router Class Initialized
INFO - 2017-09-07 09:16:12 --> Output Class Initialized
INFO - 2017-09-07 09:16:12 --> Security Class Initialized
DEBUG - 2017-09-07 09:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 09:16:12 --> Input Class Initialized
INFO - 2017-09-07 09:16:12 --> Language Class Initialized
INFO - 2017-09-07 09:16:12 --> Loader Class Initialized
INFO - 2017-09-07 09:16:12 --> Helper loaded: url_helper
INFO - 2017-09-07 09:16:12 --> Database Driver Class Initialized
INFO - 2017-09-07 09:16:12 --> Email Class Initialized
INFO - 2017-09-07 09:16:12 --> Controller Class Initialized
DEBUG - 2017-09-07 09:16:12 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 09:16:12 --> Helper loaded: inflector_helper
INFO - 2017-09-07 09:16:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 09:16:12 --> Helper loaded: log_helper
INFO - 2017-09-07 09:16:12 --> Model Class Initialized
INFO - 2017-09-07 16:16:12 --> Final output sent to browser
DEBUG - 2017-09-07 16:16:12 --> Total execution time: 0.1240
INFO - 2017-09-07 09:16:26 --> Config Class Initialized
INFO - 2017-09-07 09:16:26 --> Hooks Class Initialized
DEBUG - 2017-09-07 09:16:26 --> UTF-8 Support Enabled
INFO - 2017-09-07 09:16:26 --> Utf8 Class Initialized
INFO - 2017-09-07 09:16:26 --> URI Class Initialized
INFO - 2017-09-07 09:16:26 --> Router Class Initialized
INFO - 2017-09-07 09:16:26 --> Output Class Initialized
INFO - 2017-09-07 09:16:26 --> Security Class Initialized
DEBUG - 2017-09-07 09:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 09:16:26 --> Input Class Initialized
INFO - 2017-09-07 09:16:26 --> Language Class Initialized
INFO - 2017-09-07 09:16:26 --> Loader Class Initialized
INFO - 2017-09-07 09:16:26 --> Helper loaded: url_helper
INFO - 2017-09-07 09:16:26 --> Database Driver Class Initialized
INFO - 2017-09-07 09:16:26 --> Email Class Initialized
INFO - 2017-09-07 09:16:26 --> Controller Class Initialized
DEBUG - 2017-09-07 09:16:26 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 09:16:26 --> Helper loaded: inflector_helper
INFO - 2017-09-07 09:16:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 09:16:26 --> Helper loaded: log_helper
INFO - 2017-09-07 09:16:26 --> Model Class Initialized
INFO - 2017-09-07 16:16:26 --> Final output sent to browser
DEBUG - 2017-09-07 16:16:26 --> Total execution time: 0.0716
INFO - 2017-09-07 09:19:58 --> Config Class Initialized
INFO - 2017-09-07 09:19:58 --> Hooks Class Initialized
DEBUG - 2017-09-07 09:19:58 --> UTF-8 Support Enabled
INFO - 2017-09-07 09:19:58 --> Utf8 Class Initialized
INFO - 2017-09-07 09:19:58 --> URI Class Initialized
INFO - 2017-09-07 09:19:58 --> Router Class Initialized
INFO - 2017-09-07 09:19:58 --> Output Class Initialized
INFO - 2017-09-07 09:19:58 --> Security Class Initialized
DEBUG - 2017-09-07 09:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 09:19:58 --> Input Class Initialized
INFO - 2017-09-07 09:19:58 --> Language Class Initialized
INFO - 2017-09-07 09:19:58 --> Loader Class Initialized
INFO - 2017-09-07 09:19:58 --> Helper loaded: url_helper
INFO - 2017-09-07 09:19:58 --> Database Driver Class Initialized
INFO - 2017-09-07 09:19:58 --> Email Class Initialized
INFO - 2017-09-07 09:19:58 --> Controller Class Initialized
DEBUG - 2017-09-07 09:19:58 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 09:19:58 --> Helper loaded: inflector_helper
INFO - 2017-09-07 09:19:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 09:19:58 --> Helper loaded: log_helper
INFO - 2017-09-07 09:19:58 --> Model Class Initialized
INFO - 2017-09-07 16:19:58 --> Final output sent to browser
DEBUG - 2017-09-07 16:19:58 --> Total execution time: 0.1511
INFO - 2017-09-07 09:20:14 --> Config Class Initialized
INFO - 2017-09-07 09:20:14 --> Hooks Class Initialized
DEBUG - 2017-09-07 09:20:14 --> UTF-8 Support Enabled
INFO - 2017-09-07 09:20:14 --> Utf8 Class Initialized
INFO - 2017-09-07 09:20:14 --> URI Class Initialized
INFO - 2017-09-07 09:20:14 --> Router Class Initialized
INFO - 2017-09-07 09:20:14 --> Output Class Initialized
INFO - 2017-09-07 09:20:14 --> Security Class Initialized
DEBUG - 2017-09-07 09:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 09:20:14 --> Input Class Initialized
INFO - 2017-09-07 09:20:14 --> Language Class Initialized
INFO - 2017-09-07 09:20:14 --> Loader Class Initialized
INFO - 2017-09-07 09:20:14 --> Helper loaded: url_helper
INFO - 2017-09-07 09:20:14 --> Database Driver Class Initialized
INFO - 2017-09-07 09:20:14 --> Email Class Initialized
INFO - 2017-09-07 09:20:14 --> Controller Class Initialized
DEBUG - 2017-09-07 09:20:14 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 09:20:14 --> Helper loaded: inflector_helper
INFO - 2017-09-07 09:20:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 09:20:14 --> Helper loaded: log_helper
INFO - 2017-09-07 09:20:14 --> Model Class Initialized
INFO - 2017-09-07 16:20:14 --> Final output sent to browser
DEBUG - 2017-09-07 16:20:14 --> Total execution time: 0.0784
INFO - 2017-09-07 09:20:19 --> Config Class Initialized
INFO - 2017-09-07 09:20:19 --> Hooks Class Initialized
DEBUG - 2017-09-07 09:20:19 --> UTF-8 Support Enabled
INFO - 2017-09-07 09:20:19 --> Utf8 Class Initialized
INFO - 2017-09-07 09:20:19 --> URI Class Initialized
INFO - 2017-09-07 09:20:19 --> Router Class Initialized
INFO - 2017-09-07 09:20:19 --> Output Class Initialized
INFO - 2017-09-07 09:20:19 --> Security Class Initialized
DEBUG - 2017-09-07 09:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 09:20:19 --> Input Class Initialized
INFO - 2017-09-07 09:20:19 --> Language Class Initialized
INFO - 2017-09-07 09:20:19 --> Loader Class Initialized
INFO - 2017-09-07 09:20:19 --> Helper loaded: url_helper
INFO - 2017-09-07 09:20:19 --> Database Driver Class Initialized
INFO - 2017-09-07 09:20:19 --> Email Class Initialized
INFO - 2017-09-07 09:20:19 --> Controller Class Initialized
DEBUG - 2017-09-07 09:20:19 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 09:20:19 --> Helper loaded: inflector_helper
INFO - 2017-09-07 09:20:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 09:20:19 --> Helper loaded: log_helper
INFO - 2017-09-07 09:20:19 --> Model Class Initialized
INFO - 2017-09-07 16:20:19 --> Final output sent to browser
DEBUG - 2017-09-07 16:20:19 --> Total execution time: 0.0573
INFO - 2017-09-07 09:20:21 --> Config Class Initialized
INFO - 2017-09-07 09:20:21 --> Hooks Class Initialized
DEBUG - 2017-09-07 09:20:21 --> UTF-8 Support Enabled
INFO - 2017-09-07 09:20:21 --> Utf8 Class Initialized
INFO - 2017-09-07 09:20:21 --> URI Class Initialized
INFO - 2017-09-07 09:20:21 --> Router Class Initialized
INFO - 2017-09-07 09:20:21 --> Output Class Initialized
INFO - 2017-09-07 09:20:21 --> Security Class Initialized
DEBUG - 2017-09-07 09:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 09:20:21 --> Input Class Initialized
INFO - 2017-09-07 09:20:21 --> Language Class Initialized
INFO - 2017-09-07 09:20:21 --> Loader Class Initialized
INFO - 2017-09-07 09:20:21 --> Helper loaded: url_helper
INFO - 2017-09-07 09:20:21 --> Database Driver Class Initialized
INFO - 2017-09-07 09:20:21 --> Email Class Initialized
INFO - 2017-09-07 09:20:21 --> Controller Class Initialized
DEBUG - 2017-09-07 09:20:21 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 09:20:21 --> Helper loaded: inflector_helper
INFO - 2017-09-07 09:20:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 09:20:21 --> Helper loaded: log_helper
INFO - 2017-09-07 09:20:21 --> Model Class Initialized
INFO - 2017-09-07 16:20:21 --> Final output sent to browser
DEBUG - 2017-09-07 16:20:21 --> Total execution time: 0.0547
INFO - 2017-09-07 09:22:32 --> Config Class Initialized
INFO - 2017-09-07 09:22:32 --> Hooks Class Initialized
DEBUG - 2017-09-07 09:22:32 --> UTF-8 Support Enabled
INFO - 2017-09-07 09:22:32 --> Utf8 Class Initialized
INFO - 2017-09-07 09:22:32 --> URI Class Initialized
INFO - 2017-09-07 09:22:32 --> Router Class Initialized
INFO - 2017-09-07 09:22:32 --> Output Class Initialized
INFO - 2017-09-07 09:22:32 --> Security Class Initialized
DEBUG - 2017-09-07 09:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 09:22:32 --> Input Class Initialized
INFO - 2017-09-07 09:22:32 --> Language Class Initialized
INFO - 2017-09-07 09:22:32 --> Loader Class Initialized
INFO - 2017-09-07 09:22:32 --> Helper loaded: url_helper
INFO - 2017-09-07 09:22:32 --> Database Driver Class Initialized
INFO - 2017-09-07 09:22:32 --> Email Class Initialized
INFO - 2017-09-07 09:22:32 --> Controller Class Initialized
DEBUG - 2017-09-07 09:22:32 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 09:22:32 --> Helper loaded: inflector_helper
INFO - 2017-09-07 09:22:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 09:22:32 --> Helper loaded: log_helper
INFO - 2017-09-07 09:22:32 --> Model Class Initialized
INFO - 2017-09-07 16:22:32 --> Final output sent to browser
DEBUG - 2017-09-07 16:22:32 --> Total execution time: 0.0647
INFO - 2017-09-07 09:26:01 --> Config Class Initialized
INFO - 2017-09-07 09:26:01 --> Hooks Class Initialized
DEBUG - 2017-09-07 09:26:01 --> UTF-8 Support Enabled
INFO - 2017-09-07 09:26:01 --> Utf8 Class Initialized
INFO - 2017-09-07 09:26:01 --> URI Class Initialized
INFO - 2017-09-07 09:26:01 --> Router Class Initialized
INFO - 2017-09-07 09:26:01 --> Output Class Initialized
INFO - 2017-09-07 09:26:01 --> Security Class Initialized
DEBUG - 2017-09-07 09:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 09:26:01 --> Input Class Initialized
INFO - 2017-09-07 09:26:01 --> Language Class Initialized
INFO - 2017-09-07 09:26:01 --> Loader Class Initialized
INFO - 2017-09-07 09:26:01 --> Helper loaded: url_helper
INFO - 2017-09-07 09:26:01 --> Database Driver Class Initialized
INFO - 2017-09-07 09:26:01 --> Email Class Initialized
INFO - 2017-09-07 09:26:01 --> Controller Class Initialized
DEBUG - 2017-09-07 09:26:01 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 09:26:01 --> Helper loaded: inflector_helper
INFO - 2017-09-07 09:26:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 09:26:01 --> Helper loaded: log_helper
INFO - 2017-09-07 09:26:01 --> Model Class Initialized
ERROR - 2017-09-07 16:26:01 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\franknco\application\models\api_model.php 379
INFO - 2017-09-07 16:26:01 --> Final output sent to browser
DEBUG - 2017-09-07 16:26:01 --> Total execution time: 0.0727
INFO - 2017-09-07 09:26:14 --> Config Class Initialized
INFO - 2017-09-07 09:26:14 --> Hooks Class Initialized
DEBUG - 2017-09-07 09:26:14 --> UTF-8 Support Enabled
INFO - 2017-09-07 09:26:14 --> Utf8 Class Initialized
INFO - 2017-09-07 09:26:14 --> URI Class Initialized
INFO - 2017-09-07 09:26:14 --> Router Class Initialized
INFO - 2017-09-07 09:26:14 --> Output Class Initialized
INFO - 2017-09-07 09:26:14 --> Security Class Initialized
DEBUG - 2017-09-07 09:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 09:26:14 --> Input Class Initialized
INFO - 2017-09-07 09:26:14 --> Language Class Initialized
INFO - 2017-09-07 09:26:14 --> Loader Class Initialized
INFO - 2017-09-07 09:26:14 --> Helper loaded: url_helper
INFO - 2017-09-07 09:26:14 --> Database Driver Class Initialized
INFO - 2017-09-07 09:26:14 --> Email Class Initialized
INFO - 2017-09-07 09:26:14 --> Controller Class Initialized
DEBUG - 2017-09-07 09:26:14 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 09:26:14 --> Helper loaded: inflector_helper
INFO - 2017-09-07 09:26:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 09:26:14 --> Helper loaded: log_helper
INFO - 2017-09-07 09:26:14 --> Model Class Initialized
INFO - 2017-09-07 16:26:14 --> Final output sent to browser
DEBUG - 2017-09-07 16:26:14 --> Total execution time: 0.0628
INFO - 2017-09-07 09:26:21 --> Config Class Initialized
INFO - 2017-09-07 09:26:21 --> Hooks Class Initialized
DEBUG - 2017-09-07 09:26:21 --> UTF-8 Support Enabled
INFO - 2017-09-07 09:26:21 --> Utf8 Class Initialized
INFO - 2017-09-07 09:26:21 --> URI Class Initialized
INFO - 2017-09-07 09:26:21 --> Router Class Initialized
INFO - 2017-09-07 09:26:21 --> Output Class Initialized
INFO - 2017-09-07 09:26:21 --> Security Class Initialized
DEBUG - 2017-09-07 09:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 09:26:21 --> Input Class Initialized
INFO - 2017-09-07 09:26:21 --> Language Class Initialized
INFO - 2017-09-07 09:26:21 --> Loader Class Initialized
INFO - 2017-09-07 09:26:21 --> Helper loaded: url_helper
INFO - 2017-09-07 09:26:21 --> Database Driver Class Initialized
INFO - 2017-09-07 09:26:21 --> Email Class Initialized
INFO - 2017-09-07 09:26:21 --> Controller Class Initialized
DEBUG - 2017-09-07 09:26:21 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 09:26:21 --> Helper loaded: inflector_helper
INFO - 2017-09-07 09:26:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 09:26:21 --> Helper loaded: log_helper
INFO - 2017-09-07 09:26:21 --> Model Class Initialized
INFO - 2017-09-07 16:26:21 --> Final output sent to browser
DEBUG - 2017-09-07 16:26:21 --> Total execution time: 0.0616
INFO - 2017-09-07 09:26:42 --> Config Class Initialized
INFO - 2017-09-07 09:26:42 --> Hooks Class Initialized
DEBUG - 2017-09-07 09:26:42 --> UTF-8 Support Enabled
INFO - 2017-09-07 09:26:42 --> Utf8 Class Initialized
INFO - 2017-09-07 09:26:42 --> URI Class Initialized
INFO - 2017-09-07 09:26:42 --> Router Class Initialized
INFO - 2017-09-07 09:26:42 --> Output Class Initialized
INFO - 2017-09-07 09:26:42 --> Security Class Initialized
DEBUG - 2017-09-07 09:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 09:26:42 --> Input Class Initialized
INFO - 2017-09-07 09:26:42 --> Language Class Initialized
INFO - 2017-09-07 09:26:42 --> Loader Class Initialized
INFO - 2017-09-07 09:26:42 --> Helper loaded: url_helper
INFO - 2017-09-07 09:26:42 --> Database Driver Class Initialized
INFO - 2017-09-07 09:26:42 --> Email Class Initialized
INFO - 2017-09-07 09:26:42 --> Controller Class Initialized
DEBUG - 2017-09-07 09:26:42 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 09:26:42 --> Helper loaded: inflector_helper
INFO - 2017-09-07 09:26:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 09:26:42 --> Helper loaded: log_helper
INFO - 2017-09-07 09:26:42 --> Model Class Initialized
INFO - 2017-09-07 16:26:42 --> Final output sent to browser
DEBUG - 2017-09-07 16:26:42 --> Total execution time: 0.0554
INFO - 2017-09-07 09:27:05 --> Config Class Initialized
INFO - 2017-09-07 09:27:05 --> Hooks Class Initialized
DEBUG - 2017-09-07 09:27:05 --> UTF-8 Support Enabled
INFO - 2017-09-07 09:27:05 --> Utf8 Class Initialized
INFO - 2017-09-07 09:27:05 --> URI Class Initialized
INFO - 2017-09-07 09:27:05 --> Router Class Initialized
INFO - 2017-09-07 09:27:05 --> Output Class Initialized
INFO - 2017-09-07 09:27:05 --> Security Class Initialized
DEBUG - 2017-09-07 09:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 09:27:05 --> Input Class Initialized
INFO - 2017-09-07 09:27:05 --> Language Class Initialized
INFO - 2017-09-07 09:27:05 --> Loader Class Initialized
INFO - 2017-09-07 09:27:05 --> Helper loaded: url_helper
INFO - 2017-09-07 09:27:05 --> Database Driver Class Initialized
INFO - 2017-09-07 09:27:05 --> Email Class Initialized
INFO - 2017-09-07 09:27:05 --> Controller Class Initialized
DEBUG - 2017-09-07 09:27:05 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 09:27:05 --> Helper loaded: inflector_helper
INFO - 2017-09-07 09:27:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 09:27:05 --> Helper loaded: log_helper
INFO - 2017-09-07 09:27:05 --> Model Class Initialized
INFO - 2017-09-07 16:27:05 --> Final output sent to browser
DEBUG - 2017-09-07 16:27:05 --> Total execution time: 0.0730
INFO - 2017-09-07 09:27:05 --> Config Class Initialized
INFO - 2017-09-07 09:27:05 --> Hooks Class Initialized
DEBUG - 2017-09-07 09:27:05 --> UTF-8 Support Enabled
INFO - 2017-09-07 09:27:05 --> Utf8 Class Initialized
INFO - 2017-09-07 09:27:05 --> URI Class Initialized
INFO - 2017-09-07 09:27:05 --> Router Class Initialized
INFO - 2017-09-07 09:27:05 --> Output Class Initialized
INFO - 2017-09-07 09:27:05 --> Security Class Initialized
DEBUG - 2017-09-07 09:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 09:27:05 --> Input Class Initialized
INFO - 2017-09-07 09:27:05 --> Language Class Initialized
INFO - 2017-09-07 09:27:05 --> Loader Class Initialized
INFO - 2017-09-07 09:27:05 --> Helper loaded: url_helper
INFO - 2017-09-07 09:27:05 --> Database Driver Class Initialized
INFO - 2017-09-07 09:27:05 --> Email Class Initialized
INFO - 2017-09-07 09:27:05 --> Controller Class Initialized
DEBUG - 2017-09-07 09:27:05 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 09:27:05 --> Helper loaded: inflector_helper
INFO - 2017-09-07 09:27:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 09:27:05 --> Helper loaded: log_helper
INFO - 2017-09-07 09:27:05 --> Model Class Initialized
INFO - 2017-09-07 16:27:05 --> Final output sent to browser
DEBUG - 2017-09-07 16:27:05 --> Total execution time: 0.0832
INFO - 2017-09-07 09:27:08 --> Config Class Initialized
INFO - 2017-09-07 09:27:08 --> Hooks Class Initialized
DEBUG - 2017-09-07 09:27:08 --> UTF-8 Support Enabled
INFO - 2017-09-07 09:27:08 --> Utf8 Class Initialized
INFO - 2017-09-07 09:27:08 --> URI Class Initialized
INFO - 2017-09-07 09:27:08 --> Router Class Initialized
INFO - 2017-09-07 09:27:08 --> Output Class Initialized
INFO - 2017-09-07 09:27:08 --> Security Class Initialized
DEBUG - 2017-09-07 09:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 09:27:08 --> Input Class Initialized
INFO - 2017-09-07 09:27:08 --> Language Class Initialized
INFO - 2017-09-07 09:27:08 --> Loader Class Initialized
INFO - 2017-09-07 09:27:08 --> Helper loaded: url_helper
INFO - 2017-09-07 09:27:08 --> Database Driver Class Initialized
INFO - 2017-09-07 09:27:08 --> Email Class Initialized
INFO - 2017-09-07 09:27:08 --> Controller Class Initialized
DEBUG - 2017-09-07 09:27:08 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 09:27:08 --> Helper loaded: inflector_helper
INFO - 2017-09-07 09:27:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 09:27:08 --> Helper loaded: log_helper
INFO - 2017-09-07 09:27:08 --> Model Class Initialized
INFO - 2017-09-07 16:27:08 --> Final output sent to browser
DEBUG - 2017-09-07 16:27:08 --> Total execution time: 0.0585
INFO - 2017-09-07 09:27:08 --> Config Class Initialized
INFO - 2017-09-07 09:27:08 --> Hooks Class Initialized
DEBUG - 2017-09-07 09:27:08 --> UTF-8 Support Enabled
INFO - 2017-09-07 09:27:08 --> Utf8 Class Initialized
INFO - 2017-09-07 09:27:08 --> URI Class Initialized
INFO - 2017-09-07 09:27:08 --> Router Class Initialized
INFO - 2017-09-07 09:27:08 --> Output Class Initialized
INFO - 2017-09-07 09:27:08 --> Security Class Initialized
DEBUG - 2017-09-07 09:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 09:27:08 --> Input Class Initialized
INFO - 2017-09-07 09:27:08 --> Language Class Initialized
INFO - 2017-09-07 09:27:08 --> Loader Class Initialized
INFO - 2017-09-07 09:27:08 --> Helper loaded: url_helper
INFO - 2017-09-07 09:27:08 --> Database Driver Class Initialized
INFO - 2017-09-07 09:27:08 --> Email Class Initialized
INFO - 2017-09-07 09:27:08 --> Controller Class Initialized
DEBUG - 2017-09-07 09:27:08 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 09:27:08 --> Helper loaded: inflector_helper
INFO - 2017-09-07 09:27:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 09:27:08 --> Helper loaded: log_helper
INFO - 2017-09-07 09:27:08 --> Model Class Initialized
INFO - 2017-09-07 16:27:08 --> Final output sent to browser
DEBUG - 2017-09-07 16:27:08 --> Total execution time: 0.0777
INFO - 2017-09-07 09:27:10 --> Config Class Initialized
INFO - 2017-09-07 09:27:10 --> Hooks Class Initialized
DEBUG - 2017-09-07 09:27:10 --> UTF-8 Support Enabled
INFO - 2017-09-07 09:27:10 --> Utf8 Class Initialized
INFO - 2017-09-07 09:27:10 --> URI Class Initialized
INFO - 2017-09-07 09:27:10 --> Router Class Initialized
INFO - 2017-09-07 09:27:10 --> Output Class Initialized
INFO - 2017-09-07 09:27:10 --> Security Class Initialized
DEBUG - 2017-09-07 09:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 09:27:10 --> Input Class Initialized
INFO - 2017-09-07 09:27:10 --> Language Class Initialized
INFO - 2017-09-07 09:27:10 --> Loader Class Initialized
INFO - 2017-09-07 09:27:10 --> Helper loaded: url_helper
INFO - 2017-09-07 09:27:10 --> Database Driver Class Initialized
INFO - 2017-09-07 09:27:10 --> Email Class Initialized
INFO - 2017-09-07 09:27:10 --> Controller Class Initialized
DEBUG - 2017-09-07 09:27:10 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 09:27:10 --> Helper loaded: inflector_helper
INFO - 2017-09-07 09:27:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 09:27:10 --> Helper loaded: log_helper
INFO - 2017-09-07 09:27:10 --> Model Class Initialized
INFO - 2017-09-07 16:27:10 --> Final output sent to browser
DEBUG - 2017-09-07 16:27:10 --> Total execution time: 0.0747
INFO - 2017-09-07 09:27:10 --> Config Class Initialized
INFO - 2017-09-07 09:27:10 --> Hooks Class Initialized
DEBUG - 2017-09-07 09:27:10 --> UTF-8 Support Enabled
INFO - 2017-09-07 09:27:10 --> Utf8 Class Initialized
INFO - 2017-09-07 09:27:10 --> URI Class Initialized
INFO - 2017-09-07 09:27:10 --> Router Class Initialized
INFO - 2017-09-07 09:27:10 --> Output Class Initialized
INFO - 2017-09-07 09:27:10 --> Security Class Initialized
DEBUG - 2017-09-07 09:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 09:27:10 --> Input Class Initialized
INFO - 2017-09-07 09:27:10 --> Language Class Initialized
INFO - 2017-09-07 09:27:10 --> Loader Class Initialized
INFO - 2017-09-07 09:27:10 --> Helper loaded: url_helper
INFO - 2017-09-07 09:27:10 --> Database Driver Class Initialized
INFO - 2017-09-07 09:27:10 --> Email Class Initialized
INFO - 2017-09-07 09:27:10 --> Controller Class Initialized
DEBUG - 2017-09-07 09:27:10 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 09:27:10 --> Helper loaded: inflector_helper
INFO - 2017-09-07 09:27:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 09:27:10 --> Helper loaded: log_helper
INFO - 2017-09-07 09:27:10 --> Model Class Initialized
INFO - 2017-09-07 16:27:11 --> Final output sent to browser
DEBUG - 2017-09-07 16:27:11 --> Total execution time: 0.0759
INFO - 2017-09-07 09:27:22 --> Config Class Initialized
INFO - 2017-09-07 09:27:22 --> Hooks Class Initialized
DEBUG - 2017-09-07 09:27:22 --> UTF-8 Support Enabled
INFO - 2017-09-07 09:27:22 --> Utf8 Class Initialized
INFO - 2017-09-07 09:27:22 --> URI Class Initialized
INFO - 2017-09-07 09:27:22 --> Router Class Initialized
INFO - 2017-09-07 09:27:22 --> Output Class Initialized
INFO - 2017-09-07 09:27:22 --> Security Class Initialized
DEBUG - 2017-09-07 09:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 09:27:22 --> Input Class Initialized
INFO - 2017-09-07 09:27:22 --> Language Class Initialized
INFO - 2017-09-07 09:27:22 --> Loader Class Initialized
INFO - 2017-09-07 09:27:22 --> Helper loaded: url_helper
INFO - 2017-09-07 09:27:22 --> Database Driver Class Initialized
INFO - 2017-09-07 09:27:22 --> Email Class Initialized
INFO - 2017-09-07 09:27:22 --> Controller Class Initialized
DEBUG - 2017-09-07 09:27:22 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 09:27:22 --> Helper loaded: inflector_helper
INFO - 2017-09-07 09:27:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 09:27:22 --> Helper loaded: log_helper
INFO - 2017-09-07 09:27:22 --> Model Class Initialized
INFO - 2017-09-07 16:27:22 --> Final output sent to browser
DEBUG - 2017-09-07 16:27:22 --> Total execution time: 0.0926
INFO - 2017-09-07 09:30:21 --> Config Class Initialized
INFO - 2017-09-07 09:30:21 --> Hooks Class Initialized
DEBUG - 2017-09-07 09:30:21 --> UTF-8 Support Enabled
INFO - 2017-09-07 09:30:21 --> Utf8 Class Initialized
INFO - 2017-09-07 09:30:21 --> URI Class Initialized
INFO - 2017-09-07 09:30:21 --> Router Class Initialized
INFO - 2017-09-07 09:30:21 --> Output Class Initialized
INFO - 2017-09-07 09:30:21 --> Security Class Initialized
DEBUG - 2017-09-07 09:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 09:30:21 --> Input Class Initialized
INFO - 2017-09-07 09:30:21 --> Language Class Initialized
INFO - 2017-09-07 09:30:21 --> Loader Class Initialized
INFO - 2017-09-07 09:30:21 --> Helper loaded: url_helper
INFO - 2017-09-07 09:30:21 --> Database Driver Class Initialized
INFO - 2017-09-07 09:30:21 --> Email Class Initialized
INFO - 2017-09-07 09:30:21 --> Controller Class Initialized
DEBUG - 2017-09-07 09:30:21 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 09:30:21 --> Helper loaded: inflector_helper
INFO - 2017-09-07 09:30:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 09:30:21 --> Helper loaded: log_helper
INFO - 2017-09-07 09:30:21 --> Model Class Initialized
INFO - 2017-09-07 16:30:21 --> Final output sent to browser
DEBUG - 2017-09-07 16:30:21 --> Total execution time: 0.1470
INFO - 2017-09-07 09:30:24 --> Config Class Initialized
INFO - 2017-09-07 09:30:24 --> Hooks Class Initialized
DEBUG - 2017-09-07 09:30:24 --> UTF-8 Support Enabled
INFO - 2017-09-07 09:30:24 --> Utf8 Class Initialized
INFO - 2017-09-07 09:30:24 --> URI Class Initialized
INFO - 2017-09-07 09:30:24 --> Router Class Initialized
INFO - 2017-09-07 09:30:24 --> Output Class Initialized
INFO - 2017-09-07 09:30:24 --> Security Class Initialized
DEBUG - 2017-09-07 09:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 09:30:24 --> Input Class Initialized
INFO - 2017-09-07 09:30:24 --> Language Class Initialized
INFO - 2017-09-07 09:30:24 --> Loader Class Initialized
INFO - 2017-09-07 09:30:24 --> Helper loaded: url_helper
INFO - 2017-09-07 09:30:24 --> Database Driver Class Initialized
INFO - 2017-09-07 09:30:24 --> Email Class Initialized
INFO - 2017-09-07 09:30:24 --> Controller Class Initialized
DEBUG - 2017-09-07 09:30:24 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 09:30:24 --> Helper loaded: inflector_helper
INFO - 2017-09-07 09:30:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 09:30:24 --> Helper loaded: log_helper
INFO - 2017-09-07 09:30:24 --> Model Class Initialized
INFO - 2017-09-07 16:30:24 --> Final output sent to browser
DEBUG - 2017-09-07 16:30:24 --> Total execution time: 0.0661
INFO - 2017-09-07 09:30:28 --> Config Class Initialized
INFO - 2017-09-07 09:30:28 --> Hooks Class Initialized
DEBUG - 2017-09-07 09:30:28 --> UTF-8 Support Enabled
INFO - 2017-09-07 09:30:28 --> Utf8 Class Initialized
INFO - 2017-09-07 09:30:28 --> URI Class Initialized
INFO - 2017-09-07 09:30:28 --> Router Class Initialized
INFO - 2017-09-07 09:30:28 --> Output Class Initialized
INFO - 2017-09-07 09:30:28 --> Security Class Initialized
DEBUG - 2017-09-07 09:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 09:30:28 --> Input Class Initialized
INFO - 2017-09-07 09:30:28 --> Language Class Initialized
INFO - 2017-09-07 09:30:28 --> Loader Class Initialized
INFO - 2017-09-07 09:30:28 --> Helper loaded: url_helper
INFO - 2017-09-07 09:30:28 --> Database Driver Class Initialized
INFO - 2017-09-07 09:30:28 --> Email Class Initialized
INFO - 2017-09-07 09:30:28 --> Controller Class Initialized
DEBUG - 2017-09-07 09:30:28 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 09:30:28 --> Helper loaded: inflector_helper
INFO - 2017-09-07 09:30:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 09:30:28 --> Helper loaded: log_helper
INFO - 2017-09-07 09:30:28 --> Model Class Initialized
INFO - 2017-09-07 16:30:28 --> Final output sent to browser
DEBUG - 2017-09-07 16:30:28 --> Total execution time: 0.0566
INFO - 2017-09-07 09:30:34 --> Config Class Initialized
INFO - 2017-09-07 09:30:34 --> Hooks Class Initialized
DEBUG - 2017-09-07 09:30:34 --> UTF-8 Support Enabled
INFO - 2017-09-07 09:30:34 --> Utf8 Class Initialized
INFO - 2017-09-07 09:30:34 --> URI Class Initialized
INFO - 2017-09-07 09:30:34 --> Router Class Initialized
INFO - 2017-09-07 09:30:34 --> Output Class Initialized
INFO - 2017-09-07 09:30:34 --> Security Class Initialized
DEBUG - 2017-09-07 09:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 09:30:34 --> Input Class Initialized
INFO - 2017-09-07 09:30:34 --> Language Class Initialized
INFO - 2017-09-07 09:30:34 --> Loader Class Initialized
INFO - 2017-09-07 09:30:34 --> Helper loaded: url_helper
INFO - 2017-09-07 09:30:34 --> Database Driver Class Initialized
INFO - 2017-09-07 09:30:34 --> Email Class Initialized
INFO - 2017-09-07 09:30:34 --> Controller Class Initialized
DEBUG - 2017-09-07 09:30:34 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 09:30:34 --> Helper loaded: inflector_helper
INFO - 2017-09-07 09:30:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 09:30:34 --> Helper loaded: log_helper
INFO - 2017-09-07 09:30:34 --> Model Class Initialized
ERROR - 2017-09-07 16:30:34 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\franknco\application\models\api_model.php 379
INFO - 2017-09-07 16:30:34 --> Final output sent to browser
DEBUG - 2017-09-07 16:30:34 --> Total execution time: 0.0588
INFO - 2017-09-07 09:30:41 --> Config Class Initialized
INFO - 2017-09-07 09:30:41 --> Hooks Class Initialized
DEBUG - 2017-09-07 09:30:41 --> UTF-8 Support Enabled
INFO - 2017-09-07 09:30:41 --> Utf8 Class Initialized
INFO - 2017-09-07 09:30:41 --> URI Class Initialized
INFO - 2017-09-07 09:30:41 --> Router Class Initialized
INFO - 2017-09-07 09:30:41 --> Output Class Initialized
INFO - 2017-09-07 09:30:41 --> Security Class Initialized
DEBUG - 2017-09-07 09:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 09:30:41 --> Input Class Initialized
INFO - 2017-09-07 09:30:41 --> Language Class Initialized
INFO - 2017-09-07 09:30:41 --> Loader Class Initialized
INFO - 2017-09-07 09:30:41 --> Helper loaded: url_helper
INFO - 2017-09-07 09:30:41 --> Database Driver Class Initialized
INFO - 2017-09-07 09:30:41 --> Email Class Initialized
INFO - 2017-09-07 09:30:41 --> Controller Class Initialized
DEBUG - 2017-09-07 09:30:41 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 09:30:41 --> Helper loaded: inflector_helper
INFO - 2017-09-07 09:30:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 09:30:41 --> Helper loaded: log_helper
INFO - 2017-09-07 09:30:41 --> Model Class Initialized
INFO - 2017-09-07 16:30:41 --> Final output sent to browser
DEBUG - 2017-09-07 16:30:41 --> Total execution time: 0.0533
INFO - 2017-09-07 09:30:44 --> Config Class Initialized
INFO - 2017-09-07 09:30:44 --> Hooks Class Initialized
DEBUG - 2017-09-07 09:30:44 --> UTF-8 Support Enabled
INFO - 2017-09-07 09:30:44 --> Utf8 Class Initialized
INFO - 2017-09-07 09:30:44 --> URI Class Initialized
INFO - 2017-09-07 09:30:44 --> Router Class Initialized
INFO - 2017-09-07 09:30:44 --> Output Class Initialized
INFO - 2017-09-07 09:30:44 --> Security Class Initialized
DEBUG - 2017-09-07 09:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 09:30:44 --> Input Class Initialized
INFO - 2017-09-07 09:30:44 --> Language Class Initialized
INFO - 2017-09-07 09:30:44 --> Loader Class Initialized
INFO - 2017-09-07 09:30:44 --> Helper loaded: url_helper
INFO - 2017-09-07 09:30:44 --> Database Driver Class Initialized
INFO - 2017-09-07 09:30:44 --> Email Class Initialized
INFO - 2017-09-07 09:30:44 --> Controller Class Initialized
DEBUG - 2017-09-07 09:30:44 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 09:30:44 --> Helper loaded: inflector_helper
INFO - 2017-09-07 09:30:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 09:30:44 --> Helper loaded: log_helper
INFO - 2017-09-07 09:30:44 --> Model Class Initialized
INFO - 2017-09-07 16:30:44 --> Final output sent to browser
DEBUG - 2017-09-07 16:30:44 --> Total execution time: 0.0557
INFO - 2017-09-07 09:30:45 --> Config Class Initialized
INFO - 2017-09-07 09:30:45 --> Hooks Class Initialized
DEBUG - 2017-09-07 09:30:45 --> UTF-8 Support Enabled
INFO - 2017-09-07 09:30:45 --> Utf8 Class Initialized
INFO - 2017-09-07 09:30:45 --> URI Class Initialized
INFO - 2017-09-07 09:30:45 --> Router Class Initialized
INFO - 2017-09-07 09:30:45 --> Output Class Initialized
INFO - 2017-09-07 09:30:45 --> Security Class Initialized
DEBUG - 2017-09-07 09:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 09:30:45 --> Input Class Initialized
INFO - 2017-09-07 09:30:45 --> Language Class Initialized
INFO - 2017-09-07 09:30:45 --> Loader Class Initialized
INFO - 2017-09-07 09:30:45 --> Helper loaded: url_helper
INFO - 2017-09-07 09:30:45 --> Database Driver Class Initialized
INFO - 2017-09-07 09:30:45 --> Email Class Initialized
INFO - 2017-09-07 09:30:45 --> Controller Class Initialized
DEBUG - 2017-09-07 09:30:45 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 09:30:45 --> Helper loaded: inflector_helper
INFO - 2017-09-07 09:30:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 09:30:45 --> Helper loaded: log_helper
INFO - 2017-09-07 09:30:45 --> Model Class Initialized
INFO - 2017-09-07 16:30:45 --> Final output sent to browser
DEBUG - 2017-09-07 16:30:45 --> Total execution time: 0.0547
INFO - 2017-09-07 09:30:47 --> Config Class Initialized
INFO - 2017-09-07 09:30:47 --> Hooks Class Initialized
DEBUG - 2017-09-07 09:30:47 --> UTF-8 Support Enabled
INFO - 2017-09-07 09:30:47 --> Utf8 Class Initialized
INFO - 2017-09-07 09:30:47 --> URI Class Initialized
INFO - 2017-09-07 09:30:47 --> Router Class Initialized
INFO - 2017-09-07 09:30:47 --> Output Class Initialized
INFO - 2017-09-07 09:30:47 --> Security Class Initialized
DEBUG - 2017-09-07 09:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 09:30:47 --> Input Class Initialized
INFO - 2017-09-07 09:30:47 --> Language Class Initialized
INFO - 2017-09-07 09:30:47 --> Loader Class Initialized
INFO - 2017-09-07 09:30:47 --> Helper loaded: url_helper
INFO - 2017-09-07 09:30:47 --> Database Driver Class Initialized
INFO - 2017-09-07 09:30:47 --> Email Class Initialized
INFO - 2017-09-07 09:30:47 --> Controller Class Initialized
DEBUG - 2017-09-07 09:30:47 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 09:30:47 --> Helper loaded: inflector_helper
INFO - 2017-09-07 09:30:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 09:30:47 --> Helper loaded: log_helper
INFO - 2017-09-07 09:30:47 --> Model Class Initialized
ERROR - 2017-09-07 16:30:47 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\franknco\application\models\api_model.php 379
INFO - 2017-09-07 16:30:47 --> Final output sent to browser
DEBUG - 2017-09-07 16:30:47 --> Total execution time: 0.0589
INFO - 2017-09-07 09:30:52 --> Config Class Initialized
INFO - 2017-09-07 09:30:52 --> Hooks Class Initialized
DEBUG - 2017-09-07 09:30:52 --> UTF-8 Support Enabled
INFO - 2017-09-07 09:30:52 --> Utf8 Class Initialized
INFO - 2017-09-07 09:30:52 --> URI Class Initialized
INFO - 2017-09-07 09:30:52 --> Router Class Initialized
INFO - 2017-09-07 09:30:52 --> Output Class Initialized
INFO - 2017-09-07 09:30:52 --> Security Class Initialized
DEBUG - 2017-09-07 09:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 09:30:52 --> Input Class Initialized
INFO - 2017-09-07 09:30:52 --> Language Class Initialized
INFO - 2017-09-07 09:30:52 --> Loader Class Initialized
INFO - 2017-09-07 09:30:52 --> Helper loaded: url_helper
INFO - 2017-09-07 09:30:52 --> Database Driver Class Initialized
INFO - 2017-09-07 09:30:52 --> Email Class Initialized
INFO - 2017-09-07 09:30:52 --> Controller Class Initialized
DEBUG - 2017-09-07 09:30:52 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 09:30:52 --> Helper loaded: inflector_helper
INFO - 2017-09-07 09:30:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 09:30:52 --> Helper loaded: log_helper
INFO - 2017-09-07 09:30:52 --> Model Class Initialized
INFO - 2017-09-07 16:30:52 --> Final output sent to browser
DEBUG - 2017-09-07 16:30:52 --> Total execution time: 0.1638
INFO - 2017-09-07 09:31:19 --> Config Class Initialized
INFO - 2017-09-07 09:31:19 --> Hooks Class Initialized
DEBUG - 2017-09-07 09:31:19 --> UTF-8 Support Enabled
INFO - 2017-09-07 09:31:19 --> Utf8 Class Initialized
INFO - 2017-09-07 09:31:19 --> URI Class Initialized
INFO - 2017-09-07 09:31:19 --> Router Class Initialized
INFO - 2017-09-07 09:31:19 --> Output Class Initialized
INFO - 2017-09-07 09:31:19 --> Security Class Initialized
DEBUG - 2017-09-07 09:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 09:31:19 --> Input Class Initialized
INFO - 2017-09-07 09:31:19 --> Language Class Initialized
INFO - 2017-09-07 09:31:19 --> Loader Class Initialized
INFO - 2017-09-07 09:31:19 --> Helper loaded: url_helper
INFO - 2017-09-07 09:31:19 --> Database Driver Class Initialized
INFO - 2017-09-07 09:31:19 --> Email Class Initialized
INFO - 2017-09-07 09:31:19 --> Controller Class Initialized
DEBUG - 2017-09-07 09:31:19 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 09:31:19 --> Helper loaded: inflector_helper
INFO - 2017-09-07 09:31:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 09:31:19 --> Helper loaded: log_helper
INFO - 2017-09-07 09:31:19 --> Model Class Initialized
INFO - 2017-09-07 16:31:19 --> Final output sent to browser
DEBUG - 2017-09-07 16:31:19 --> Total execution time: 0.0565
INFO - 2017-09-07 09:31:19 --> Config Class Initialized
INFO - 2017-09-07 09:31:19 --> Hooks Class Initialized
DEBUG - 2017-09-07 09:31:19 --> UTF-8 Support Enabled
INFO - 2017-09-07 09:31:19 --> Utf8 Class Initialized
INFO - 2017-09-07 09:31:19 --> URI Class Initialized
INFO - 2017-09-07 09:31:19 --> Router Class Initialized
INFO - 2017-09-07 09:31:19 --> Output Class Initialized
INFO - 2017-09-07 09:31:19 --> Security Class Initialized
DEBUG - 2017-09-07 09:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 09:31:19 --> Input Class Initialized
INFO - 2017-09-07 09:31:19 --> Language Class Initialized
INFO - 2017-09-07 09:31:19 --> Loader Class Initialized
INFO - 2017-09-07 09:31:19 --> Helper loaded: url_helper
INFO - 2017-09-07 09:31:19 --> Database Driver Class Initialized
INFO - 2017-09-07 09:31:19 --> Email Class Initialized
INFO - 2017-09-07 09:31:19 --> Controller Class Initialized
DEBUG - 2017-09-07 09:31:19 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 09:31:19 --> Helper loaded: inflector_helper
INFO - 2017-09-07 09:31:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 09:31:19 --> Helper loaded: log_helper
INFO - 2017-09-07 09:31:19 --> Model Class Initialized
INFO - 2017-09-07 16:31:19 --> Final output sent to browser
DEBUG - 2017-09-07 16:31:19 --> Total execution time: 0.0725
INFO - 2017-09-07 09:31:45 --> Config Class Initialized
INFO - 2017-09-07 09:31:45 --> Hooks Class Initialized
DEBUG - 2017-09-07 09:31:45 --> UTF-8 Support Enabled
INFO - 2017-09-07 09:31:45 --> Utf8 Class Initialized
INFO - 2017-09-07 09:31:45 --> URI Class Initialized
INFO - 2017-09-07 09:31:45 --> Router Class Initialized
INFO - 2017-09-07 09:31:45 --> Output Class Initialized
INFO - 2017-09-07 09:31:45 --> Security Class Initialized
DEBUG - 2017-09-07 09:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 09:31:45 --> Input Class Initialized
INFO - 2017-09-07 09:31:45 --> Language Class Initialized
INFO - 2017-09-07 09:31:45 --> Loader Class Initialized
INFO - 2017-09-07 09:31:45 --> Helper loaded: url_helper
INFO - 2017-09-07 09:31:45 --> Database Driver Class Initialized
INFO - 2017-09-07 09:31:45 --> Email Class Initialized
INFO - 2017-09-07 09:31:45 --> Controller Class Initialized
DEBUG - 2017-09-07 09:31:45 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 09:31:45 --> Helper loaded: inflector_helper
INFO - 2017-09-07 09:31:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 09:31:45 --> Helper loaded: log_helper
INFO - 2017-09-07 09:31:45 --> Model Class Initialized
INFO - 2017-09-07 16:31:45 --> Final output sent to browser
DEBUG - 2017-09-07 16:31:45 --> Total execution time: 0.0622
INFO - 2017-09-07 09:31:45 --> Config Class Initialized
INFO - 2017-09-07 09:31:45 --> Hooks Class Initialized
DEBUG - 2017-09-07 09:31:45 --> UTF-8 Support Enabled
INFO - 2017-09-07 09:31:45 --> Utf8 Class Initialized
INFO - 2017-09-07 09:31:45 --> URI Class Initialized
INFO - 2017-09-07 09:31:45 --> Router Class Initialized
INFO - 2017-09-07 09:31:45 --> Output Class Initialized
INFO - 2017-09-07 09:31:45 --> Security Class Initialized
DEBUG - 2017-09-07 09:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 09:31:46 --> Input Class Initialized
INFO - 2017-09-07 09:31:46 --> Language Class Initialized
INFO - 2017-09-07 09:31:46 --> Loader Class Initialized
INFO - 2017-09-07 09:31:46 --> Helper loaded: url_helper
INFO - 2017-09-07 09:31:46 --> Database Driver Class Initialized
INFO - 2017-09-07 09:31:46 --> Email Class Initialized
INFO - 2017-09-07 09:31:46 --> Controller Class Initialized
DEBUG - 2017-09-07 09:31:46 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 09:31:46 --> Helper loaded: inflector_helper
INFO - 2017-09-07 09:31:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 09:31:46 --> Helper loaded: log_helper
INFO - 2017-09-07 09:31:46 --> Model Class Initialized
INFO - 2017-09-07 16:31:46 --> Final output sent to browser
DEBUG - 2017-09-07 16:31:46 --> Total execution time: 0.0770
INFO - 2017-09-07 09:34:47 --> Config Class Initialized
INFO - 2017-09-07 09:34:47 --> Hooks Class Initialized
DEBUG - 2017-09-07 09:34:47 --> UTF-8 Support Enabled
INFO - 2017-09-07 09:34:47 --> Utf8 Class Initialized
INFO - 2017-09-07 09:34:47 --> URI Class Initialized
INFO - 2017-09-07 09:34:47 --> Router Class Initialized
INFO - 2017-09-07 09:34:47 --> Output Class Initialized
INFO - 2017-09-07 09:34:47 --> Security Class Initialized
DEBUG - 2017-09-07 09:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 09:34:47 --> Input Class Initialized
INFO - 2017-09-07 09:34:47 --> Language Class Initialized
INFO - 2017-09-07 09:34:47 --> Loader Class Initialized
INFO - 2017-09-07 09:34:47 --> Helper loaded: url_helper
INFO - 2017-09-07 09:34:47 --> Database Driver Class Initialized
INFO - 2017-09-07 09:34:47 --> Email Class Initialized
INFO - 2017-09-07 09:34:47 --> Controller Class Initialized
DEBUG - 2017-09-07 09:34:47 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 09:34:47 --> Helper loaded: inflector_helper
INFO - 2017-09-07 09:34:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 09:34:47 --> Helper loaded: log_helper
INFO - 2017-09-07 09:34:47 --> Model Class Initialized
INFO - 2017-09-07 16:34:47 --> Final output sent to browser
DEBUG - 2017-09-07 16:34:47 --> Total execution time: 0.0702
INFO - 2017-09-07 09:34:47 --> Config Class Initialized
INFO - 2017-09-07 09:34:47 --> Hooks Class Initialized
DEBUG - 2017-09-07 09:34:47 --> UTF-8 Support Enabled
INFO - 2017-09-07 09:34:47 --> Utf8 Class Initialized
INFO - 2017-09-07 09:34:47 --> URI Class Initialized
INFO - 2017-09-07 09:34:47 --> Router Class Initialized
INFO - 2017-09-07 09:34:47 --> Output Class Initialized
INFO - 2017-09-07 09:34:47 --> Security Class Initialized
DEBUG - 2017-09-07 09:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 09:34:47 --> Input Class Initialized
INFO - 2017-09-07 09:34:47 --> Language Class Initialized
INFO - 2017-09-07 09:34:47 --> Loader Class Initialized
INFO - 2017-09-07 09:34:47 --> Helper loaded: url_helper
INFO - 2017-09-07 09:34:47 --> Database Driver Class Initialized
INFO - 2017-09-07 09:34:47 --> Email Class Initialized
INFO - 2017-09-07 09:34:47 --> Controller Class Initialized
DEBUG - 2017-09-07 09:34:47 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 09:34:47 --> Helper loaded: inflector_helper
INFO - 2017-09-07 09:34:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 09:34:47 --> Helper loaded: log_helper
INFO - 2017-09-07 09:34:47 --> Model Class Initialized
INFO - 2017-09-07 16:34:47 --> Final output sent to browser
DEBUG - 2017-09-07 16:34:47 --> Total execution time: 0.0725
INFO - 2017-09-07 09:34:50 --> Config Class Initialized
INFO - 2017-09-07 09:34:50 --> Hooks Class Initialized
DEBUG - 2017-09-07 09:34:50 --> UTF-8 Support Enabled
INFO - 2017-09-07 09:34:50 --> Utf8 Class Initialized
INFO - 2017-09-07 09:34:50 --> URI Class Initialized
INFO - 2017-09-07 09:34:50 --> Router Class Initialized
INFO - 2017-09-07 09:34:50 --> Output Class Initialized
INFO - 2017-09-07 09:34:50 --> Security Class Initialized
DEBUG - 2017-09-07 09:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 09:34:50 --> Input Class Initialized
INFO - 2017-09-07 09:34:50 --> Language Class Initialized
INFO - 2017-09-07 09:34:50 --> Loader Class Initialized
INFO - 2017-09-07 09:34:50 --> Helper loaded: url_helper
INFO - 2017-09-07 09:34:50 --> Database Driver Class Initialized
INFO - 2017-09-07 09:34:50 --> Email Class Initialized
INFO - 2017-09-07 09:34:50 --> Controller Class Initialized
DEBUG - 2017-09-07 09:34:50 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 09:34:50 --> Helper loaded: inflector_helper
INFO - 2017-09-07 09:34:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 09:34:50 --> Helper loaded: log_helper
INFO - 2017-09-07 09:34:50 --> Model Class Initialized
INFO - 2017-09-07 16:34:50 --> Final output sent to browser
DEBUG - 2017-09-07 16:34:50 --> Total execution time: 0.0556
INFO - 2017-09-07 09:34:52 --> Config Class Initialized
INFO - 2017-09-07 09:34:52 --> Hooks Class Initialized
DEBUG - 2017-09-07 09:34:52 --> UTF-8 Support Enabled
INFO - 2017-09-07 09:34:52 --> Utf8 Class Initialized
INFO - 2017-09-07 09:34:52 --> URI Class Initialized
INFO - 2017-09-07 09:34:52 --> Router Class Initialized
INFO - 2017-09-07 09:34:52 --> Output Class Initialized
INFO - 2017-09-07 09:34:52 --> Security Class Initialized
DEBUG - 2017-09-07 09:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 09:34:52 --> Input Class Initialized
INFO - 2017-09-07 09:34:52 --> Language Class Initialized
INFO - 2017-09-07 09:34:52 --> Loader Class Initialized
INFO - 2017-09-07 09:34:52 --> Helper loaded: url_helper
INFO - 2017-09-07 09:34:52 --> Database Driver Class Initialized
INFO - 2017-09-07 09:34:52 --> Email Class Initialized
INFO - 2017-09-07 09:34:52 --> Controller Class Initialized
DEBUG - 2017-09-07 09:34:52 --> Config file loaded: C:\wamp64\www\franknco\application\config/rest.php
INFO - 2017-09-07 09:34:52 --> Helper loaded: inflector_helper
INFO - 2017-09-07 09:34:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-07 09:34:52 --> Helper loaded: log_helper
INFO - 2017-09-07 09:34:52 --> Model Class Initialized
INFO - 2017-09-07 16:34:52 --> Final output sent to browser
DEBUG - 2017-09-07 16:34:52 --> Total execution time: 0.0553
