<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-09-14 00:02:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '?vmOR6?)??.+1??߲????WF?N?j_?7'y??@a??????ϝ??.?w?L=??ޤ}?x";Card Number:s:16:' at line 1 - Invalid query: insert into logging_api(user,action,data,last_log_timestamp) values ('Z�n��*[%��T��<','SIGN UP','Init Hit Data User:s:16:"Z�n��*[%��T��<";Password:s:72:"�Щ/Zc�'�vmOR6�)��.+1��߲����WF�N�j_�7'y��@a������ϝ��.�w�L=��ޤ}�x";Card Number:s:16:"�H���`bQ�=) JL�";Fullname:s:8:"i�����";DOB:s:12:"464646646464";Address:s:8:"��I�fg��";Email:s:16:"붝������2|��";',now())
INFO - 2017-09-14 00:02:19 --> Language file loaded: language/english/db_lang.php
INFO - 2017-09-14 00:03:54 --> Final output sent to browser
DEBUG - 2017-09-14 00:03:54 --> Total execution time: 1.1811
INFO - 2017-09-14 10:28:02 --> Config Class Initialized
INFO - 2017-09-14 10:28:02 --> Hooks Class Initialized
DEBUG - 2017-09-14 10:28:02 --> UTF-8 Support Enabled
INFO - 2017-09-14 10:28:02 --> Utf8 Class Initialized
INFO - 2017-09-14 10:28:02 --> URI Class Initialized
INFO - 2017-09-14 10:28:02 --> Router Class Initialized
INFO - 2017-09-14 10:28:02 --> Output Class Initialized
INFO - 2017-09-14 10:28:03 --> Security Class Initialized
DEBUG - 2017-09-14 10:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-14 10:28:03 --> Input Class Initialized
INFO - 2017-09-14 10:28:03 --> Language Class Initialized
INFO - 2017-09-14 10:28:03 --> Loader Class Initialized
INFO - 2017-09-14 10:28:03 --> Helper loaded: url_helper
INFO - 2017-09-14 10:28:03 --> Database Driver Class Initialized
INFO - 2017-09-14 10:28:03 --> Email Class Initialized
INFO - 2017-09-14 10:28:03 --> Controller Class Initialized
DEBUG - 2017-09-14 10:28:03 --> Config file loaded: C:\xampp\htdocs\api\franknco\franknco\application\config/rest.php
INFO - 2017-09-14 10:28:03 --> Helper loaded: inflector_helper
INFO - 2017-09-14 10:28:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-14 10:28:03 --> Helper loaded: log_helper
INFO - 2017-09-14 10:28:03 --> Model Class Initialized
ERROR - 2017-09-14 15:28:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '?vmOR6?)??.+1??߲????WF?N?j_?7'y??@a??????ϝ??.?w?L=??ޤ}?x";Card Number:s:16:' at line 1 - Invalid query: insert into logging_api(user,action,data,last_log_timestamp) values ('Z�n��*[%��T��<','SIGN UP','Init Hit Data User:s:16:"Z�n��*[%��T��<";Password:s:72:"�Щ/Zc�'�vmOR6�)��.+1��߲����WF�N�j_�7'y��@a������ϝ��.�w�L=��ޤ}�x";Card Number:s:16:"P;��4VZH�j19�";Fullname:s:8:"i�����";DOB:s:10:"1994-02-26";Address:s:8:"�k����";Email:s:16:"��e���P�� O꣭�";',now())
INFO - 2017-09-14 15:28:04 --> Language file loaded: language/english/db_lang.php
INFO - 2017-09-14 11:21:53 --> Config Class Initialized
INFO - 2017-09-14 11:21:54 --> Hooks Class Initialized
DEBUG - 2017-09-14 11:21:54 --> UTF-8 Support Enabled
INFO - 2017-09-14 11:21:54 --> Utf8 Class Initialized
INFO - 2017-09-14 11:21:54 --> URI Class Initialized
INFO - 2017-09-14 11:21:54 --> Router Class Initialized
INFO - 2017-09-14 11:21:54 --> Output Class Initialized
INFO - 2017-09-14 11:21:54 --> Security Class Initialized
DEBUG - 2017-09-14 11:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-14 11:21:54 --> Input Class Initialized
INFO - 2017-09-14 11:21:54 --> Language Class Initialized
INFO - 2017-09-14 11:21:54 --> Loader Class Initialized
INFO - 2017-09-14 11:21:54 --> Helper loaded: url_helper
INFO - 2017-09-14 11:21:54 --> Database Driver Class Initialized
INFO - 2017-09-14 11:21:54 --> Email Class Initialized
INFO - 2017-09-14 11:21:54 --> Controller Class Initialized
DEBUG - 2017-09-14 11:21:54 --> Config file loaded: C:\xampp\htdocs\api\franknco\franknco\application\config/rest.php
INFO - 2017-09-14 11:21:54 --> Helper loaded: inflector_helper
INFO - 2017-09-14 11:21:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-14 11:21:54 --> Helper loaded: log_helper
INFO - 2017-09-14 11:21:54 --> Model Class Initialized
ERROR - 2017-09-14 16:21:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '?vmOR6?)??.+1??߲????WF?N?j_?7'y??@a??????ϝ??.?w?L=??ޤ}?x";Card Number:s:16:' at line 1 - Invalid query: insert into logging_api(user,action,data,last_log_timestamp) values ('Z�n��*[%��T��<','SIGN UP','Init Hit Data User:s:16:"Z�n��*[%��T��<";Password:s:72:"�Щ/Zc�'�vmOR6�)��.+1��߲����WF�N�j_�7'y��@a������ϝ��.�w�L=��ޤ}�x";Card Number:s:16:"P;��4VZH�j19�";Fullname:s:8:"i�����";DOB:s:10:"1994-02-26";Address:s:7:"�>�mt�";Email:s:16:"T���HDd���ۢ";',now())
INFO - 2017-09-14 16:21:54 --> Language file loaded: language/english/db_lang.php
INFO - 2017-09-14 11:22:54 --> Config Class Initialized
INFO - 2017-09-14 11:22:54 --> Hooks Class Initialized
DEBUG - 2017-09-14 11:22:54 --> UTF-8 Support Enabled
INFO - 2017-09-14 11:22:54 --> Utf8 Class Initialized
INFO - 2017-09-14 11:22:54 --> URI Class Initialized
INFO - 2017-09-14 11:22:54 --> Router Class Initialized
INFO - 2017-09-14 11:22:54 --> Output Class Initialized
INFO - 2017-09-14 11:22:54 --> Security Class Initialized
DEBUG - 2017-09-14 11:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-14 11:22:54 --> Input Class Initialized
INFO - 2017-09-14 11:22:54 --> Language Class Initialized
INFO - 2017-09-14 11:22:54 --> Loader Class Initialized
INFO - 2017-09-14 11:22:54 --> Helper loaded: url_helper
INFO - 2017-09-14 11:22:54 --> Database Driver Class Initialized
INFO - 2017-09-14 11:22:54 --> Email Class Initialized
INFO - 2017-09-14 11:22:54 --> Controller Class Initialized
DEBUG - 2017-09-14 11:22:54 --> Config file loaded: C:\xampp\htdocs\api\franknco\franknco\application\config/rest.php
INFO - 2017-09-14 11:22:54 --> Helper loaded: inflector_helper
INFO - 2017-09-14 11:22:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-14 11:22:54 --> Helper loaded: log_helper
INFO - 2017-09-14 11:22:54 --> Model Class Initialized
ERROR - 2017-09-14 16:22:54 --> Severity: Warning --> hex2bin(): Hexadecimal input string must have an even length C:\xampp\htdocs\api\franknco\franknco\application\models\api_model.php 706
ERROR - 2017-09-14 16:22:54 --> Severity: Warning --> mdecrypt_generic(): An empty string was passed C:\xampp\htdocs\api\franknco\franknco\application\models\api_model.php 706
INFO - 2017-09-14 16:22:55 --> Final output sent to browser
DEBUG - 2017-09-14 16:22:55 --> Total execution time: 1.3391
INFO - 2017-09-14 11:24:29 --> Config Class Initialized
INFO - 2017-09-14 11:24:29 --> Hooks Class Initialized
DEBUG - 2017-09-14 11:24:29 --> UTF-8 Support Enabled
INFO - 2017-09-14 11:24:29 --> Utf8 Class Initialized
INFO - 2017-09-14 11:24:29 --> URI Class Initialized
INFO - 2017-09-14 11:24:29 --> Router Class Initialized
INFO - 2017-09-14 11:24:29 --> Output Class Initialized
INFO - 2017-09-14 11:24:29 --> Security Class Initialized
DEBUG - 2017-09-14 11:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-14 11:24:29 --> Input Class Initialized
INFO - 2017-09-14 11:24:29 --> Language Class Initialized
INFO - 2017-09-14 11:24:29 --> Loader Class Initialized
INFO - 2017-09-14 11:24:29 --> Helper loaded: url_helper
INFO - 2017-09-14 11:24:29 --> Database Driver Class Initialized
INFO - 2017-09-14 11:24:29 --> Email Class Initialized
INFO - 2017-09-14 11:24:29 --> Controller Class Initialized
DEBUG - 2017-09-14 11:24:29 --> Config file loaded: C:\xampp\htdocs\api\franknco\franknco\application\config/rest.php
INFO - 2017-09-14 11:24:29 --> Helper loaded: inflector_helper
INFO - 2017-09-14 11:24:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-14 11:24:29 --> Helper loaded: log_helper
INFO - 2017-09-14 11:24:29 --> Model Class Initialized
ERROR - 2017-09-14 16:24:29 --> Severity: Warning --> hex2bin(): Hexadecimal input string must have an even length C:\xampp\htdocs\api\franknco\franknco\application\models\api_model.php 706
ERROR - 2017-09-14 16:24:29 --> Severity: Warning --> mdecrypt_generic(): An empty string was passed C:\xampp\htdocs\api\franknco\franknco\application\models\api_model.php 706
INFO - 2017-09-14 16:24:29 --> Final output sent to browser
DEBUG - 2017-09-14 16:24:30 --> Total execution time: 0.4450
INFO - 2017-09-14 11:39:54 --> Config Class Initialized
INFO - 2017-09-14 11:39:54 --> Hooks Class Initialized
DEBUG - 2017-09-14 11:39:54 --> UTF-8 Support Enabled
INFO - 2017-09-14 11:39:54 --> Utf8 Class Initialized
INFO - 2017-09-14 11:39:54 --> URI Class Initialized
INFO - 2017-09-14 11:39:54 --> Router Class Initialized
INFO - 2017-09-14 11:39:54 --> Output Class Initialized
INFO - 2017-09-14 11:39:54 --> Security Class Initialized
DEBUG - 2017-09-14 11:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-14 11:39:54 --> Input Class Initialized
INFO - 2017-09-14 11:39:54 --> Language Class Initialized
INFO - 2017-09-14 11:39:54 --> Loader Class Initialized
INFO - 2017-09-14 11:39:54 --> Helper loaded: url_helper
INFO - 2017-09-14 11:39:54 --> Database Driver Class Initialized
INFO - 2017-09-14 11:39:54 --> Email Class Initialized
INFO - 2017-09-14 11:39:54 --> Controller Class Initialized
DEBUG - 2017-09-14 11:39:54 --> Config file loaded: C:\xampp\htdocs\api\franknco\franknco\application\config/rest.php
INFO - 2017-09-14 11:39:54 --> Helper loaded: inflector_helper
INFO - 2017-09-14 11:39:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-14 11:39:54 --> Helper loaded: log_helper
INFO - 2017-09-14 11:39:54 --> Model Class Initialized
ERROR - 2017-09-14 16:39:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '?vmOR6?)??.+1??߲????WF?N?j_?7'y??@a??????ϝ??.?w?L=??ޤ}?x";Card Number:s:16:' at line 1 - Invalid query: insert into logging_api(user,action,data,last_log_timestamp) values ('Z�n��*[%��T��<','SIGN UP','Init Hit Data User:s:16:"Z�n��*[%��T��<";Password:s:72:"�Щ/Zc�'�vmOR6�)��.+1��߲����WF�N�j_�7'y��@a������ϝ��.�w�L=��ޤ}�x";Card Number:s:16:"P;��4VZH�j19�";Fullname:s:8:"i�����";DOB:s:10:"1994-02-26";Address:s:7:"�>�mt�";Email:s:16:"T���HDd���ۢ";',now())
INFO - 2017-09-14 16:39:54 --> Language file loaded: language/english/db_lang.php
INFO - 2017-09-14 11:41:43 --> Config Class Initialized
INFO - 2017-09-14 11:41:43 --> Hooks Class Initialized
DEBUG - 2017-09-14 11:41:43 --> UTF-8 Support Enabled
INFO - 2017-09-14 11:41:43 --> Utf8 Class Initialized
INFO - 2017-09-14 11:41:43 --> URI Class Initialized
INFO - 2017-09-14 11:41:43 --> Router Class Initialized
INFO - 2017-09-14 11:41:43 --> Output Class Initialized
INFO - 2017-09-14 11:41:43 --> Security Class Initialized
DEBUG - 2017-09-14 11:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-14 11:41:43 --> Input Class Initialized
INFO - 2017-09-14 11:41:43 --> Language Class Initialized
INFO - 2017-09-14 11:41:43 --> Loader Class Initialized
INFO - 2017-09-14 11:41:43 --> Helper loaded: url_helper
INFO - 2017-09-14 11:41:43 --> Database Driver Class Initialized
INFO - 2017-09-14 11:41:43 --> Email Class Initialized
INFO - 2017-09-14 11:41:43 --> Controller Class Initialized
DEBUG - 2017-09-14 11:41:43 --> Config file loaded: C:\xampp\htdocs\api\franknco\franknco\application\config/rest.php
INFO - 2017-09-14 11:41:43 --> Helper loaded: inflector_helper
INFO - 2017-09-14 11:41:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-14 11:41:43 --> Helper loaded: log_helper
INFO - 2017-09-14 11:41:43 --> Model Class Initialized
ERROR - 2017-09-14 16:41:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '?vmOR6?)??.+1??߲????WF?N?j_?7'y??@a??????ϝ??.?w?L=??ޤ}?x";Card Number:s:16:' at line 1 - Invalid query: insert into logging_api(user,action,data,last_log_timestamp) values ('Z�n��*[%��T��<','SIGN UP','Init Hit Data User:s:16:"Z�n��*[%��T��<";Password:s:72:"�Щ/Zc�'�vmOR6�)��.+1��߲����WF�N�j_�7'y��@a������ϝ��.�w�L=��ޤ}�x";Card Number:s:16:"P;��4VZH�j19�";Fullname:s:8:"i�����";DOB:s:10:"1994-02-26";Address:s:7:"�>�mt�";Email:s:16:"T���HDd���ۢ";',now())
INFO - 2017-09-14 16:41:43 --> Language file loaded: language/english/db_lang.php
INFO - 2017-09-14 13:34:04 --> Config Class Initialized
INFO - 2017-09-14 13:34:04 --> Hooks Class Initialized
DEBUG - 2017-09-14 13:34:04 --> UTF-8 Support Enabled
INFO - 2017-09-14 13:34:04 --> Utf8 Class Initialized
INFO - 2017-09-14 13:34:04 --> URI Class Initialized
INFO - 2017-09-14 13:34:04 --> Router Class Initialized
INFO - 2017-09-14 13:34:04 --> Output Class Initialized
INFO - 2017-09-14 13:34:04 --> Security Class Initialized
DEBUG - 2017-09-14 13:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-14 13:34:04 --> Input Class Initialized
INFO - 2017-09-14 13:34:04 --> Language Class Initialized
INFO - 2017-09-14 13:34:04 --> Loader Class Initialized
INFO - 2017-09-14 13:34:04 --> Helper loaded: url_helper
INFO - 2017-09-14 13:34:04 --> Database Driver Class Initialized
INFO - 2017-09-14 13:34:04 --> Email Class Initialized
INFO - 2017-09-14 13:34:04 --> Controller Class Initialized
DEBUG - 2017-09-14 13:34:04 --> Config file loaded: C:\xampp\htdocs\api\franknco\franknco\application\config/rest.php
INFO - 2017-09-14 13:34:04 --> Helper loaded: inflector_helper
INFO - 2017-09-14 13:34:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-14 13:34:04 --> Helper loaded: log_helper
INFO - 2017-09-14 13:34:04 --> Model Class Initialized
INFO - 2017-09-14 18:34:04 --> Final output sent to browser
DEBUG - 2017-09-14 18:34:04 --> Total execution time: 0.3380
INFO - 2017-09-14 13:34:24 --> Config Class Initialized
INFO - 2017-09-14 13:34:24 --> Hooks Class Initialized
DEBUG - 2017-09-14 13:34:24 --> UTF-8 Support Enabled
INFO - 2017-09-14 13:34:24 --> Utf8 Class Initialized
INFO - 2017-09-14 13:34:24 --> URI Class Initialized
INFO - 2017-09-14 13:34:24 --> Router Class Initialized
INFO - 2017-09-14 13:34:24 --> Output Class Initialized
INFO - 2017-09-14 13:34:24 --> Security Class Initialized
DEBUG - 2017-09-14 13:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-14 13:34:24 --> Input Class Initialized
INFO - 2017-09-14 13:34:24 --> Language Class Initialized
INFO - 2017-09-14 13:34:24 --> Loader Class Initialized
INFO - 2017-09-14 13:34:24 --> Helper loaded: url_helper
INFO - 2017-09-14 13:34:24 --> Database Driver Class Initialized
INFO - 2017-09-14 13:34:24 --> Email Class Initialized
INFO - 2017-09-14 13:34:24 --> Controller Class Initialized
DEBUG - 2017-09-14 13:34:24 --> Config file loaded: C:\xampp\htdocs\api\franknco\franknco\application\config/rest.php
INFO - 2017-09-14 13:34:24 --> Helper loaded: inflector_helper
INFO - 2017-09-14 13:34:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-14 13:34:24 --> Helper loaded: log_helper
INFO - 2017-09-14 13:34:24 --> Model Class Initialized
INFO - 2017-09-14 18:34:24 --> Final output sent to browser
DEBUG - 2017-09-14 18:34:24 --> Total execution time: 0.3290
INFO - 2017-09-14 13:47:59 --> Config Class Initialized
INFO - 2017-09-14 13:47:59 --> Hooks Class Initialized
DEBUG - 2017-09-14 13:47:59 --> UTF-8 Support Enabled
INFO - 2017-09-14 13:47:59 --> Utf8 Class Initialized
INFO - 2017-09-14 13:47:59 --> URI Class Initialized
INFO - 2017-09-14 13:47:59 --> Router Class Initialized
INFO - 2017-09-14 13:47:59 --> Output Class Initialized
INFO - 2017-09-14 13:47:59 --> Security Class Initialized
DEBUG - 2017-09-14 13:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-14 13:47:59 --> Input Class Initialized
INFO - 2017-09-14 13:47:59 --> Language Class Initialized
INFO - 2017-09-14 13:47:59 --> Loader Class Initialized
INFO - 2017-09-14 13:47:59 --> Helper loaded: url_helper
INFO - 2017-09-14 13:47:59 --> Database Driver Class Initialized
INFO - 2017-09-14 13:47:59 --> Email Class Initialized
INFO - 2017-09-14 13:47:59 --> Controller Class Initialized
DEBUG - 2017-09-14 13:47:59 --> Config file loaded: C:\xampp\htdocs\api\franknco\franknco\application\config/rest.php
INFO - 2017-09-14 13:47:59 --> Helper loaded: inflector_helper
INFO - 2017-09-14 13:47:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-14 13:47:59 --> Helper loaded: log_helper
INFO - 2017-09-14 13:47:59 --> Model Class Initialized
ERROR - 2017-09-14 18:47:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '?vmOR6?)??.+1??߲????WF?N?j_?7'y??@a??????ϝ??.?w?L=??ޤ}?x";Card Number:s:16:' at line 1 - Invalid query: insert into logging_api(user,action,data,last_log_timestamp) values ('Z�n��*[%��T��<','SIGN UP','Init Hit Data User:s:16:"Z�n��*[%��T��<";Password:s:72:"�Щ/Zc�'�vmOR6�)��.+1��߲����WF�N�j_�7'y��@a������ϝ��.�w�L=��ޤ}�x";Card Number:s:16:"P;��4VZHJ��(��";Fullname:s:8:"i�����";DOB:s:10:"1994-02-26";Address:s:7:"�>�mt�";Email:s:16:"q%o~웿y��ơ�";',now())
INFO - 2017-09-14 18:47:59 --> Language file loaded: language/english/db_lang.php
INFO - 2017-09-14 13:48:44 --> Config Class Initialized
INFO - 2017-09-14 13:48:44 --> Hooks Class Initialized
DEBUG - 2017-09-14 13:48:44 --> UTF-8 Support Enabled
INFO - 2017-09-14 13:48:44 --> Utf8 Class Initialized
INFO - 2017-09-14 13:48:44 --> URI Class Initialized
INFO - 2017-09-14 13:48:44 --> Router Class Initialized
INFO - 2017-09-14 13:48:44 --> Output Class Initialized
INFO - 2017-09-14 13:48:44 --> Security Class Initialized
DEBUG - 2017-09-14 13:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-14 13:48:44 --> Input Class Initialized
INFO - 2017-09-14 13:48:44 --> Language Class Initialized
INFO - 2017-09-14 13:48:44 --> Loader Class Initialized
INFO - 2017-09-14 13:48:44 --> Helper loaded: url_helper
INFO - 2017-09-14 13:48:44 --> Database Driver Class Initialized
INFO - 2017-09-14 13:48:44 --> Email Class Initialized
INFO - 2017-09-14 13:48:44 --> Controller Class Initialized
DEBUG - 2017-09-14 13:48:44 --> Config file loaded: C:\xampp\htdocs\api\franknco\franknco\application\config/rest.php
INFO - 2017-09-14 13:48:44 --> Helper loaded: inflector_helper
INFO - 2017-09-14 13:48:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-14 13:48:44 --> Helper loaded: log_helper
INFO - 2017-09-14 13:48:44 --> Model Class Initialized
INFO - 2017-09-14 18:48:44 --> Final output sent to browser
DEBUG - 2017-09-14 18:48:45 --> Total execution time: 0.3310
INFO - 2017-09-14 14:19:46 --> Config Class Initialized
INFO - 2017-09-14 14:19:46 --> Hooks Class Initialized
DEBUG - 2017-09-14 14:19:46 --> UTF-8 Support Enabled
INFO - 2017-09-14 14:19:46 --> Utf8 Class Initialized
INFO - 2017-09-14 14:19:46 --> URI Class Initialized
INFO - 2017-09-14 14:19:46 --> Router Class Initialized
INFO - 2017-09-14 14:19:46 --> Output Class Initialized
INFO - 2017-09-14 14:19:46 --> Security Class Initialized
DEBUG - 2017-09-14 14:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-14 14:19:46 --> Input Class Initialized
INFO - 2017-09-14 14:19:46 --> Language Class Initialized
INFO - 2017-09-14 14:19:46 --> Loader Class Initialized
INFO - 2017-09-14 14:19:46 --> Helper loaded: url_helper
INFO - 2017-09-14 14:19:46 --> Database Driver Class Initialized
INFO - 2017-09-14 14:19:46 --> Email Class Initialized
INFO - 2017-09-14 14:19:46 --> Controller Class Initialized
DEBUG - 2017-09-14 14:19:46 --> Config file loaded: C:\xampp\htdocs\api\franknco\franknco\application\config/rest.php
INFO - 2017-09-14 14:19:46 --> Helper loaded: inflector_helper
INFO - 2017-09-14 14:19:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-14 14:19:46 --> Helper loaded: log_helper
INFO - 2017-09-14 14:19:46 --> Model Class Initialized
ERROR - 2017-09-14 19:19:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'SIGN UP','Init Hit Data User:s:16:"???/+?#(3m!'";Password:s:72:"???ڏ???' at line 1 - Invalid query: insert into logging_api(user,action,data,last_log_timestamp) values ('��/+�#(3m!'','SIGN UP','Init Hit Data User:s:16:"��/+�#(3m!'";Password:s:72:"���ڏ���ɑ.@��U�U��vp�d˙��N���B<���'�=u�T�f��8:�����7;)���4�";Card Number:s:16:"�-�ћ��ժt<���";Fullname:s:8:"�d���Gs�";DOB:s:10:"1994-02-26";Address:s:8:"h����!�";Email:s:16:"�a
�T���jJŃ����";',now())
INFO - 2017-09-14 19:19:46 --> Language file loaded: language/english/db_lang.php
INFO - 2017-09-14 14:28:32 --> Config Class Initialized
INFO - 2017-09-14 14:28:32 --> Hooks Class Initialized
DEBUG - 2017-09-14 14:28:32 --> UTF-8 Support Enabled
INFO - 2017-09-14 14:28:32 --> Utf8 Class Initialized
INFO - 2017-09-14 14:28:32 --> URI Class Initialized
INFO - 2017-09-14 14:28:32 --> Router Class Initialized
INFO - 2017-09-14 14:28:32 --> Output Class Initialized
INFO - 2017-09-14 14:28:32 --> Security Class Initialized
DEBUG - 2017-09-14 14:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-14 14:28:32 --> Input Class Initialized
INFO - 2017-09-14 14:28:32 --> Language Class Initialized
INFO - 2017-09-14 14:28:32 --> Loader Class Initialized
INFO - 2017-09-14 14:28:33 --> Helper loaded: url_helper
INFO - 2017-09-14 14:28:33 --> Database Driver Class Initialized
INFO - 2017-09-14 14:28:33 --> Email Class Initialized
INFO - 2017-09-14 14:28:33 --> Controller Class Initialized
DEBUG - 2017-09-14 14:28:33 --> Config file loaded: C:\xampp\htdocs\api\franknco\franknco\application\config/rest.php
INFO - 2017-09-14 14:28:33 --> Helper loaded: inflector_helper
INFO - 2017-09-14 14:28:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2017-09-14 14:28:33 --> Helper loaded: log_helper
INFO - 2017-09-14 14:28:33 --> Model Class Initialized
INFO - 2017-09-14 19:28:33 --> Final output sent to browser
DEBUG - 2017-09-14 19:28:33 --> Total execution time: 0.4810
